import React from "react";
import type { Metadata } from "next";
import AdvancedSearch from "@/components/wiki/AdvancedSearch";

export const metadata: Metadata = {
  title: "Pirate Crews & Fleets Encyclopedia — One Piece Fan Wiki",
  description: "Examine detailed ship manifests, former members, Jolly Roger designs, and total fleet bounties for all Grand Line crews.",
};

export default function CrewsIndexPage() {
  return <AdvancedSearch />;
}
