import React from "react";
import type { Metadata } from "next";
import CrewView from "@/components/wiki/CrewView";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const name = resolvedParams.slug.split("-").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  return {
    title: `${name} — Fleet Manifest & History | One Piece Fan Wiki`,
    description: `Complete crew manifest for ${name}, including captain profile, executive officers, flagship blueprints, and territorial holdings.`,
  };
}

export default async function CrewPage({ params }: PageProps) {
  const resolvedParams = await params;
  return <CrewView crewSlug={resolvedParams.slug} />;
}
