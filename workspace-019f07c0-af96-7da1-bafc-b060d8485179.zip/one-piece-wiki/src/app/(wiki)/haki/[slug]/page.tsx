import React from "react";
import type { Metadata } from "next";
import HakiView from "@/components/wiki/HakiView";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const name = resolvedParams.slug.split("-").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  return {
    title: `${name} — Haki Advanced Technique Manifest | One Piece Fan Wiki`,
    description: `Comprehensive analysis of ${name}, covering advanced tactical applications, known supreme wielders, and legendary historical clash examples.`,
  };
}

export default async function HakiPage({ params }: PageProps) {
  const resolvedParams = await params;
  return <HakiView hakiSlug={resolvedParams.slug} />;
}
