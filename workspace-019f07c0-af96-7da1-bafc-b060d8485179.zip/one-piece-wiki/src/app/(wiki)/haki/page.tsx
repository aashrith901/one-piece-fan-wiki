import React from "react";
import type { Metadata } from "next";
import AdvancedSearch from "@/components/wiki/AdvancedSearch";

export const metadata: Metadata = {
  title: "The Three Colors of Haki Guide — One Piece Fan Wiki",
  description: "Examine advanced applications of Conqueror's Infusion, Future Sight, and Internal Destruction across legendary Grand Line users.",
};

export default function HakiIndexPage() {
  return <AdvancedSearch />;
}
