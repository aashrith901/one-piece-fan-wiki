import React from "react";
import type { Metadata } from "next";
import AdvancedSearch from "@/components/wiki/AdvancedSearch";

export const metadata: Metadata = {
  title: "Meito Weapons & Named Swords Registry — One Piece Fan Wiki",
  description: "Examine Supreme Grade, Great Grade, and Skillful Grade blade specifications, master wielders, and historical battle origins.",
};

export default function WeaponsIndexPage() {
  return <AdvancedSearch />;
}
