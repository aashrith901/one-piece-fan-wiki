import React from "react";
import type { Metadata } from "next";
import WeaponView from "@/components/wiki/WeaponView";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const name = resolvedParams.slug.split("-").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  return {
    title: `${name} — Meito Blade Specification & History | One Piece Fan Wiki`,
    description: `Complete technical specification and historical analysis for the ${name} Meito weapon, including wielder lineage and combat capabilities.`,
  };
}

export default async function WeaponPage({ params }: PageProps) {
  const resolvedParams = await params;
  return <WeaponView weaponSlug={resolvedParams.slug} />;
}
