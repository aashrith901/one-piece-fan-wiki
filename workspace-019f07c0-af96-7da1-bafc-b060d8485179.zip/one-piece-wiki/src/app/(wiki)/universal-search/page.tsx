import React from "react";
import type { Metadata } from "next";
import UniversalSearchDashboard from "@/components/wiki/UniversalSearchDashboard";
import { PremiumNavbar, MobileNavbar, ScrollIndicator, Footer } from "@/components/navigation/navigation-system";

export const metadata: Metadata = {
  title: "Universal Grand Line Search Engine — One Piece Fan Wiki",
  description: "Instantly scan across 10,000+ characters, crews, devil fruits, manga chapters, and anime episodes with voice recognition, fuzzy typo correction, and live analytical tracking.",
};

export default function UniversalSearchPage() {
  return (
    <div className="w-full min-h-screen bg-background flex flex-col justify-between">
      <PremiumNavbar onOpenSearch={() => {}} />
      <MobileNavbar onOpenSearch={() => {}} />
      <ScrollIndicator />
      <div className="flex-grow">
        <UniversalSearchDashboard />
      </div>
      <Footer />
    </div>
  );
}
