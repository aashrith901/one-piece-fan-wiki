import React from "react";
import type { Metadata } from "next";
import NewsArticleView from "@/components/news/NewsArticleView";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const name = resolvedParams.slug.split("-").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  return {
    title: `${name} — Grand Line News | One Piece Fan Wiki`,
    description: `Read the full news dispatch regarding ${name}, complete with community transponder snail discussions and editorial analysis.`,
  };
}

export default async function NewsArticlePage({ params }: PageProps) {
  const resolvedParams = await params;
  const title = resolvedParams.slug.split("-").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "NewsArticle",
    "headline": title,
    "image": ["https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=1200&auto=format&fit=crop"],
    "datePublished": "2026-06-25T12:00:00+00:00",
    "dateModified": "2026-06-25T12:00:00+00:00",
    "author": [{
      "@type": "Person",
      "name": "Morgans (World Economy News)",
      "url": "https://onepiecefanwiki.grandline/profile/morgans"
    }]
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <NewsArticleView articleSlug={resolvedParams.slug} />
    </>
  );
}
