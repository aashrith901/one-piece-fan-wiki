import React from "react";
import type { Metadata } from "next";
import NewsIndex from "@/components/news/NewsIndex";

export const metadata: Metadata = {
  title: "Grand Line News Hub — One Piece Fan Wiki",
  description: "Read breaking dispatches, editorial reviews, live action set updates, and official merchandise drops hot off the Grand Line presses.",
};

export default function NewsIndexPage() {
  return <NewsIndex />;
}
