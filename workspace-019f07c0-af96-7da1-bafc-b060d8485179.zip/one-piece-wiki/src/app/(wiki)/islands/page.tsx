import React from "react";
import type { Metadata } from "next";
import AdvancedSearch from "@/components/wiki/AdvancedSearch";

export const metadata: Metadata = {
  title: "Gazetteer of Islands & Realms — One Piece Fan Wiki",
  description: "Examine detailed climate patterns, Log Pose lock times, and ruling factions across every major island in the One Piece universe.",
};

export default function IslandsIndexPage() {
  return <AdvancedSearch />;
}
