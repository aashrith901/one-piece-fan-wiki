import React from "react";
import type { Metadata } from "next";
import IslandView from "@/components/interactive/IslandView";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const name = resolvedParams.slug.split("-").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  return {
    title: `${name} — Gazetteer & Island Explorer | One Piece Fan Wiki`,
    description: `Complete geographic profile for ${name}, including climate, Log Pose lock times, notable inhabitants, and territorial conflict history.`,
  };
}

export default async function IslandPage({ params }: PageProps) {
  const resolvedParams = await params;
  return <IslandView islandSlug={resolvedParams.slug} />;
}
