import React from "react";
import type { Metadata } from "next";
import AdvancedSearch from "@/components/wiki/AdvancedSearch";

export const metadata: Metadata = {
  title: "Advanced Grand Line Search — One Piece Fan Wiki",
  description: "Instantly filter across 1,500+ characters, crews, devil fruits, weapons, and islands with full fuzzy matching and live suggestions.",
};

export default function SearchPage() {
  return <AdvancedSearch />;
}
