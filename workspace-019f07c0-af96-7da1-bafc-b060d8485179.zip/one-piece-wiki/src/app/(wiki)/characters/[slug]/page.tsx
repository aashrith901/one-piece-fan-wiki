import React from "react";
import type { Metadata } from "next";
import CharacterView from "@/components/wiki/CharacterView";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const name = resolvedParams.slug.split("-").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  return {
    title: `${name} — Dossier & Lore Biome | One Piece Fan Wiki`,
    description: `Complete character profile for ${name}, including official artwork, bounty timeline, devil fruit awakening analysis, and haki mastery.`,
  };
}

export default async function CharacterPage({ params }: PageProps) {
  const resolvedParams = await params;
  return <CharacterView characterSlug={resolvedParams.slug} />;
}
