import React from "react";
import type { Metadata } from "next";
import AdvancedSearch from "@/components/wiki/AdvancedSearch";

export const metadata: Metadata = {
  title: "Universal Character Database — One Piece Fan Wiki",
  description: "Explore the comprehensive index of Straw Hat Crew members, Marines, Yonko, Warlords, and Cross Guild operatives.",
};

export default function CharactersIndexPage() {
  return <AdvancedSearch />;
}
