import React from "react";
import { LoadingScreen } from "@/components/ui/feedback";

export default function WikiLoading() {
  return <LoadingScreen text="Querying Ancient Logs of the Grand Line..." className="min-h-screen" />;
}
