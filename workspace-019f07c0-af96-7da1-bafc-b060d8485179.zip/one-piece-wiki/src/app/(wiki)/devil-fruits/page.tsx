import React from "react";
import type { Metadata } from "next";
import AdvancedSearch from "@/components/wiki/AdvancedSearch";

export const metadata: Metadata = {
  title: "Cursed Devil Fruit Encyclopedia — One Piece Fan Wiki",
  description: "Investigate Paramecia, Zoan, and Logia classification tiers, awakened forms, strengths, weaknesses, and side-by-side comparison matrices.",
};

export default function DevilFruitsIndexPage() {
  return <AdvancedSearch />;
}
