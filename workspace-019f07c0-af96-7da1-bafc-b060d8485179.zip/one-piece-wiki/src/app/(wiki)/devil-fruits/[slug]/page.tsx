import React from "react";
import type { Metadata } from "next";
import DevilFruitView from "@/components/wiki/DevilFruitView";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const name = resolvedParams.slug.split("-").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  return {
    title: `${name} — Devil Fruit Abilities & Awakening | One Piece Fan Wiki`,
    description: `Detailed analysis of the ${name} Devil Fruit, including wielder identity, strengths, weaknesses, and awakening manifestations.`,
  };
}

export default async function DevilFruitPage({ params }: PageProps) {
  const resolvedParams = await params;
  return <DevilFruitView fruitSlug={resolvedParams.slug} />;
}
