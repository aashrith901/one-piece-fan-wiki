"use client";

import React from "react";
import { ErrorComponent } from "@/components/ui/feedback";

export default function WikiError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="w-full min-h-screen bg-background flex items-center justify-center">
      <ErrorComponent
        title="BUSTER CALL ON ARCHIVE SERVER!"
        message={`A transmission fault occurred while retrieving lore entity records: ${error.message}`}
        onRetry={reset}
      />
    </div>
  );
}
