import React from "react";
import type { Metadata } from "next";
import BountyView from "@/components/wiki/BountyView";

export const metadata: Metadata = {
  title: "Historical Bounty Ledger & Fleet Charts — One Piece Fan Wiki",
  description: "Track official Wanted Dead or Alive bounty progress, highest individual infamy amounts, and total combined crew totals across the New World.",
};

export default function BountiesIndexPage() {
  return <BountyView />;
}
