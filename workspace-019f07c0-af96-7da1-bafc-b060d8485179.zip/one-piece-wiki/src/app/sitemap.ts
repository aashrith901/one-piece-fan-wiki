import { MetadataRoute } from "next";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = "https://onepiecefanwiki.grandline";

  const routes = [
    "",
    "/characters",
    "/crews",
    "/devil-fruits",
    "/haki",
    "/weapons",
    "/ships",
    "/islands",
    "/world-map",
    "/bounties",
    "/bounties/generator",
    "/news",
    "/universal-search",
    "/community/boards",
  ];

  return routes.map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: route === "" || route === "/news" ? "daily" : "weekly",
    priority: route === "" ? 1.0 : route.includes("generator") || route === "/world-map" ? 0.9 : 0.8,
  }));
}
