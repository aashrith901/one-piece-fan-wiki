import React from "react";
import type { Metadata, Viewport } from "next";
import { Inter, Cinzel, Pirata_One } from "next/font/google";
import { auth } from "@/server/auth";
import GlobalProviders from "@/components/providers/GlobalProviders";
import SoundToggle from "@/components/ui/sound-toggle";
import "@/app/globals.css";

// ============================================================================
// ENTERPRISE FONT OPTIMIZATION & CONFIGURATION
// ============================================================================

const fontInter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

const fontCinzel = Cinzel({
  subsets: ["latin"],
  variable: "--font-cinematic",
  display: "swap",
  weight: ["400", "600", "700"],
});

const fontPirata = Pirata_One({
  subsets: ["latin"],
  variable: "--font-pirate",
  display: "swap",
  weight: ["400"],
});

// ============================================================================
// ENTERPRISE VIEWPORT & PWA METADATA CONFIGURATION
// ============================================================================

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#051329" },
    { media: "(prefers-color-scheme: light)", color: "#f5ecd8" },
  ],
  colorScheme: "dark light",
};

export const metadata: Metadata = {
  title: "One Piece Fan Wiki — The Ultimate Fan Encyclopedia of the Grand Line",
  description: "Set sail across 1,100+ manga chapters, explore legendary pirate fleets, analyze awakened devil fruits, and craft custom high-fidelity bounty posters with our Canva-grade generator studio.",
  manifest: "/manifest.json",
  icons: {
    icon: "/favicon.ico",
    apple: "/icons/apple-touch-icon.png",
  },
  other: {
    "mobile-web-app-capable": "yes",
    "apple-mobile-web-app-capable": "yes",
    "apple-mobile-web-app-title": "One Piece Wiki",
  },
};

// ============================================================================
// ROOT APPLICATION LAYOUT (RSC)
// ============================================================================

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();

  return (
    <html lang="en" suppressHydrationWarning className={`${fontInter.variable} ${fontCinzel.variable} ${fontPirata.variable} dark`}>
      <head>
        <meta name="application-name" content="One Piece Fan Wiki" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      </head>
      <body className="bg-background text-foreground font-sans antialiased overflow-x-hidden selection:bg-treasure selection:text-ocean-deep min-h-screen flex flex-col justify-between">
        <GlobalProviders session={session}>
          {children}
          {/* Ambient Sound Toggle Microinteraction */}
          <SoundToggle />
        </GlobalProviders>

        {/* PWA Service Worker Registration Script */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              if ('serviceWorker' in navigator) {
                window.addEventListener('load', function() {
                  navigator.serviceWorker.register('/sw.js', { scope: '/' }).then(function(registration) {
                    console.log('ServiceWorker registration successful with scope: ', registration.scope);
                  }, function(err) {
                    console.error('ServiceWorker registration failed: ', err);
                  });
                });
              }
            `,
          }}
        />
      </body>
    </html>
  );
}
