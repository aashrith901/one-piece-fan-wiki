import React from "react";
import type { Metadata } from "next";
import CinematicHome from "@/components/homepage/CinematicHome";

// ============================================================================
// 1. ENTERPRISE SEO METADATA OPTIMIZATION
// ============================================================================

export const metadata: Metadata = {
  title: "One Piece Fan Wiki — The Ultimate Fan Encyclopedia of the Grand Line",
  description: "Set sail across 1,100+ manga chapters, explore legendary pirate fleets, analyze awakened devil fruits, and craft custom high-fidelity bounty posters with our Canva-grade generator studio.",
  keywords: ["One Piece", "Wiki", "Grand Line", "Manga", "Anime", "Bounty Poster Generator", "Luffy", "Gear 5", "Devil Fruits", "Yonko"],
  authors: [{ name: "Gorosei Architects" }],
  openGraph: {
    title: "One Piece Fan Wiki — The Ultimate Fan Encyclopedia of the Grand Line",
    description: "Set sail across 1,100+ manga chapters, explore legendary pirate fleets, analyze awakened devil fruits, and craft custom high-fidelity bounty posters.",
    url: "https://onepiecefanwiki.grandline",
    siteName: "One Piece Fan Wiki",
    images: [
      {
        url: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=1200&auto=format&fit=crop",
        width: 1200,
        height: 630,
        alt: "One Piece Fan Wiki Ultimate Encyclopedia",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "One Piece Fan Wiki — The Ultimate Fan Encyclopedia of the Grand Line",
    description: "Set sail across 1,100+ manga chapters, explore legendary pirate fleets, analyze awakened devil fruits, and craft custom high-fidelity bounty posters.",
    images: ["https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=1200&auto=format&fit=crop"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
};

// ============================================================================
// 2. MAIN HOMEPAGE SERVER COMPONENT
// ============================================================================

export default function HomePage() {
  return <CinematicHome />;
}
