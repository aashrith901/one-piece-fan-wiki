import React from "react";
import type { Metadata } from "next";
import PWAManager from "@/components/pwa/PWAManager";
import { PremiumNavbar, MobileNavbar, Footer } from "@/components/navigation/navigation-system";

export const metadata: Metadata = {
  title: "PWA Offline Mode & App Installation — One Piece Fan Wiki",
  description: "Install the One Piece Fan Wiki to your device home screen. Inspect background synchronization logs and manage offline cache storage.",
};

export default function OfflinePage() {
  return (
    <div className="w-full min-h-screen bg-background flex flex-col justify-between">
      <PremiumNavbar onOpenSearch={() => {}} />
      <MobileNavbar onOpenSearch={() => {}} />
      <div className="flex-grow">
        <PWAManager />
      </div>
      <Footer />
    </div>
  );
}
