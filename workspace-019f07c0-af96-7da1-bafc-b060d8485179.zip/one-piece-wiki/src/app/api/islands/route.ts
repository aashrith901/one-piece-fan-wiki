import { NextRequest, NextResponse } from "next/server";
import { db, islands } from "@/db";
import { ilike, or } from "drizzle-orm";

// ============================================================================
// INTERACTIVE MAP ISLANDS & SEA ROUTES API ROUTE
// ============================================================================

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const query = searchParams.get("q") || "";
    const sea = searchParams.get("sea") || "all"; // East Blue, West Blue, North Blue, South Blue, Grand Line, New World, Sky Islands, Undersea
    const saga = searchParams.get("saga") || "all";
    const importance = searchParams.get("importance") || "all";

    // Static fallback database simulation for absolute runtime resilience
    const fallbackIslands = [
      { id: 1, slug: "foosha-village", name: "Foosha Village", japaneseName: "フーシャ村", region: "East Blue", climate: "Temperate Spring", logPoseLockTime: "N/A", affiliation: "World Government", coverImageUrl: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=800&auto=format&fit=crop", mapCoordX: -40, mapCoordY: 1, mapCoordZ: -30, history: "The peaceful windmill village where Monkey D. Luffy grew up and met Red-Haired Shanks.", cultureAndSociety: "Peaceful rural fishing village.", saga: "East Blue Saga", importance: "Legendary" },
      { id: 2, slug: "alabasta-kingdom", name: "Alabasta Kingdom", japaneseName: "アラバスタ王国", region: "Grand Line", climate: "Desert Heat / Drought", logPoseLockTime: "1 Year (Eternal Pose Recommended)", affiliation: "World Government", coverImageUrl: "https://images.unsplash.com/photo-1505118380757-91f5f563b031?q=80&w=800&auto=format&fit=crop", mapCoordX: -15, mapCoordY: 1, mapCoordZ: -10, history: "A massive desert kingdom saved by the Straw Hat Pirates from Baroque Works and Sir Crocodile.", cultureAndSociety: "Desert oasis culture ruled by the Nefertari family.", saga: "Alabasta Saga", importance: "Major" },
      { id: 3, slug: "skypiea", name: "Skypiea", japaneseName: "スカイピア", region: "Sky Island", climate: "High Altitude Cloud", logPoseLockTime: "Unknown", affiliation: "Independent", coverImageUrl: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?q=80&w=800&auto=format&fit=crop", mapCoordX: 0, mapCoordY: 12, mapCoordZ: 0, history: "An island in the sky formed by a portion of Jaya that was knocked into the clouds by the Knock Up Stream.", cultureAndSociety: "Shandian and Angel islander tribes.", saga: "Sky Island Saga", importance: "Major" },
      { id: 4, slug: "water-7", name: "Water 7", japaneseName: "ウォーターセブン", region: "Grand Line", climate: "Subtropical / Aqua Laguna", logPoseLockTime: "7 Days", affiliation: "World Government", coverImageUrl: "https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=800&auto=format&fit=crop", mapCoordX: 10, mapCoordY: 1, mapCoordZ: 5, history: "The beautiful water metropolis famous for its elite shipwrights and the Sea Train.", cultureAndSociety: "Advanced shipbuilding society governed by Iceburg.", saga: "Water 7 Saga", importance: "Major" },
      { id: 5, slug: "enies-lobby", name: "Enies Lobby", japaneseName: "エニエス・ロビー", region: "Grand Line", climate: "Perpetual Daylight", logPoseLockTime: "N/A (Eternal Pose Required)", affiliation: "World Government", coverImageUrl: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=800&auto=format&fit=crop", mapCoordX: 20, mapCoordY: 1, mapCoordZ: 10, history: "The judicial island of the World Government, obliterated by a Buster Call during the Straw Hats' invasion to rescue Nico Robin.", cultureAndSociety: "Completely militarized judiciary compound.", saga: "Water 7 Saga", importance: "Legendary" },
      { id: 6, slug: "sabaody-archipelago", name: "Sabaody Archipelago", japaneseName: "シャボンディ諸島", region: "Grand Line", climate: "Mangrove Humid", logPoseLockTime: "N/A (Coating Spot)", affiliation: "World Government", coverImageUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=800&auto=format&fit=crop", mapCoordX: 35, mapCoordY: 1, mapCoordZ: 20, history: "A massive mangrove forest where ships are coated with resin before traveling 10,000 meters under the Red Line to Fish-Man Island.", cultureAndSociety: "Lawless mangrove hubs mixed with World Government celestial resorts.", saga: "Summit War Saga", importance: "Major" },
      { id: 7, slug: "marineford", name: "Marineford", japaneseName: "マリンフォード", region: "Grand Line", climate: "Temperate Military", logPoseLockTime: "N/A", affiliation: "World Government", coverImageUrl: "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?q=80&w=800&auto=format&fit=crop", mapCoordX: 30, mapCoordY: 1, mapCoordZ: 35, history: "The former base of the Marine Headquarters and site of the legendary Paramount War where Whitebeard and Portgas D. Ace fell.", cultureAndSociety: "Marine base stronghold.", saga: "Summit War Saga", importance: "Legendary" },
      { id: 8, slug: "fish-man-island", name: "Fish-Man Island", japaneseName: "魚人島", region: "Undersea", climate: "Deep Sea Enclosed Bubble", logPoseLockTime: "Half a Day", affiliation: "Straw Hat Territory", coverImageUrl: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?q=80&w=800&auto=format&fit=crop", mapCoordX: 38, mapCoordY: -10, mapCoordZ: 22, history: "Located directly underneath the Red Line at 10,000 meters depth, protected by Monkey D. Luffy.", cultureAndSociety: "Fish-men and merfolk society.", saga: "Fish-Man Island Saga", importance: "Major" },
      { id: 9, slug: "dressrosa", name: "Dressrosa", japaneseName: "ドレスローザ", region: "New World", climate: "Mediterranean Sunshine", logPoseLockTime: "One Day", affiliation: "World Government (Straw Hat Grand Fleet Allied)", coverImageUrl: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=800&auto=format&fit=crop", mapCoordX: 45, mapCoordY: 1, mapCoordZ: 30, history: "The land of passion, toys, and fairies, liberated from the tyrannical rule of Warlord Donquixote Doflamingo.", cultureAndSociety: "Passionate Spanish-inspired kingdom.", saga: "Dressrosa Saga", importance: "Major" },
      { id: 10, slug: "wano-country", name: "Wano Country", japaneseName: "ワノ国", region: "New World", climate: "Various Severe Weather", logPoseLockTime: "Untraceable (Requires Vivre Card)", affiliation: "Straw Hat Territory", coverImageUrl: "https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=800&auto=format&fit=crop", mapCoordX: 65, mapCoordY: 1, mapCoordZ: 45, history: "An isolated samurai nation liberated from Emperor Kaido by the Straw Hat Alliance, restoring the Kozuki Shogunate.", cultureAndSociety: "Feudal Japanese samurai society.", saga: "Wano Country Saga", importance: "Legendary" },
      { id: 11, slug: "egghead-island", name: "Egghead Island", japaneseName: "エッグヘッド", region: "New World", climate: "Winter Island (Island Climate Controlled)", logPoseLockTime: "A few days", affiliation: "World Government", coverImageUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=800&auto=format&fit=crop", mapCoordX: 80, mapCoordY: 1, mapCoordZ: 55, history: "The Future Island containing the top-secret laboratory of Dr. Vegapunk, site of the historic Egghead Buster Call.", cultureAndSociety: "Extremely advanced sci-fi metropolis.", saga: "Final Saga", importance: "Legendary" },
    ];

    const seaRoutes = {
      strawHat: [
        { x: -40, y: 1, z: -30, name: "Foosha Village" },
        { x: -15, y: 1, z: -10, name: "Alabasta Kingdom" },
        { x: 0, y: 12, z: 0, name: "Skypiea" },
        { x: 10, y: 1, z: 5, name: "Water 7" },
        { x: 35, y: 1, z: 20, name: "Sabaody Archipelago" },
        { x: 38, y: -10, z: 22, name: "Fish-Man Island" },
        { x: 45, y: 1, z: 30, name: "Dressrosa" },
        { x: 65, y: 1, z: 45, name: "Wano Country" },
        { x: 80, y: 1, z: 55, name: "Egghead Island" },
      ],
      rogerPirates: [
        { x: -40, y: 1, z: -30, name: "Loguetown" },
        { x: 10, y: 1, z: 5, name: "Water 7" },
        { x: 38, y: -10, z: 22, name: "Fish-Man Island" },
        { x: 65, y: 1, z: 45, name: "Wano Country" },
        { x: 90, y: 1, z: 65, name: "Laugh Tale (Conjectured)" },
      ],
      marines: [
        { x: 30, y: 1, z: 35, name: "Marineford" },
        { x: 20, y: 1, z: 10, name: "Enies Lobby" },
        { x: 80, y: 1, z: 55, name: "Egghead Island" },
      ],
      revolutionaries: [
        { x: -30, y: 1, z: -20, name: "Baltigo" },
        { x: 45, y: 1, z: 30, name: "Dressrosa" },
        { x: 25, y: 5, z: 15, name: "Kamabakka Kingdom" },
      ],
      yonkoTerritories: [
        { x: 65, y: 1, z: 45, name: "Wano Country (Formerly Kaido)" },
        { x: 55, y: 1, z: 35, name: "Whole Cake Island (Big Mom)" },
        { x: 75, y: 1, z: 50, name: "Hachinosu (Blackbeard)" },
        { x: 85, y: 1, z: 60, name: "Elbaf (Red Hair Pirates)" },
      ],
    };

    try {
      // Attempt live database query if DB connection is active
      const dbIslands = await db.select().from(islands)
        .where(query ? or(ilike(islands.name, `%${query}%`), ilike(islands.region, `%${query}%`)) : undefined);
      
      if (dbIslands.length === 0) {
        throw new Error("Empty DB results, falling back to static map simulation");
      }

      let filtered = dbIslands.map(i => ({ ...i, saga: "Grand Line Saga", importance: "Major" }));
      if (sea !== "all") filtered = filtered.filter(i => i.region.toLowerCase().includes(sea.toLowerCase()));

      return NextResponse.json({
        success: true,
        data: filtered,
        seaRoutes,
      });

    } catch (dbError) {
      // Execute robust filtering on fallback simulation data
      let filtered = fallbackIslands.filter(item => {
        const matchesQuery = item.name.toLowerCase().includes(query.toLowerCase()) || item.region.toLowerCase().includes(query.toLowerCase());
        const matchesSea = sea === "all" ? true : item.region.toLowerCase() === sea.toLowerCase();
        const matchesSaga = saga === "all" ? true : item.saga.toLowerCase() === saga.toLowerCase();
        const matchesImportance = importance === "all" ? true : item.importance.toLowerCase() === importance.toLowerCase();
        return matchesQuery && matchesSea && matchesSaga && matchesImportance;
      });

      return NextResponse.json({
        success: true,
        data: filtered,
        seaRoutes,
      });
    }
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
