import { NextRequest, NextResponse } from "next/server";

// ============================================================================
// GOROSEI MODERATION ENGINE API ROUTE
// ============================================================================

// Memory store simulating moderation actions, active warnings, bans, and reported items
const reportedStore: any[] = [
  { id: 1, type: "comment", targetId: 489, author: "SpamPirate99", reason: "Phishing spam link to fake merchandise.", status: "Pending", reportedAt: "2026-06-25T14:20:00Z" },
  { id: 2, type: "thread", targetId: 102, author: "ToxicFanboy", reason: "Extreme profanity and toxic powerscaling harassment.", status: "Pending", reportedAt: "2026-06-25T11:10:00Z" },
];

const bannedUsers: string[] = ["SpamPirate99"];
const mutedUsers: string[] = ["ToxicFanboy"];
const warningLogs: Record<string, number> = { "RudeAdmiral": 2 };

export async function GET(req: NextRequest) {
  try {
    return NextResponse.json({
      success: true,
      data: {
        reportedItems: reportedStore,
        bannedUsers,
        mutedUsers,
        warningLogs,
        systemHealth: "100% Secure — Profanity & Spam Traps Active",
      },
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const action = body.action; // ban, mute, warn, delete, pin, resolveReport

    if (!action) {
      return NextResponse.json({ success: false, error: "Moderation action parameter is required." }, { status: 400 });
    }

    if (action === "ban") {
      if (!bannedUsers.includes(body.username)) bannedUsers.push(body.username);
      return NextResponse.json({ success: true, message: `Buster Call active: Admiral ${body.username} has been permanently banned from the Grand Line.` });
    } else if (action === "mute") {
      if (!mutedUsers.includes(body.username)) mutedUsers.push(body.username);
      return NextResponse.json({ success: true, message: `Den Den Mushi waves jammed: Admiral ${body.username} has been muted.` });
    } else if (action === "warn") {
      warningLogs[body.username] = (warningLogs[body.username] || 0) + 1;
      return NextResponse.json({ success: true, message: `Issued official Government warning #${warningLogs[body.username]} to Admiral ${body.username}.` });
    } else if (action === "delete") {
      return NextResponse.json({ success: true, message: "Offending content permanently obliterated from the database cache." });
    } else if (action === "pin") {
      return NextResponse.json({ success: true, message: "Thread successfully pinned to the World Government global banner!" });
    } else if (action === "resolveReport") {
      const idx = reportedStore.findIndex((item) => item.id === body.reportId);
      if (idx !== -1) reportedStore[idx].status = "Resolved";
      return NextResponse.json({ success: true, message: "Report successfully resolved." });
    }

    return NextResponse.json({ success: false, error: "Unknown moderation action." }, { status: 400 });

  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
