import React from "react";
import type { Metadata } from "next";
import CommunityIndex from "@/components/community/CommunityIndex";

export const metadata: Metadata = {
  title: "Community Hub & Discussion Boards — One Piece Fan Wiki",
  description: "Share fan theories, debate powerscaling matrices, explore arc reviews, and participate in live universal polls across 18 distinct categories.",
};

export default function CommunityBoardsPage() {
  return <CommunityIndex />;
}
