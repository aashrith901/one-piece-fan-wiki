import React from "react";
import type { Metadata } from "next";
import ThreadDetailView from "@/components/community/ThreadDetailView";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const name = resolvedParams.slug.split("-").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  return {
    title: `${name} — Community Thread | One Piece Fan Wiki`,
    description: `Inspect the community discussion and fan theory evidence for ${name}, complete with nested transponder snail replies and upvote matrices.`,
  };
}

export default async function ThreadPage({ params }: PageProps) {
  const resolvedParams = await params;
  return <ThreadDetailView threadSlug={resolvedParams.slug} />;
}
