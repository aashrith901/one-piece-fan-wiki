import React from "react";
import type { Metadata } from "next";
import LeaderboardsView from "@/components/community/LeaderboardsView";

export const metadata: Metadata = {
  title: "Community Fleet Leaderboards — One Piece Fan Wiki",
  description: "Track XP progression, daily streaks, and supreme reputation levels across the Four Seas. Examine Top Contributors and Theory Masters.",
};

export default function LeaderboardsPage() {
  return <LeaderboardsView />;
}
