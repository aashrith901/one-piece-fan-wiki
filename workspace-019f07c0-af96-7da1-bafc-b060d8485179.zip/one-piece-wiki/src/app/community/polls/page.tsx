import React from "react";
import type { Metadata } from "next";
import PollsStudioView from "@/components/community/PollsStudioView";

export const metadata: Metadata = {
  title: "Universal Community Polls — One Piece Fan Wiki",
  description: "Participate in live universal ballots, powerscaling votes, and theory validation matrices. Create custom single or multiple choice polls.",
};

export default function PollsPage() {
  return <PollsStudioView />;
}
