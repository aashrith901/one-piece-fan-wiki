import React from "react";
import type { Metadata } from "next";
import AuthForms from "@/components/auth/AuthForms";

export const metadata: Metadata = {
  title: "Set Sail (Login) — One Piece Fan Wiki",
  description: "Board the Thousand Sunny and access your personal Reading Tracker, Watch Tracker, and gamified achievements room.",
};

export default function SignInPage() {
  return <AuthForms initialView="signin" />;
}
