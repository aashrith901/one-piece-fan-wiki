import React from "react";
import type { Metadata } from "next";
import AuthForms from "@/components/auth/AuthForms";

export const metadata: Metadata = {
  title: "Verify Transponder Snail — One Piece Fan Wiki",
  description: "Enter your one-time email encryption verification token to successfully set sail on the Grand Line platform.",
};

export default function VerifyEmailPage() {
  return <AuthForms initialView="verify" />;
}
