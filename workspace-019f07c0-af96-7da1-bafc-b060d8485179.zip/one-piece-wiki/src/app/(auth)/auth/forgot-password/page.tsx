import React from "react";
import type { Metadata } from "next";
import AuthForms from "@/components/auth/AuthForms";

export const metadata: Metadata = {
  title: "Recover Encrypted Cipher — One Piece Fan Wiki",
  description: "Broadcast an encrypted password reset transponder snail token to recover your pirate fleet credentials.",
};

export default function ForgotPasswordPage() {
  return <AuthForms initialView="forgot" />;
}
