import React from "react";
import type { Metadata } from "next";
import AuthForms from "@/components/auth/AuthForms";

export const metadata: Metadata = {
  title: "Establish Pirate Fleet (Signup) — One Piece Fan Wiki",
  description: "Join 48,920+ active community Admirals. Track your anime watching progress, bookmark lore dossiers, and vote in live polls.",
};

export default function SignUpPage() {
  return <AuthForms initialView="signup" />;
}
