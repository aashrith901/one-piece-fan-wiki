import React from "react";
import type { Metadata } from "next";
import BountyStudioMain from "@/components/bounty/BountyStudioMain";

export const metadata: Metadata = {
  title: "Ultimate Bounty Poster Studio — One Piece Fan Wiki",
  description: "Craft Canva-quality bounty posters with full vector layer manipulation, custom image uploads, burn mark decals, wax seals, and high-resolution PDF/SVG export support.",
};

export default function BountyGeneratorPage() {
  return <BountyStudioMain />;
}
