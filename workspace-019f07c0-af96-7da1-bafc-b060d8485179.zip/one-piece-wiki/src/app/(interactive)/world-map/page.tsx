import React from "react";
import type { Metadata } from "next";
import WorldMapExplorer from "@/components/interactive/WorldMapExplorer";

export const metadata: Metadata = {
  title: "Interactive 3D Grand Line World Map — One Piece Fan Wiki",
  description: "Navigate the Four Blues, Grand Line, and New World with our interactive 3D navigation table. Track glowing sea routes for the Straw Hats, Roger Pirates, Marines, and Yonko.",
};

export default function WorldMapPage() {
  return <WorldMapExplorer />;
}
