"use client";

import React from "react";
import { ErrorComponent } from "@/components/ui/feedback";
import { PremiumNavbar, MobileNavbar, Footer } from "@/components/navigation/navigation-system";

export default function MaintenancePage() {
  return (
    <div className="w-full min-h-screen bg-background flex flex-col justify-between">
      <PremiumNavbar onOpenSearch={() => {}} />
      <MobileNavbar onOpenSearch={() => {}} />
      <div className="flex-grow flex items-center justify-center">
        <ErrorComponent
          title="MARY GEOISE CENTRAL REPOSITORY MAINTENANCE"
          message="The Gorosei are actively executing an enterprise-grade database migration and CDN edge optimization routine. Den den mushi broadcast frequencies will resume shortly."
          onRetry={() => (window.location.href = "/")}
        />
      </div>
      <Footer />
    </div>
  );
}
