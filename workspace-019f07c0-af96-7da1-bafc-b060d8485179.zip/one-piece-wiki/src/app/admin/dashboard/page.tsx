import React from "react";
import type { Metadata } from "next";
import GoroseiAdminDashboard from "@/components/admin/GoroseiAdminDashboard";

export const metadata: Metadata = {
  title: "Master Admin CMS & Analytics Dashboard — One Piece Fan Wiki",
  description: "Manage user roles, inspect search analytics, configure homepage hero layouts, review audit logs, and capture encrypted database backups.",
};

export default function AdminDashboardPage() {
  return <GoroseiAdminDashboard />;
}
