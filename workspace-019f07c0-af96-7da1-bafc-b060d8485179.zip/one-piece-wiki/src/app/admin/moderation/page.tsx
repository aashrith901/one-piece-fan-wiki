import React from "react";
import type { Metadata } from "next";
import ModeratorDashboard from "@/components/community/ModeratorDashboard";

export const metadata: Metadata = {
  title: "Gorosei Moderation Engine — One Piece Fan Wiki",
  description: "Review reported transponder snail broadcasts, manage active Buster Call bans, and pin global announcements.",
};

export default function ModerationPage() {
  return <ModeratorDashboard />;
}
