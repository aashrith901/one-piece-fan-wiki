"use client";

import React from "react";
import { NotFoundComponent } from "@/components/ui/feedback";
import { PremiumNavbar, MobileNavbar, Footer } from "@/components/navigation/navigation-system";

export default function GlobalNotFoundPage() {
  return (
    <div className="w-full min-h-screen bg-background flex flex-col justify-between">
      <PremiumNavbar onOpenSearch={() => {}} />
      <MobileNavbar onOpenSearch={() => {}} />
      <div className="flex-grow flex items-center justify-center">
        <NotFoundComponent onBack={() => (window.location.href = "/")} />
      </div>
      <Footer />
    </div>
  );
}
