import React from "react";
import type { Metadata } from "next";
import UserSettingsView from "@/components/profile/UserSettingsView";

interface PageProps {
  params: Promise<{ username: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const resolvedParams = await params;
  return {
    title: `Fleet Configuration & Ciphers — Admiral ${resolvedParams.username} | One Piece Fan Wiki`,
    description: `Manage active session tokens, two-factor authentication ciphers, connected OAuth providers, and global accessibility modes.`,
  };
}

export default async function SettingsPage({ params }: PageProps) {
  const resolvedParams = await params;
  return <UserSettingsView username={resolvedParams.username} />;
}
