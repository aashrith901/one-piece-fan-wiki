import React from "react";
import type { Metadata } from "next";
import UserProfileView from "@/components/profile/UserProfileView";

interface PageProps {
  params: Promise<{ username: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const resolvedParams = await params;
  return {
    title: `Admiral ${resolvedParams.username} — Fleet Profile | One Piece Fan Wiki`,
    description: `Inspect the official Grand Line dossier, reputation score, hall of favorites, and activity log for Admiral ${resolvedParams.username}.`,
  };
}

export default async function ProfilePage({ params }: PageProps) {
  const resolvedParams = await params;
  return <UserProfileView username={resolvedParams.username} />;
}
