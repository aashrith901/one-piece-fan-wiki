import React from "react";
import type { Metadata } from "next";
import TrackerDashboard from "@/components/profile/TrackerDashboard";

interface PageProps {
  params: Promise<{ username: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const resolvedParams = await params;
  return {
    title: `Synced Tracker Hub — Admiral ${resolvedParams.username} | One Piece Fan Wiki`,
    description: `Inspect the anime watch progress, manga reading logs, and gamified achievement trophy room for Admiral ${resolvedParams.username}.`,
  };
}

export default async function TrackerPage({ params }: PageProps) {
  const resolvedParams = await params;
  return <TrackerDashboard username={resolvedParams.username} />;
}
