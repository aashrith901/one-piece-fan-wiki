import { create } from "zustand";
import { BountyCanvasLayer } from "@/lib/validations";

// ============================================================================
// CANVA-GRADE BOUNTY STUDIO ZUSTAND STORE
// ============================================================================

export interface BountyStudioState {
  // Project Metadata
  projectId: string;
  projectTitle: string;
  characterName: string;
  bountyAmount: string;
  templateId: number;
  folder: string;
  isFavorite: boolean;

  // Editor Parameters
  zoom: number; // e.g., 1 for 100%, 0.5 for 50%
  panX: number;
  panY: number;
  snapToGrid: boolean;
  showSmartGuides: boolean;
  showRulers: boolean;
  activeLayerId: string | null;

  // Layers Array & Undo/Redo Stacks
  layers: BountyCanvasLayer[];
  undoStack: BountyCanvasLayer[][];
  redoStack: BountyCanvasLayer[][];
  lastSaved: string;
  isDirty: boolean;

  // Actions
  setProjectMetadata: (metadata: Partial<BountyStudioState>) => void;
  setEditorParam: (param: Partial<BountyStudioState>) => void;
  setActiveLayerId: (id: string | null) => void;

  // Layer Manipulation
  addLayer: (layer: Omit<BountyCanvasLayer, "id" | "zIndex">) => void;
  updateLayer: (id: string, updates: Partial<BountyCanvasLayer>) => void;
  duplicateLayer: (id: string) => void;
  deleteLayer: (id: string) => void;
  reorderLayer: (id: string, direction: "up" | "down" | "top" | "bottom") => void;
  toggleLayerLock: (id: string) => void;
  toggleLayerVisibility: (id: string) => void;

  // History & Persistence
  undo: () => void;
  redo: () => void;
  pushHistory: () => void;
  resetToTemplate: (templateLayers: BountyCanvasLayer[]) => void;
}

const defaultInitialLayers: BountyCanvasLayer[] = [
  { id: "bg_1", type: "border", name: "Ancient Parchment Base", x: 0, y: 0, width: 800, height: 1120, rotation: 0, scaleX: 1, scaleY: 1, opacity: 1, visible: true, locked: true, zIndex: 1, content: "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?q=80&w=1200&auto=format&fit=crop" },
  { id: "img_1", type: "image", name: "Luffy Cover Photo", x: 95, y: 220, width: 610, height: 490, rotation: 0, scaleX: 1, scaleY: 1, opacity: 1, visible: true, locked: false, zIndex: 2, content: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=800&auto=format&fit=crop", filterConfig: { sepia: 0.2, contrast: 1.1, brightness: 1.05, scratchIntensity: 0.1, burnIntensity: 0.2, tornEdgeIntensity: 0 } },
  { id: "txt_wanted", type: "text", name: "WANTED HEADER", x: 100, y: 80, width: 600, height: 120, rotation: 0, scaleX: 1, scaleY: 1, opacity: 1, visible: true, locked: false, zIndex: 3, content: "WANTED", fontFamily: "Cinzel", fontSize: 110, color: "#2b180d", letterSpacing: 15 },
  { id: "txt_name", type: "text", name: "CHARACTER ALIAS", x: 100, y: 750, width: 600, height: 90, rotation: 0, scaleX: 1, scaleY: 1, opacity: 1, visible: true, locked: false, zIndex: 4, content: "MONKEY D. LUFFY", fontFamily: "Pirata One", fontSize: 75, color: "#2b180d", letterSpacing: 5 },
  { id: "txt_bounty", type: "text", name: "BOUNTY AMOUNT", x: 100, y: 880, width: 600, height: 90, rotation: 0, scaleX: 1, scaleY: 1, opacity: 1, visible: true, locked: false, zIndex: 5, content: "฿ 3,000,000,000", fontFamily: "JetBrains Mono", fontSize: 65, color: "#2b180d", letterSpacing: 3 },
  { id: "eff_burn", type: "filter", name: "Burned Edge Decal", x: 20, y: 20, width: 760, height: 1080, rotation: 0, scaleX: 1, scaleY: 1, opacity: 0.85, visible: true, locked: true, zIndex: 6, content: "burnt_edge_overlay" },
  { id: "seal_1", type: "seal", name: "Marine Wax Seal", x: 620, y: 950, width: 130, height: 130, rotation: -15, scaleX: 1, scaleY: 1, opacity: 0.95, visible: true, locked: false, zIndex: 7, content: "marine_red_seal" },
];

export const useBountyStudioStore = create<BountyStudioState>((set, get) => ({
  projectId: "proj_1",
  projectTitle: "Emperor Luffy Wanted Poster",
  characterName: "Monkey D. Luffy",
  bountyAmount: "3,000,000,000",
  templateId: 1,
  folder: "Emperor Fleet",
  isFavorite: true,

  zoom: 1,
  panX: 0,
  panY: 0,
  snapToGrid: true,
  showSmartGuides: true,
  showRulers: true,
  activeLayerId: "img_1",

  layers: defaultInitialLayers,
  undoStack: [],
  redoStack: [],
  lastSaved: new Date().toISOString(),
  isDirty: false,

  setProjectMetadata: (meta) => set((state) => ({ ...state, ...meta, isDirty: true })),
  setEditorParam: (param) => set((state) => ({ ...state, ...param })),
  setActiveLayerId: (id) => set({ activeLayerId: id }),

  pushHistory: () => {
    const current = get().layers;
    const undo = [...get().undoStack, JSON.parse(JSON.stringify(current))];
    // Cap history at 30 actions
    if (undo.length > 30) undo.shift();
    set({ undoStack: undo, redoStack: [], isDirty: true });
  },

  addLayer: (layer) => {
    get().pushHistory();
    const id = `layer_${Date.now()}`;
    const zIndex = get().layers.length + 1;
    const fullLayer: BountyCanvasLayer = { ...layer, id, zIndex, scaleX: 1, scaleY: 1, opacity: 1, visible: true, locked: false };
    set((state) => ({ layers: [...state.layers, fullLayer], activeLayerId: id }));
  },

  updateLayer: (id, updates) => {
    get().pushHistory();
    set((state) => ({
      layers: state.layers.map((l) => (l.id === id ? { ...l, ...updates } : l)),
    }));
  },

  duplicateLayer: (id) => {
    get().pushHistory();
    const target = get().layers.find((l) => l.id === id);
    if (!target) return;
    const newId = `layer_${Date.now()}`;
    const duplicate: BountyCanvasLayer = { ...target, id: newId, name: `${target.name} (Copy)`, zIndex: get().layers.length + 1, x: target.x + 20, y: target.y + 20 };
    set((state) => ({ layers: [...state.layers, duplicate], activeLayerId: newId }));
  },

  deleteLayer: (id) => {
    get().pushHistory();
    set((state) => ({
      layers: state.layers.filter((l) => l.id !== id),
      activeLayerId: state.activeLayerId === id ? null : state.activeLayerId,
    }));
  },

  reorderLayer: (id, direction) => {
    get().pushHistory();
    const layers = [...get().layers];
    const idx = layers.findIndex((l) => l.id === id);
    if (idx === -1) return;

    const [target] = layers.splice(idx, 1);

    if (direction === "up") {
      layers.splice(Math.min(layers.length, idx + 1), 0, target);
    } else if (direction === "down") {
      layers.splice(Math.max(0, idx - 1), 0, target);
    } else if (direction === "top") {
      layers.push(target);
    } else if (direction === "bottom") {
      layers.unshift(target);
    }

    // Re-assign zIndexes
    const reordered = layers.map((l, i) => ({ ...l, zIndex: i + 1 }));
    set({ layers: reordered });
  },

  toggleLayerLock: (id) => {
    set((state) => ({
      layers: state.layers.map((l) => (l.id === id ? { ...l, locked: !l.locked } : l)),
    }));
  },

  toggleLayerVisibility: (id) => {
    set((state) => ({
      layers: state.layers.map((l) => (l.id === id ? { ...l, visible: !l.visible } : l)),
    }));
  },

  undo: () => {
    const undoStack = [...get().undoStack];
    if (undoStack.length === 0) return;
    const previous = undoStack.pop()!;
    const current = get().layers;
    set({ layers: previous, undoStack, redoStack: [...get().redoStack, JSON.parse(JSON.stringify(current))], isDirty: true });
  },

  redo: () => {
    const redoStack = [...get().redoStack];
    if (redoStack.length === 0) return;
    const next = redoStack.pop()!;
    const current = get().layers;
    set({ layers: next, undoStack: [...get().undoStack, JSON.parse(JSON.stringify(current))], redoStack, isDirty: true });
  },

  resetToTemplate: (templateLayers) => {
    get().pushHistory();
    set({ layers: templateLayers, activeLayerId: templateLayers[1]?.id || null });
  },
}));
