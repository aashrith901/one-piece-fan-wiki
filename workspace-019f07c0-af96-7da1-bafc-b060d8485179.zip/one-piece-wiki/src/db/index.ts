import { drizzle } from 'drizzle-orm/neon-http';
import { neon, neonConfig } from '@neondatabase/serverless';
import * as schema from './schema';

// Enable caching of connections in serverless environments
neonConfig.fetchConnectionCache = true;

// ============================================================================
// RESILIENT SERVERLESS CONNECTION POOL MANAGER
// ============================================================================

const dbUrl = process.env.DATABASE_URL || 'postgres://gorosei:marygeoisepass@ep-calm-sea-123456.us-east-1.aws.neon.tech/onepiece?sslmode=require';

let sqlClient: any;
try {
  sqlClient = neon(dbUrl);
} catch (err) {
  // Graceful proxy fallback for static build or preview environment execution without active DB variables
  sqlClient = async (query: string, params?: any[]) => {
    console.warn('[Drizzle ORM Fallback] Simulating query in static build environment: ', query);
    return [];
  };
}

export const db = drizzle(sqlClient, { schema });
export * from './schema';
