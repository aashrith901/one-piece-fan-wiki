import {
  pgTable,
  serial,
  text,
  timestamp,
  integer,
  boolean,
  jsonb,
  primaryKey,
  foreignKey,
  uuid,
  real
} from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// ============================================================================
// 1. AUTHENTICATION & USER MANAGEMENT
// ============================================================================

export const users = pgTable('users', {
  id: uuid('id').defaultRandom().primaryKey(),
  name: text('name'),
  email: text('email').unique(),
  emailVerified: timestamp('email_verified', { mode: 'date' }),
  image: text('image'),
  role: text('role').default('fan').notNull(), // 'fan', 'super-fan', 'admiral', 'gorosei'
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

export const accounts = pgTable('accounts', {
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  type: text('type').notNull(),
  provider: text('provider').notNull(),
  providerAccountId: text('provider_account_id').notNull(),
  refresh_token: text('refresh_token'),
  access_token: text('access_token'),
  expires_at: integer('expires_at'),
  token_type: text('token_type'),
  scope: text('scope'),
  id_token: text('id_token'),
  session_state: text('session_state'),
}, (table) => ({
  pk: primaryKey({ columns: [table.provider, table.providerAccountId] }),
}));

export const sessions = pgTable('sessions', {
  sessionToken: text('session_token').primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  expires: timestamp('expires', { mode: 'date' }).notNull(),
});

export const verificationTokens = pgTable('verification_tokens', {
  identifier: text('identifier').notNull(),
  token: text('token').notNull(),
  expires: timestamp('expires', { mode: 'date' }).notNull(),
}, (table) => ({
  pk: primaryKey({ columns: [table.identifier, table.token] }),
}));

export const profiles = pgTable('profiles', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().unique().references(() => users.id, { onDelete: 'cascade' }),
  username: text('username').unique().notNull(),
  bio: text('bio').default(''),
  avatarUrl: text('avatar_url'),
  bannerUrl: text('banner_url'),
  factionAllegiance: text('faction_allegiance').default('Independent'), // Pirates, Marines, Revolutionaries, Cross Guild, Independent
  reputationScore: integer('reputation_score').default(0).notNull(),
  title: text('title').default('Rookie Pirate').notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

// ============================================================================
// 2. SOCIAL, TRACKERS & ACHIEVEMENTS
// ============================================================================

export const achievements = pgTable('achievements', {
  id: serial('id').primaryKey(),
  title: text('title').notNull().unique(),
  description: text('description').notNull(),
  badgeIconUrl: text('badge_icon_url').notNull(),
  category: text('category').notNull(), // 'Participation', 'Reading', 'Watching', 'Lore', 'Creator'
  xpReward: integer('xp_reward').default(100).notNull(),
  secret: boolean('secret').default(false).notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
});

export const userAchievements = pgTable('user_achievements', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  achievementId: integer('achievement_id').notNull().references(() => achievements.id, { onDelete: 'cascade' }),
  unlockedAt: timestamp('unlocked_at', { mode: 'date' }).defaultNow().notNull(),
});

export const userBookmarks = pgTable('user_bookmarks', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  entityType: text('entity_type').notNull(), // 'character', 'crew', 'devil_fruit', 'island', 'chapter', 'episode', etc.
  entitySlug: text('entity_slug').notNull(),
  title: text('title').notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
});

export const userFavorites = pgTable('user_favorites', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  entityType: text('entity_type').notNull(),
  entitySlug: text('entity_slug').notNull(),
  title: text('title').notNull(),
  imageUrl: text('image_url').notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
});

export const readingTracker = pgTable('reading_tracker', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  chapterId: integer('chapter_id').notNull(), // Referenced in manga_chapters
  status: text('status').notNull(), // 'completed', 'reading', 'plan_to_read', 'dropped'
  rating: integer('rating'), // 1-10
  notes: text('notes'),
  readAt: timestamp('read_at', { mode: 'date' }).defaultNow().notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

export const watchTracker = pgTable('watch_tracker', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  episodeId: integer('episode_id').notNull(), // Referenced in anime_episodes
  status: text('status').notNull(), // 'completed', 'watching', 'plan_to_watch', 'dropped'
  rating: integer('rating'), // 1-10
  notes: text('notes'),
  watchedAt: timestamp('watched_at', { mode: 'date' }).defaultNow().notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

// ============================================================================
// 3. UNIVERSE LORE ENTITIES (CHARACTERS, CREWS, FACTIONS, DEVIL FRUITS...)
// ============================================================================

export const characters = pgTable('characters', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  name: text('name').notNull(),
  japaneseName: text('japanese_name').notNull(),
  romanizedName: text('romanized_name').notNull(),
  epithet: text('epithet'),
  age: text('age'),
  birthday: text('birthday'),
  height: text('height'),
  bloodType: text('blood_type'),
  origin: text('origin'), // E.g. East Blue, Wano Country
  residence: text('residence'),
  status: text('status').default('Alive').notNull(), // 'Alive', 'Deceased', 'Unknown'
  coverImageUrl: text('cover_image_url').notNull(),
  thumbnailImageUrl: text('thumbnail_image_url').notNull(),
  biography: text('biography').notNull(),
  personality: text('personality').notNull(),
  appearance: text('appearance').notNull(),
  combatStyle: text('combat_style').notNull(),
  statPower: integer('stat_power').default(1).notNull(),
  statSpeed: integer('stat_speed').default(1).notNull(),
  statTechnique: integer('stat_technique').default(1).notNull(),
  statIntelligence: integer('stat_intelligence').default(1).notNull(),
  statHaki: integer('stat_haki').default(1).notNull(),
  isDevilFruitUser: boolean('is_devil_fruit_user').default(false).notNull(),
  devilFruitId: integer('devil_fruit_id'), // Referenced in devil_fruits
  hasConquerorsHaki: boolean('has_conquerors_haki').default(false).notNull(),
  hasArmamentHaki: boolean('has_armament_haki').default(false).notNull(),
  hasObservationHaki: boolean('has_observation_haki').default(false).notNull(),
  bounty: text('bounty'), // Formatted large text representation, e.g. "3,000,000,000"
  numericBounty: real('numeric_bounty'), // For sorting purposes
  primaryCrewId: integer('primary_crew_id'), // Referenced in crews
  primaryFactionId: integer('primary_faction_id'), // Referenced in factions
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

export const crews = pgTable('crews', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  name: text('name').notNull(),
  japaneseName: text('japanese_name').notNull(),
  romanizedName: text('romanized_name').notNull(),
  status: text('status').default('Active').notNull(), // 'Active', 'Disbanded', 'Unknown'
  totalBounty: text('total_bounty'),
  jollyRogerUrl: text('jolly_roger_url').notNull(),
  shipId: integer('ship_id'), // Referenced in ships
  flagshipName: text('flagship_name'),
  summary: text('summary').notNull(),
  history: text('history').notNull(),
  goals: text('goals').notNull(),
  captainId: integer('captain_id'), // Referenced in characters
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

export const crewMembers = pgTable('crew_members', {
  id: serial('id').primaryKey(),
  crewId: integer('crew_id').notNull().references(() => crews.id, { onDelete: 'cascade' }),
  characterId: integer('character_id').notNull().references(() => characters.id, { onDelete: 'cascade' }),
  role: text('role').notNull(), // e.g., 'Captain', 'Vice Captain', 'Navigator', 'Sniper', 'Combatant'
  joinOrder: integer('join_order'),
  currentStatus: text('current_status').default('Active').notNull(), // 'Active', 'Former', 'Deceased'
});

export const factions = pgTable('factions', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  name: text('name').notNull(), // e.g., 'Marines', 'Yonko', 'Revolutionary Army', 'Cross Guild', 'World Government'
  japaneseName: text('japanese_name').notNull(),
  logoUrl: text('logo_url').notNull(),
  type: text('type').notNull(), // 'Marine', 'Pirate Faction', 'World Government', 'Underworld'
  leaderId: integer('leader_id'), // Referenced in characters
  headquarters: text('headquarters'),
  summary: text('summary').notNull(),
  ideology: text('ideology').notNull(),
  history: text('history').notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

export const factionMembers = pgTable('faction_members', {
  id: serial('id').primaryKey(),
  factionId: integer('faction_id').notNull().references(() => factions.id, { onDelete: 'cascade' }),
  characterId: integer('character_id').notNull().references(() => characters.id, { onDelete: 'cascade' }),
  rankOrTitle: text('rank_or_title').notNull(), // e.g., 'Fleet Admiral', 'Emperor', 'Commander'
  isLeader: boolean('is_leader').default(false).notNull(),
});

export const devilFruits = pgTable('devil_fruits', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  name: text('name').notNull(),
  japaneseName: text('japanese_name').notNull(),
  romanizedName: text('romanized_name').notNull(),
  meaning: text('meaning').notNull(), // e.g., "Rubber", "Tremor"
  type: text('type').notNull(), // 'Paramecia', 'Zoan', 'Logia', 'Ancient Zoan', 'Mythical Zoan', 'Artificial'
  currentUserId: integer('current_user_id'), // Referenced in characters
  previousUserId: integer('previous_user_id'), // Referenced in characters
  appearanceDescription: text('appearance_description'),
  imageUrl: text('image_url'),
  abilitiesAndUsage: text('abilities_and_usage').notNull(),
  awakeningDescription: text('awakening_description'),
  hasKnownAwakening: boolean('has_known_awakening').default(false).notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

export const hakiTypes = pgTable('haki_types', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  name: text('name').notNull(), // 'Conqueror's Haki', 'Armament Haki', 'Observation Haki'
  japaneseName: text('japanese_name').notNull(),
  colorAccent: text('color_accent').notNull(),
  summary: text('summary').notNull(),
  advancedApplications: text('advanced_applications').notNull(), // e.g., Internal Destruction, Future Sight, Infusion
  limitations: text('limitations').notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
});

export const weapons = pgTable('weapons', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  name: text('name').notNull(),
  japaneseName: text('japanese_name').notNull(),
  type: text('type').notNull(), // 'Sword', 'Gun', 'Polearm', 'Clima-Tact', 'Special'
  grade: text('grade'), // 'Supreme Grade', 'Great Grade', 'Skillful Grade', 'Meito', 'Unknown'
  ownerId: integer('owner_id'), // Referenced in characters
  creator: text('creator'),
  imageUrl: text('image_url').notNull(),
  summary: text('summary').notNull(),
  abilities: text('abilities').notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

export const ships = pgTable('ships', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  name: text('name').notNull(),
  japaneseName: text('japanese_name').notNull(),
  affiliationId: integer('affiliation_id'), // Referenced in crews or factions
  shipwright: text('shipwright'),
  model3dUrl: text('model_3d_url'), // glTF/GLB path
  coverImageUrl: text('cover_image_url').notNull(),
  designAndAppearance: text('design_and_appearance').notNull(),
  armamentAndFeatures: text('armament_and_features').notNull(),
  destroyed: boolean('destroyed').default(false).notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

export const islands = pgTable('islands', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  name: text('name').notNull(),
  japaneseName: text('japanese_name').notNull(),
  region: text('region').notNull(), // 'East Blue', 'Grand Line', 'New World', 'Sky Island', 'Undersea'
  climate: text('climate'), // 'Summer Island', 'Winter Island', 'Various', etc.
  logPoseLockTime: text('log_pose_lock_time'),
  affiliation: text('affiliation'), // World Government, Yonko territory, Independent
  rulerId: integer('ruler_id'), // Referenced in characters
  coverImageUrl: text('cover_image_url').notNull(),
  mapCoordX: real('map_coord_x').notNull(), // For the 3D Interactive Map
  mapCoordY: real('map_coord_y').notNull(),
  mapCoordZ: real('map_coord_z').notNull(),
  history: text('history').notNull(),
  cultureAndSociety: text('culture_and_society').notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

export const characterRelationships = pgTable('character_relationships', {
  id: serial('id').primaryKey(),
  characterId: integer('character_id').notNull().references(() => characters.id, { onDelete: 'cascade' }),
  relatedCharacterId: integer('related_character_id').notNull().references(() => characters.id, { onDelete: 'cascade' }),
  relationType: text('relation_type').notNull(), // 'Allied', 'Enemy', 'Family', 'Crewmate', 'Rival', 'Mentor'
  notes: text('notes'),
});

// ============================================================================
// 4. MEDIA, PUBLICATIONS & NEWS
// ============================================================================

export const mangaChapters = pgTable('manga_chapters', {
  id: serial('id').primaryKey(),
  chapterNumber: integer('chapter_number').notNull().unique(),
  title: text('title').notNull(),
  volumeNumber: integer('volume_number').notNull(),
  releaseDate: timestamp('release_date', { mode: 'date' }).notNull(),
  summary: text('summary').notNull(),
  coverStoryTitle: text('cover_story_title'),
  coverStorySummary: text('cover_story_summary'),
  thumbnailUrl: text('thumbnail_url').notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
});

export const animeEpisodes = pgTable('anime_episodes', {
  id: serial('id').primaryKey(),
  episodeNumber: integer('episode_number').notNull().unique(),
  title: text('title').notNull(),
  arc: text('arc').notNull(), // e.g., 'Wano Country Arc', 'Egghead Arc'
  isFiller: boolean('is_filler').default(false).notNull(),
  releaseDate: timestamp('release_date', { mode: 'date' }).notNull(),
  summary: text('summary').notNull(),
  thumbnailUrl: text('thumbnail_url').notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
});

export const movies = pgTable('movies', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  title: text('title').notNull(),
  japaneseTitle: text('japanese_title').notNull(),
  releaseDate: timestamp('release_date', { mode: 'date' }).notNull(),
  director: text('director'),
  boxOffice: text('box_office'),
  synopsis: text('synopsis').notNull(),
  coverImageUrl: text('cover_image_url').notNull(),
  canonStatus: text('canon_status').default('Non-Canon').notNull(), // 'Canon', 'Non-Canon', 'Mixed'
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
});

export const newsArticles = pgTable('news_articles', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  title: text('title').notNull(),
  excerpt: text('excerpt').notNull(),
  content: text('content').notNull(),
  coverImageUrl: text('cover_image_url').notNull(),
  authorId: uuid('author_id').notNull().references(() => users.id),
  category: text('category').default('General').notNull(), // 'Manga', 'Anime', 'Live Action', 'Merchandise', 'Events'
  publishedAt: timestamp('published_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

// ============================================================================
// 5. COMMUNITY FORUMS, COMMENTS, POLLS & RATINGS
// ============================================================================

export const comments = pgTable('comments', {
  id: serial('id').primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  entityType: text('entity_type').notNull(), // 'character', 'chapter', 'episode', 'news', 'bounty', etc.
  entitySlug: text('entity_slug').notNull(),
  parentId: integer('parent_id'), // For nested comment replies
  content: text('content').notNull(),
  upvotes: integer('upvotes').default(0).notNull(),
  downvotes: integer('downvotes').default(0).notNull(),
  isEdited: boolean('is_edited').default(false).notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

export const discussionThreads = pgTable('discussion_threads', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  title: text('title').notNull(),
  category: text('category').notNull(), // 'Lore', 'Theories', 'Episode Discussions', 'Manga Discussions', 'General'
  authorId: uuid('author_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  content: text('content').notNull(),
  pinned: boolean('pinned').default(false).notNull(),
  locked: boolean('locked').default(false).notNull(),
  viewCount: integer('view_count').default(0).notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

export const discussionPosts = pgTable('discussion_posts', {
  id: serial('id').primaryKey(),
  threadId: integer('thread_id').notNull().references(() => discussionThreads.id, { onDelete: 'cascade' }),
  authorId: uuid('author_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  content: text('content').notNull(),
  upvotes: integer('upvotes').default(0).notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

export const polls = pgTable('polls', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  question: text('question').notNull(),
  description: text('description'),
  authorId: uuid('author_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  isActive: boolean('is_active').default(true).notNull(),
  expiresAt: timestamp('expires_at', { mode: 'date' }),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
});

export const pollOptions = pgTable('poll_options', {
  id: serial('id').primaryKey(),
  pollId: integer('poll_id').notNull().references(() => polls.id, { onDelete: 'cascade' }),
  optionText: text('option_text').notNull(),
  imageUrl: text('image_url'),
  voteCount: integer('vote_count').default(0).notNull(),
});

export const pollVotes = pgTable('poll_votes', {
  id: uuid('id').defaultRandom().primaryKey(),
  pollId: integer('poll_id').notNull().references(() => polls.id, { onDelete: 'cascade' }),
  optionId: integer('option_id').notNull().references(() => pollOptions.id, { onDelete: 'cascade' }),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  votedAt: timestamp('voted_at', { mode: 'date' }).defaultNow().notNull(),
});

export const ratings = pgTable('ratings', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  entityType: text('entity_type').notNull(), // 'character', 'episode', 'chapter', 'movie'
  entitySlug: text('entity_slug').notNull(),
  score: integer('score').notNull(), // 1 to 10
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
});

// ============================================================================
// 6. SPECIAL ADVANCED FEATURE: BOUNTY POSTER GENERATOR ENGINE
// ============================================================================

export const bounties = pgTable('bounties', {
  id: serial('id').primaryKey(),
  characterId: integer('character_id').notNull().references(() => characters.id, { onDelete: 'cascade' }),
  bountyAmount: text('bounty_amount').notNull(), // e.g., "1,500,000,000"
  status: text('status').default('Active').notNull(), // 'Active', 'Former', 'Frozen', 'Revoked'
  posterImageUrl: text('poster_image_url').notNull(),
  issueDate: timestamp('issue_date', { mode: 'date' }),
  notes: text('notes'),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
});

export const bountyTemplates = pgTable('bounty_templates', {
  id: serial('id').primaryKey(),
  name: text('name').notNull().unique(), // e.g., 'Pre-Timeskip Marine Classic', 'New World Ancient Parchment', 'Cross Guild Marine Bounty'
  description: text('description').notNull(),
  baseBackgroundImageUrl: text('base_background_image_url').notNull(),
  canvasConfig: jsonb('canvas_config').notNull(), // Default layers, positions, bounding boxes, text font configs
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
});

export const userCustomBounties = pgTable('user_custom_bounties', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  title: text('title').notNull(),
  characterName: text('character_name').notNull(),
  bountyAmount: text('bounty_amount').notNull(),
  templateId: integer('template_id').notNull().references(() => bountyTemplates.id, { onDelete: 'cascade' }),
  layersData: jsonb('layers_data').notNull(), // Full JSON tree representing drag, resize, rotate, crop, filters, torn edges, burn effects
  exportedImageUrl: text('exported_image_url'),
  isPublic: boolean('is_public').default(true).notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { mode: 'date' }).defaultNow().notNull(),
});

// ============================================================================
// 7. DRIZZLE ORM RELATIONS DEFINITIONS
// ============================================================================

export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(profiles, { fields: [users.id], references: [profiles.userId] }),
  accounts: many(accounts),
  sessions: many(sessions),
  achievements: many(userAchievements),
  bookmarks: many(userBookmarks),
  favorites: many(userFavorites),
  mangaTracking: many(readingTracker),
  animeTracking: many(watchTracker),
  customBounties: many(userCustomBounties),
  comments: many(comments),
  discussionThreads: many(discussionThreads),
  discussionPosts: many(discussionPosts),
  pollVotes: many(pollVotes),
  ratings: many(ratings),
}));

export const charactersRelations = relations(characters, ({ one, many }) => ({
  crew: one(crews, { fields: [characters.primaryCrewId], references: [crews.id] }),
  faction: one(factions, { fields: [characters.primaryFactionId], references: [factions.id] }),
  devilFruit: one(devilFruits, { fields: [characters.devilFruitId], references: [devilFruits.id] }),
  bounties: many(bounties),
  crewMemberships: many(crewMembers),
  factionMemberships: many(factionMembers),
  relationships: many(characterRelationships, { relationName: 'baseCharacter' }),
  relatedRelationships: many(characterRelationships, { relationName: 'relatedCharacter' }),
}));

export const crewsRelations = relations(crews, ({ one, many }) => ({
  captain: one(characters, { fields: [crews.captainId], references: [characters.id] }),
  ship: one(ships, { fields: [crews.shipId], references: [ships.id] }),
  members: many(crewMembers),
}));

export const factionsRelations = relations(factions, ({ one, many }) => ({
  leader: one(characters, { fields: [factions.leaderId], references: [characters.id] }),
  members: many(factionMembers),
}));

export const characterRelationshipsRelations = relations(characterRelationships, ({ one }) => ({
  character: one(characters, { fields: [characterRelationships.characterId], references: [characters.id], relationName: 'baseCharacter' }),
  relatedCharacter: one(characters, { fields: [characterRelationships.relatedCharacterId], references: [characters.id], relationName: 'relatedCharacter' }),
}));

export const commentsRelations = relations(comments, ({ one, many }) => ({
  author: one(users, { fields: [comments.userId], references: [users.id] }),
  parent: one(comments, { fields: [comments.parentId], references: [comments.id], relationName: 'replies' }),
  replies: many(comments, { relationName: 'replies' }),
}));

export const pollsRelations = relations(polls, ({ one, many }) => ({
  author: one(users, { fields: [polls.authorId], references: [users.id] }),
  options: many(pollOptions),
  votes: many(pollVotes),
}));

export const pollOptionsRelations = relations(pollOptions, ({ one, many }) => ({
  poll: one(polls, { fields: [pollOptions.pollId], references: [polls.id] }),
  votes: many(pollVotes),
}));

export const pollVotesRelations = relations(pollVotes, ({ one }) => ({
  poll: one(polls, { fields: [pollVotes.pollId], references: [polls.id] }),
  option: one(pollOptions, { fields: [pollVotes.optionId], references: [pollOptions.id] }),
  user: one(users, { fields: [pollVotes.userId], references: [users.id] }),
}));

export const discussionThreadsRelations = relations(discussionThreads, ({ one, many }) => ({
  author: one(users, { fields: [discussionThreads.authorId], references: [users.id] }),
  posts: many(discussionPosts),
}));

export const discussionPostsRelations = relations(discussionPosts, ({ one }) => ({
  thread: one(discussionThreads, { fields: [discussionPosts.threadId], references: [discussionThreads.id] }),
  author: one(users, { fields: [discussionPosts.authorId], references: [users.id] }),
}));

export const userCustomBountiesRelations = relations(userCustomBounties, ({ one }) => ({
  user: one(users, { fields: [userCustomBounties.userId], references: [users.id] }),
  template: one(bountyTemplates, { fields: [userCustomBounties.templateId], references: [bountyTemplates.id] }),
}));
