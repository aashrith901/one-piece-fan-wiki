import { z } from 'zod';

// ============================================================================
// 1. USER & AUTHENTICATION SCHEMAS
// ============================================================================

export const userProfileSchema = z.object({
  username: z.string().min(3, 'Username must be at least 3 characters').max(30, 'Username cannot exceed 30 characters'),
  bio: z.string().max(500, 'Bio cannot exceed 500 characters').optional(),
  avatarUrl: z.string().url('Invalid avatar URL').optional(),
  bannerUrl: z.string().url('Invalid banner URL').optional(),
  factionAllegiance: z.enum(['Pirates', 'Marines', 'Revolutionaries', 'Cross Guild', 'Independent']).default('Independent'),
  title: z.string().max(50, 'Title cannot exceed 50 characters').optional(),
});

export type UserProfileInput = z.infer<typeof userProfileSchema>;

// ============================================================================
// 2. SOCIAL & TRACKER SCHEMAS
// ============================================================================

export const trackerReadingSchema = z.object({
  chapterId: z.number().int().positive('Invalid chapter ID'),
  status: z.enum(['completed', 'reading', 'plan_to_read', 'dropped']),
  rating: z.number().int().min(1).max(10).optional().nullable(),
  notes: z.string().max(1000, 'Notes cannot exceed 1000 characters').optional().nullable(),
});

export type TrackerReadingInput = z.infer<typeof trackerReadingSchema>;

export const trackerWatchSchema = z.object({
  episodeId: z.number().int().positive('Invalid episode ID'),
  status: z.enum(['completed', 'watching', 'plan_to_watch', 'dropped']),
  rating: z.number().int().min(1).max(10).optional().nullable(),
  notes: z.string().max(1000, 'Notes cannot exceed 1000 characters').optional().nullable(),
});

export type TrackerWatchInput = z.infer<typeof trackerWatchSchema>;

export const bookmarkSchema = z.object({
  entityType: z.enum(['character', 'crew', 'devil_fruit', 'island', 'chapter', 'episode', 'faction', 'ship', 'weapon', 'haki', 'movie', 'news']),
  entitySlug: z.string().min(1, 'Entity slug is required'),
  title: z.string().min(1, 'Title is required'),
});

export type BookmarkInput = z.infer<typeof bookmarkSchema>;

export const favoriteSchema = bookmarkSchema.extend({
  imageUrl: z.string().url('Invalid image URL'),
});

export type FavoriteInput = z.infer<typeof favoriteSchema>;

// ============================================================================
// 3. UNIVERSE LORE ENTITY VALIDATION SCHEMAS
// ============================================================================

export const characterSchema = z.object({
  slug: z.string().min(1, 'Slug is required'),
  name: z.string().min(1, 'Name is required'),
  japaneseName: z.string().min(1, 'Japanese name is required'),
  romanizedName: z.string().min(1, 'Romanized name is required'),
  epithet: z.string().optional().nullable(),
  age: z.string().optional().nullable(),
  birthday: z.string().optional().nullable(),
  height: z.string().optional().nullable(),
  bloodType: z.string().optional().nullable(),
  origin: z.string().optional().nullable(),
  residence: z.string().optional().nullable(),
  status: z.enum(['Alive', 'Deceased', 'Unknown']).default('Alive'),
  coverImageUrl: z.string().url('Invalid cover image URL'),
  thumbnailImageUrl: z.string().url('Invalid thumbnail image URL'),
  biography: z.string().min(10, 'Biography must be at least 10 characters'),
  personality: z.string().min(10, 'Personality description must be at least 10 characters'),
  appearance: z.string().min(10, 'Appearance description must be at least 10 characters'),
  combatStyle: z.string().min(10, 'Combat style description must be at least 10 characters'),
  statPower: z.number().int().min(1).max(100).default(1),
  statSpeed: z.number().int().min(1).max(100).default(1),
  statTechnique: z.number().int().min(1).max(100).default(1),
  statIntelligence: z.number().int().min(1).max(100).default(1),
  statHaki: z.number().int().min(1).max(100).default(1),
  isDevilFruitUser: z.boolean().default(false),
  devilFruitId: z.number().int().positive().optional().nullable(),
  hasConquerorsHaki: z.boolean().default(false),
  hasArmamentHaki: z.boolean().default(false),
  hasObservationHaki: z.boolean().default(false),
  bounty: z.string().optional().nullable(),
  numericBounty: z.number().positive().optional().nullable(),
  primaryCrewId: z.number().int().positive().optional().nullable(),
  primaryFactionId: z.number().int().positive().optional().nullable(),
});

export type CharacterInput = z.infer<typeof characterSchema>;

export const crewSchema = z.object({
  slug: z.string().min(1, 'Slug is required'),
  name: z.string().min(1, 'Name is required'),
  japaneseName: z.string().min(1, 'Japanese name is required'),
  romanizedName: z.string().min(1, 'Romanized name is required'),
  status: z.enum(['Active', 'Disbanded', 'Unknown']).default('Active'),
  totalBounty: z.string().optional().nullable(),
  jollyRogerUrl: z.string().url('Invalid Jolly Roger URL'),
  shipId: z.number().int().positive().optional().nullable(),
  flagshipName: z.string().optional().nullable(),
  summary: z.string().min(10, 'Summary must be at least 10 characters'),
  history: z.string().min(10, 'History must be at least 10 characters'),
  goals: z.string().min(10, 'Goals must be at least 10 characters'),
  captainId: z.number().int().positive().optional().nullable(),
});

export type CrewInput = z.infer<typeof crewSchema>;

export const devilFruitSchema = z.object({
  slug: z.string().min(1, 'Slug is required'),
  name: z.string().min(1, 'Name is required'),
  japaneseName: z.string().min(1, 'Japanese name is required'),
  romanizedName: z.string().min(1, 'Romanized name is required'),
  meaning: z.string().min(1, 'Meaning is required'),
  type: z.enum(['Paramecia', 'Zoan', 'Logia', 'Ancient Zoan', 'Mythical Zoan', 'Artificial']),
  currentUserId: z.number().int().positive().optional().nullable(),
  previousUserId: z.number().int().positive().optional().nullable(),
  appearanceDescription: z.string().optional().nullable(),
  imageUrl: z.string().url().optional().nullable(),
  abilitiesAndUsage: z.string().min(10, 'Abilities description must be at least 10 characters'),
  awakeningDescription: z.string().optional().nullable(),
  hasKnownAwakening: z.boolean().default(false),
});

export type DevilFruitInput = z.infer<typeof devilFruitSchema>;

// ============================================================================
// 4. COMMUNITY FORUMS, POLLS & COMMENTS SCHEMAS
// ============================================================================

export const commentSchema = z.object({
  entityType: z.string().min(1, 'Entity type is required'),
  entitySlug: z.string().min(1, 'Entity slug is required'),
  parentId: z.number().int().positive().optional().nullable(),
  content: z.string().min(1, 'Comment cannot be empty').max(2000, 'Comment cannot exceed 2000 characters'),
});

export type CommentInput = z.infer<typeof commentSchema>;

export const discussionThreadSchema = z.object({
  slug: z.string().min(1, 'Slug is required'),
  title: z.string().min(5, 'Title must be at least 5 characters').max(150, 'Title cannot exceed 150 characters'),
  category: z.enum(['Lore', 'Theories', 'Episode Discussions', 'Manga Discussions', 'General']),
  content: z.string().min(20, 'Thread content must be at least 20 characters'),
});

export type DiscussionThreadInput = z.infer<typeof discussionThreadSchema>;

export const discussionPostSchema = z.object({
  threadId: z.number().int().positive('Invalid thread ID'),
  content: z.string().min(1, 'Post content cannot be empty').max(5000, 'Post content cannot exceed 5000 characters'),
});

export type DiscussionPostInput = z.infer<typeof discussionPostSchema>;

export const pollSchema = z.object({
  slug: z.string().min(1, 'Slug is required'),
  question: z.string().min(5, 'Question must be at least 5 characters').max(255, 'Question cannot exceed 255 characters'),
  description: z.string().max(1000, 'Description cannot exceed 1000 characters').optional().nullable(),
  options: z.array(z.object({
    optionText: z.string().min(1, 'Option text is required').max(100, 'Option text cannot exceed 100 characters'),
    imageUrl: z.string().url().optional().nullable(),
  })).min(2, 'A poll must have at least 2 options').max(10, 'A poll cannot exceed 10 options'),
  expiresInDays: z.number().int().min(1).max(30).optional().nullable(),
});

export type PollInput = z.infer<typeof pollSchema>;

// ============================================================================
// 5. SPECIAL ADVANCED FEATURE: BOUNTY POSTER SCHEMAS
// ============================================================================

export const bountyCanvasLayerSchema = z.object({
  id: z.string(),
  type: z.enum(['image', 'text', 'seal', 'stamp', 'filter', 'watermark', 'border']),
  name: z.string(),
  x: z.number(),
  y: z.number(),
  width: z.number(),
  height: z.number(),
  rotation: z.number(), // in degrees
  scaleX: z.number().default(1),
  scaleY: z.number().default(1),
  opacity: z.number().min(0).max(1).default(1),
  visible: z.boolean().default(true),
  locked: z.boolean().default(false),
  zIndex: z.number().int(),
  // Type specific parameters
  content: z.string().optional(), // For text layers or image URLs
  fontFamily: z.string().optional(),
  fontSize: z.number().optional(),
  color: z.string().optional(),
  letterSpacing: z.number().optional(),
  filterConfig: z.object({
    sepia: z.number().min(0).max(1).default(0),
    contrast: z.number().min(0).max(2).default(1),
    brightness: z.number().min(0).max(2).default(1),
    scratchIntensity: z.number().min(0).max(1).default(0),
    burnIntensity: z.number().min(0).max(1).default(0),
    tornEdgeIntensity: z.number().min(0).max(1).default(0),
  }).optional(),
});

export type BountyCanvasLayer = z.infer<typeof bountyCanvasLayerSchema>;

export const userCustomBountySchema = z.object({
  title: z.string().min(1, 'Title is required').max(100, 'Title cannot exceed 100 characters'),
  characterName: z.string().min(1, 'Character name is required').max(100, 'Character name cannot exceed 100 characters'),
  bountyAmount: z.string().min(1, 'Bounty amount is required'),
  templateId: z.number().int().positive('Invalid template ID'),
  layersData: z.array(bountyCanvasLayerSchema),
  exportedImageUrl: z.string().url().optional().nullable(),
  isPublic: z.boolean().default(true),
});

export type UserCustomBountyInput = z.infer<typeof userCustomBountySchema>;
