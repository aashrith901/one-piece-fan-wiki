import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Combines class names using clsx and merges tailwind classes safely.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Helper to format large bounty numbers with commas and Beli currency symbol.
 */
export function formatBounty(amount: number | string): string {
  const num = typeof amount === 'string' ? parseFloat(amount.replace(/,/g, '')) : amount;
  if (isNaN(num)) return typeof amount === 'string' ? amount : '0';
  return `฿ ${num.toLocaleString('en-US')}`;
}

/**
 * Generates a persistent random number seeded by a string, useful for static tilt angles or particle positions.
 */
export function seededRandom(seed: string): number {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = Math.imul(31, hash) + seed.charCodeAt(i) | 0;
  }
  return Math.abs(hash) / 2147483648;
}
