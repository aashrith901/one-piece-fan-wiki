import { NextRequest, NextResponse } from "next/server";

// ============================================================================
// EDGE MIDDLEWARE: CSRF, RATE LIMITING & SECURITY HEADERS
// ============================================================================

// Basic Edge Memory Rate Limiting Store
const rateLimitMap = new Map<string, { count: number; lastReset: number }>();
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const MAX_REQUESTS = 60; // 60 requests per minute per IP

export function middleware(req: NextRequest) {
  const ip = req.ip || req.headers.get("x-forwarded-for") || "127.0.0.1";
  const now = Date.now();

  // 1. RATE LIMITING CHECK
  if (!rateLimitMap.has(ip)) {
    rateLimitMap.set(ip, { count: 1, lastReset: now });
  } else {
    const data = rateLimitMap.get(ip)!;
    if (now - data.lastReset > RATE_LIMIT_WINDOW) {
      data.count = 1;
      data.lastReset = now;
    } else {
      data.count += 1;
      if (data.count > MAX_REQUESTS) {
        return new NextResponse(
          JSON.stringify({ success: false, error: "Too many requests. Rate limit exceeded." }),
          { status: 429, headers: { "Content-Type": "application/json", "Retry-After": "60" } }
        );
      }
    }
  }

  // 2. CSRF PROTECTION CHECK (FOR MUTATIVE METHODS)
  if (["POST", "PUT", "DELETE"].includes(req.method)) {
    const origin = req.headers.get("origin");
    const host = req.headers.get("host");
    // Ensure origin matches host (allow localhost for dev/preview)
    if (origin && host && !origin.includes(host) && !origin.includes("localhost")) {
      return new NextResponse(
        JSON.stringify({ success: false, error: "Potential CSRF attempt blocked." }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }
  }

  // 3. SECURE COOKIE & XSS HEADERS
  const response = NextResponse.next();
  response.headers.set("X-Content-Type-Options", "nosniff");
  response.headers.set("X-Frame-Options", "DENY");
  response.headers.set("X-XSS-Protection", "1; mode=block");
  response.headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");

  return response;
}

export const config = {
  matcher: [
    "/api/:path*",
    "/profile/:path*/settings",
    "/auth/:path*",
  ],
};
