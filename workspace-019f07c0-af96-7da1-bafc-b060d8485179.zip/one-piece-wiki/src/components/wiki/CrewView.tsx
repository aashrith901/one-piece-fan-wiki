"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, Badge } from "@/components/ui/buttons";
import { Tabs, Accordion, Timeline, Gallery, Table } from "@/components/ui/navigation-ui";
import { CharacterCard, FactCard } from "@/components/ui/cards";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { Shield, Flame, Compass, Anchor, Skull, Sparkles, Users, Award, MapPin } from "lucide-react";

// ============================================================================
// PIRATE CREW FULL LORE BIOME VIEW
// ============================================================================

export interface CrewViewProps {
  crewSlug?: string;
}

export default function CrewView({ crewSlug = "straw-hat-pirates" }: CrewViewProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Static rich production data simulating Drizzle ORM infers for absolute reliability
  const crew = {
    name: "Straw Hat Pirates",
    japaneseName: "麦わらの一味",
    romanizedName: "Mugiwara no Ichimi",
    status: "Active (Yonko Fleet)",
    totalBounty: "8,816,000,000",
    jollyRoger: "https://images.unsplash.com/photo-1505118380757-91f5f563b031?q=80&w=600&auto=format&fit=crop",
    flagship: { name: "Thousand Sunny", type: "Brig Sloop (Adam Wood)", image: "https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=800&auto=format&fit=crop" },
    history: "Founded in the East Blue by Monkey D. Luffy. Following their victory over Emperor Kaido in Wano Country, the Straw Hats became recognized as an official Yonko crew, leading the 5,600+ strong Straw Hat Grand Fleet across the New World.",
    captain: { name: "Monkey D. Luffy", epithet: "Straw Hat / Sun God Nika", bounty: "3,000,000,000", image: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=800&auto=format&fit=crop" },
    members: [
      { name: "Roronoa Zoro", role: "Swordsman / First Mate", bounty: "1,111,000,000", image: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=800&auto=format&fit=crop" },
      { name: "Nami", role: "Navigator", bounty: "366,000,000", image: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=800&auto=format&fit=crop" },
      { name: "Usopp", role: "Sniper / God Usopp", bounty: "500,000,000", image: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=800&auto=format&fit=crop" },
      { name: "Sanji", role: "Cook / Black Leg", bounty: "1,032,000,000", image: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?q=80&w=800&auto=format&fit=crop" },
      { name: "Tony Tony Chopper", role: "Doctor / Cotton Candy Lover", bounty: "1,000", image: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?q=80&w=800&auto=format&fit=crop" },
      { name: "Nico Robin", role: "Archaeologist / Devil Child", bounty: "930,000,000", image: "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?q=80&w=800&auto=format&fit=crop" },
      { name: "Franky", role: "Shipwright / Iron Man", bounty: "394,000,000", image: "https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=800&auto=format&fit=crop" },
      { name: "Brook", role: "Musician / Soul King", bounty: "383,000,000", image: "https://images.unsplash.com/photo-1505118380757-91f5f563b031?q=80&w=800&auto=format&fit=crop" },
      { name: "Jinbe", role: "Helmsman / Knight of the Sea", bounty: "1,100,000,000", image: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=800&auto=format&fit=crop" },
    ],
    formerMembers: [
      { name: "Nefertari Vivi", role: "Honorary Princess", reason: "Stayed to govern Alabasta Kingdom" },
      { name: "Karoo", role: "Honorary Mount", reason: "Stayed with Vivi in Alabasta" },
    ],
    territories: ["Wano Country", "Fish-Man Island", "Dressrosa (Under Grand Fleet Protection)", "Alabasta Kingdom", "Zou"],
    battles: [
      { opponent: "Beasts Pirates (Kaido)", territory: "Wano Country", outcome: "Victory (Became Yonko Crew)" },
      { opponent: "Big Mom Pirates", territory: "Whole Cake Island", outcome: "Strategic Retreat / Objective Accomplished" },
      { opponent: "Donquixote Pirates", territory: "Dressrosa", outcome: "Victory (Grand Fleet Formed)" },
      { opponent: "CP9 / Enies Lobby Fleet", territory: "Enies Lobby", outcome: "Victory (Saved Nico Robin)" },
    ],
    timeline: [
      { year: "East Blue", title: "Original Five Assembled", description: "Luffy recruits Zoro, Nami, Usopp, and Sanji, setting sail on the Going Merry." },
      { year: "Grand Line Entry", title: "Entering the Wiskey Peak & Alabasta", description: "Vivi joins temporarily as they battle Baroque Works." },
      { year: "Water 7 & Enies Lobby", title: "Declaration of War", description: "Acquired the Thousand Sunny and recruited Franky and Brook." },
      { year: "New World", title: "Emperor Defeat", description: "Jinbe officially joins as helmsman as they defeat Kaido in Wano." },
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=800&auto=format&fit=crop", title: "Thousand Sunny", alt: "Flagship" },
      { src: "https://images.unsplash.com/photo-1505118380757-91f5f563b031?q=80&w=800&auto=format&fit=crop", title: "Onigashima Alliance", alt: "Straw Hat Alliance" },
      { src: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=800&auto=format&fit=crop", title: "Egghead Arrival", alt: "Future Island" },
    ],
  };

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[60vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <img src={crew.flagship.image} alt={crew.name} className="absolute inset-0 w-full h-full object-cover opacity-30 object-center" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-ocean-deep/50 to-transparent" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs
            items={[
              { label: "Grand Line Wiki", href: "/" },
              { label: "Pirate Crews", href: "/crews" },
              { label: crew.name },
            ]}
          />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex items-center space-x-6">
              <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-3xl overflow-hidden border-4 border-treasure bg-ocean-royal flex-shrink-0 shadow-premium-ocean">
                <img src={crew.jollyRoger} alt="Jolly Roger" className="w-full h-full object-cover" />
              </div>
              <div>
                <span className="inline-block bg-sunset-crimson text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-glowing-bounty mb-3">
                  {crew.status}
                </span>
                <h1 className="text-5xl sm:text-6xl md:text-7xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
                  {crew.name}
                </h1>
                <p className="text-xl font-cinematic text-treasure italic mt-1">
                  {crew.japaneseName} • {crew.romanizedName}
                </p>
              </div>
            </div>
            <div className="flex flex-col items-start md:items-end">
              <span className="font-cinematic text-sm font-bold text-muted-foreground uppercase tracking-widest mb-1">TOTAL FLEET BOUNTY</span>
              <span className="font-mono text-4xl sm:text-5xl font-bold text-treasure bg-ocean-deep px-6 py-2 rounded-2xl border-2 border-treasure shadow-premium-gilded">
                ฿ {crew.totalBounty}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MAIN LORE TABS */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <Tabs
          items={[
            {
              id: "fleet",
              label: "CREW & FLEET",
              content: (
                <div className="space-y-16">
                  {/* Captain & Flagship Dossier */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
                    <div className="lg:col-span-5 space-y-8">
                      <h3 className="text-2xl font-cinematic font-bold text-foreground mb-4 border-b-2 border-border pb-2 flex items-center">
                        <Skull className="w-6 h-6 mr-2 text-treasure" /> CAPTAIN OF THE FLEET
                      </h3>
                      <CharacterCard
                        name={crew.captain.name}
                        epithet={crew.captain.epithet}
                        image={crew.captain.image}
                        bounty={crew.captain.bounty}
                        faction="yonko"
                        onClick={() => (window.location.href = "/characters/monkey-d-luffy")}
                        className="w-full max-w-full"
                      />
                    </div>
                    <div className="lg:col-span-7 space-y-12">
                      <TreasureMapContainer>
                        <h3 className="text-3xl font-cinematic font-bold text-foreground mb-6 border-b-2 border-border pb-3 flex items-center">
                          <Anchor className="w-8 h-8 mr-3 text-treasure" /> FLEET HISTORY & MANIFEST
                        </h3>
                        <p className="font-sans text-lg text-foreground leading-relaxed font-medium mb-6">
                          {crew.history}
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 font-sans text-base border-t border-border pt-6">
                          <div><span className="font-bold text-xs uppercase text-muted-foreground block">Flagship Vessel</span>{crew.flagship.name} ({crew.flagship.type})</div>
                          <div><span className="font-bold text-xs uppercase text-muted-foreground block">Active Territories</span>{crew.territories.length} Islands Under Protection</div>
                        </div>
                      </TreasureMapContainer>

                      {/* Territories Grid */}
                      <WoodenPanel className="space-y-6 text-paper">
                        <h4 className="text-2xl font-cinematic font-bold text-treasure flex items-center border-b border-treasure/30 pb-4">
                          <MapPin className="w-7 h-7 mr-3 text-treasure" /> PROTECTED TERRITORIES
                        </h4>
                        <div className="flex flex-wrap gap-4">
                          {crew.territories.map((t, i) => (
                            <span key={i} className="px-6 py-3 rounded-2xl bg-ocean-deep border border-treasure font-cinematic text-lg font-bold text-treasure shadow-sm">
                              {t}
                            </span>
                          ))}
                        </div>
                      </WoodenPanel>
                    </div>
                  </div>

                  {/* Core Crew Members Grid */}
                  <div className="space-y-8">
                    <SectionHeader title="EXECUTIVE OFFICERS" subtitle="The Ten Commanders of the Straw Hats" />
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                      {crew.members.map((m, i) => (
                        <CharacterCard
                          key={i}
                          name={m.name}
                          epithet={m.role}
                          image={m.image}
                          bounty={m.bounty}
                          faction="pirate"
                          onClick={() => (window.location.href = `/characters/${m.name.toLowerCase().replace(/ /g, "-")}`)}
                          className="w-full max-w-sm mx-auto"
                        />
                      ))}
                    </div>
                  </div>

                  {/* Former Members & Affiliates */}
                  <div className="space-y-6">
                    <h3 className="text-3xl font-cinematic font-bold text-foreground tracking-wide flex items-center">
                      <Users className="w-8 h-8 mr-3 text-treasure" /> FORMER MEMBERS & ALLIES
                    </h3>
                    <Table
                      columns={[
                        { header: "Name", accessor: "name", className: "font-cinematic text-xl font-bold text-foreground" },
                        { header: "Role / Title", accessor: "role", className: "font-sans text-base text-muted-foreground" },
                        { header: "Departure / Reason", accessor: "reason", className: "font-sans text-base text-muted-foreground italic" },
                      ]}
                      data={crew.formerMembers}
                    />
                  </div>
                </div>
              ),
            },
            {
              id: "timeline",
              label: "VOYAGE TIMELINE",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="THE GRAND VOYAGE" subtitle="Chronology of the Straw Hat Fleet" />
                  <div className="max-w-4xl mx-auto">
                    <Timeline events={crew.timeline} />
                  </div>
                </div>
              ),
            },
            {
              id: "battles",
              label: "MAJOR CONFLICTS",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="WAR OF THE EMPERORS" subtitle="Historical Conflicts of the Straw Hats" />
                  <Table
                    columns={[
                      { header: "Opposing Faction", accessor: "opponent", className: "font-cinematic text-xl font-bold text-foreground" },
                      { header: "Location / Territory", accessor: "territory", className: "font-sans text-base text-muted-foreground" },
                      { header: "Strategic Outcome", accessor: "outcome", className: "font-cinematic text-lg font-bold text-treasure" },
                    ]}
                    data={crew.battles}
                  />
                </div>
              ),
            },
            {
              id: "gallery",
              label: "JOLLY ROGER GALLERY",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="FLEET ARCHIVES" subtitle="Official Curated Manifests" />
                  <Gallery images={crew.gallery} />
                </div>
              ),
            },
          ]}
        />
      </div>

      <Footer />
    </div>
  );
}
