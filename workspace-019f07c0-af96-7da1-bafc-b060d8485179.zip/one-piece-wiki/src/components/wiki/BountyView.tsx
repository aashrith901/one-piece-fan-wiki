"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { cn, formatBounty } from "@/lib/utils";
import { Button } from "@/components/ui/buttons";
import { Tabs, Table, Timeline } from "@/components/ui/navigation-ui";
import { StatCard, CharacterCard } from "@/components/ui/cards";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel, CoinParticles } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { Flame, Sparkles, AlertCircle, Anchor, Shield, TrendingUp } from "lucide-react";

// ============================================================================
// BOUNTY FULL LEDGER & CHARTS VIEW
// ============================================================================

export default function BountyView() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Static rich production data simulating Drizzle ORM infers for absolute reliability
  const highestBounties = [
    { rank: 1, name: "Gol D. Roger", title: "Pirate King", bounty: "5,564,800,000", status: "Deceased", image: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=800&auto=format&fit=crop" },
    { rank: 2, name: "Edward Newgate", title: "Whitebeard", bounty: "5,046,000,000", status: "Deceased", image: "https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=800&auto=format&fit=crop" },
    { rank: 3, name: "Kaido", title: "King of the Beasts", bounty: "4,611,100,000", status: "Active / Defeated", image: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=800&auto=format&fit=crop" },
    { rank: 4, name: "Charlotte Linlin", title: "Big Mom", bounty: "4,388,000,000", status: "Active / Defeated", image: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?q=80&w=800&auto=format&fit=crop" },
    { rank: 5, name: "Shanks", title: "Red-Haired", bounty: "4,048,900,000", status: "Active", image: "https://images.unsplash.com/photo-1505118380757-91f5f563b031?q=80&w=800&auto=format&fit=crop" },
    { rank: 6, name: "Marshall D. Teach", title: "Blackbeard", bounty: "3,996,000,000", status: "Active", image: "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?q=80&w=800&auto=format&fit=crop" },
    { rank: 7, name: "Dracule Mihawk", title: "Hawk Eyes / Cross Guild", bounty: "3,590,000,000", status: "Active", image: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?q=80&w=800&auto=format&fit=crop" },
    { rank: 8, name: "Buggy", title: "Genius Jester / Cross Guild", bounty: "3,189,000,000", status: "Active", image: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=800&auto=format&fit=crop" },
    { rank: 9, name: "Monkey D. Luffy", title: "Straw Hat / Sun God Nika", bounty: "3,000,000,000", status: "Active", image: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=800&auto=format&fit=crop" },
  ];

  const crewTotals = [
    { rank: 1, crew: "Red Hair Pirates", total: "10,140,000,000", flagship: "Red Force", captain: "Shanks" },
    { rank: 2, crew: "Straw Hat Pirates", total: "8,816,000,000", flagship: "Thousand Sunny", captain: "Monkey D. Luffy" },
    { rank: 3, crew: "Beasts Pirates", total: "8,335,100,000", flagship: "Mammoth Fleet", captain: "Kaido" },
    { rank: 4, crew: "Big Mom Pirates", total: "8,124,500,000", flagship: "Queen Mama Chanter", captain: "Charlotte Linlin" },
  ];

  const latestBounties = [
    { year: "June 2026 (Cross Guild)", title: "Vice Admiral Bounties", description: "Buggy the Jester establishes 500,000,000 Beli minimum bounties on Marine Vice Admirals." },
    { year: "Egghead Incident", title: "Straw Hat Fleet Expansion", description: "Post-Wano bounties confirmed globally by the World Government." },
  ];

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[50vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-treasure/20 via-ocean-deep to-ocean-royal pointer-events-none" />
        <CoinParticles count={25} />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs
            items={[
              { label: "Grand Line Wiki", href: "/" },
              { label: "Bounty Ledger" },
            ]}
          />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <span className="inline-block bg-wood text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-sm mb-3">
                WANTED DEAD OR ALIVE
              </span>
              <h1 className="text-5xl sm:text-6xl md:text-7xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
                HISTORICAL BOUNTY LEDGER
              </h1>
              <p className="text-xl font-sans text-ocean-foam/80 italic mt-1">
                Official tracking records of the World Government and Cross Guild operations.
              </p>
            </div>
            <div>
              <Button variant="gilded" size="lg" onClick={() => (window.location.href = "/bounties/generator")} leftIcon={<Flame className="w-5 h-5 text-sunset" />}>
                CANVA BOUNTY STUDIO
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MAIN LORE TABS */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <Tabs
          items={[
            {
              id: "highest",
              label: "HIGHEST RECORDED BOUNTIES",
              content: (
                <div className="space-y-16">
                  <SectionHeader title="THE PEAK OF INFAMY" subtitle="Highest Individual Bounties" />
                  <Table
                    columns={[
                      { header: "Rank", accessor: (row) => <span className="font-mono text-xl font-bold text-treasure bg-ocean-deep px-3 py-1 rounded-full border border-treasure">#{row.rank}</span>, className: "w-24" },
                      { header: "Legendary Infidel", accessor: (row) => (
                        <div className="flex items-center space-x-4">
                          <img src={row.image} alt={row.name} className="w-12 h-12 rounded-full object-cover border-2 border-treasure shadow-sm" />
                          <div>
                            <span className="font-cinematic text-xl font-bold text-foreground block">{row.name}</span>
                            <span className="font-sans text-xs text-muted-foreground italic">{row.title}</span>
                          </div>
                        </div>
                      ) },
                      { header: "Status", accessor: "status", className: "font-sans text-base text-muted-foreground" },
                      { header: "Bounty Amount", accessor: (row) => <span className="font-mono text-2xl font-bold text-treasure bg-ocean-deep px-4 py-2 rounded-xl border border-treasure shadow-sm">฿ {row.bounty}</span>, className: "text-right" },
                    ]}
                    data={highestBounties}
                  />
                </div>
              ),
            },
            {
              id: "crews",
              label: "CREW BOUNTY TOTALS",
              content: (
                <div className="space-y-16">
                  <SectionHeader title="FLEET COMBINED BOUNTY" subtitle="Most Wanted Pirate Squads" />
                  <Table
                    columns={[
                      { header: "Rank", accessor: (row) => <span className="font-mono text-xl font-bold text-treasure bg-ocean-deep px-3 py-1 rounded-full border border-treasure">#{row.rank}</span>, className: "w-24" },
                      { header: "Pirate Crew", accessor: "crew", className: "font-cinematic text-2xl font-bold text-foreground" },
                      { header: "Captain", accessor: "captain", className: "font-sans text-base text-muted-foreground" },
                      { header: "Flagship", accessor: "flagship", className: "font-sans text-base text-muted-foreground italic" },
                      { header: "Combined Total", accessor: (row) => <span className="font-mono text-2xl font-bold text-treasure bg-ocean-deep px-4 py-2 rounded-xl border border-treasure shadow-sm">฿ {row.total}</span>, className: "text-right" },
                    ]}
                    data={crewTotals}
                  />
                </div>
              ),
            },
            {
              id: "latest",
              label: "LATEST BOUNTY NEWS",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="RECENT GOVERNMENT ANNOUNCEMENTS" subtitle="Latest Shifts in the Balance of Power" />
                  <div className="max-w-4xl mx-auto">
                    <Timeline events={latestBounties} />
                  </div>
                </div>
              ),
            },
          ]}
        />
      </div>

      <Footer />
    </div>
  );
}
