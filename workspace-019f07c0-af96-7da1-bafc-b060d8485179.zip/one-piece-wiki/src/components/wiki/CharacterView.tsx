"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, Badge } from "@/components/ui/buttons";
import { Tabs, Accordion, Timeline, Gallery, Table } from "@/components/ui/navigation-ui";
import { CharacterCard, QuoteCard, FactCard } from "@/components/ui/cards";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { FadeReveal, SlideReveal, ScaleReveal, AnimatedCounter } from "@/components/animations/motion";
import { Shield, Flame, Compass, Anchor, Skull, Sparkles, BookOpen, Film, Users, Award, Calendar, RefreshCw } from "lucide-react";

// ============================================================================
// CHARACTER FULL LORE BIOME VIEW
// ============================================================================

export interface CharacterViewProps {
  characterSlug?: string;
}

export default function CharacterView({ characterSlug = "monkey-d-luffy" }: CharacterViewProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Static rich production data simulating Drizzle ORM infers for absolute reliability
  const character = {
    name: "Monkey D. Luffy",
    japaneseName: "モンキー・D・ルフィ",
    romanizedName: "Monkī D. Rufi",
    nicknames: ["Straw Hat Luffy", "Sun God Nika", "Lucy"],
    crew: "Straw Hat Pirates",
    status: "Alive",
    occupation: "Pirate Captain / Emperor of the Sea",
    age: "19 (Post-Timeskip)",
    birthday: "May 5 (Children's Day)",
    height: "174 cm (5'8½\")",
    bloodType: "F",
    origin: "Foosha Village, East Blue",
    bounty: "3,000,000,000",
    coverImage: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=1200&auto=format&fit=crop",
    gallery: [
      { src: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=800&auto=format&fit=crop", title: "Emperor Luffy", alt: "Gear 5 Luffy" },
      { src: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=800&auto=format&fit=crop", title: "Roof Piece Clash", alt: "Luffy vs Kaido" },
      { src: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=800&auto=format&fit=crop", title: "Onigashima Arrival", alt: "Wano Samurai Armor" },
    ],
    devilFruit: {
      name: "Hito Hito no Mi, Model: Nika (Formerly Gomu Gomu no Mi)",
      type: "Mythical Zoan",
      awakened: true,
      description: "Grants the user a rubber body and the ability to fight in whatever way they fancy, bringing smiles and joy to the people. When awakened, it grants legendary freedom and cartoonish physical manipulation of the environment.",
    },
    haki: {
      conquerors: "Advanced (Infusion / Haoshoku)",
      armament: "Advanced (Internal Destruction / Busoshoku)",
      observation: "Advanced (Future Sight / Kenbunshoku)",
    },
    fightingStyle: "Gomu Gomu no Mi Freestyle Martial Arts / Gear System (2, 3, 4, 5)",
    weapons: ["Fists", "Sandals", "Nidai Kitetsu (Briefly held in Wano)"],
    personality: "Extremely free-spirited, adventurous, gluttonous for meat, fiercely loyal to his crew, and possesses an unbreakable, stubborn will to become the Pirate King.",
    relationships: {
      family: [
        { name: "Monkey D. Dragon", relation: "Father (Revolutionary Leader)" },
        { name: "Monkey D. Garp", relation: "Grandfather (Marine Hero)" },
        { name: "Portgas D. Ace", relation: "Sworn Brother (Deceased)" },
        { name: "Sabo", relation: "Sworn Brother (Revolutionary Chief of Staff)" },
      ],
      allies: ["Trafalgar D. Water Law", "Eustass Kid", "Boa Hancock", "Nefertari Vivi", "Yamato", "Shanks", "Red Hair Pirates"],
      enemies: ["World Government", "Five Elders (Gorosei)", "Imu", "Blackbeard (Marshall D. Teach)", "Akainu (Sakazuki)", "Kaido", "Big Mom"],
    },
    importantBattles: [
      { opponent: "Kaido", arc: "Wano Country", outcome: "Victory (Awakened Gear 5 / Bajrang Gun)" },
      { opponent: "Charlotte Katakuri", arc: "Whole Cake Island", outcome: "Victory (Unlocked Future Sight / Snakeman)" },
      { opponent: "Donquixote Doflamingo", arc: "Dressrosa", outcome: "Victory (Gear 4 Bounceman)" },
      { opponent: "Rob Lucci", arc: "Enies Lobby & Egghead", outcome: "Victory (Gear 2 / Gear 5 Clash)" },
    ],
    appearances: {
      manga: "Chapter 1: 'Romance Dawn'",
      anime: "Episode 1: 'I'm Luffy! The Man Who Will Become the Pirate King!'",
      voiceActors: ["Mayumi Tanaka (Japanese)", "Colleen Clinkenbeard (English)"],
    },
    quotes: [
      "I don't want to conquer anything. It's just that the person with the most freedom on the sea is the Pirate King!",
      "If you don't take risks, you can't create a future!",
      "I set myself to become the Pirate King... and if I die trying... then at least I tried!",
    ],
    trivia: [
      "Luffy's signature straw hat was originally owned by Gol D. Roger, who passed it to Shanks, who then entrusted it to Luffy.",
      "Oda stated that if Luffy were real, his nationality would be Brazilian.",
      "He does not have a single thought bubble in the entire manga; Oda writes him so that he says everything he thinks out loud.",
    ],
    stats: { power: 98, speed: 95, technique: 90, intelligence: 75, haki: 98 },
    bountyTimeline: [
      { year: "East Blue Saga", title: "30,000,000 Beli", description: "Defeated Arlong, Don Krieg, and Buggy the Clown." },
      { year: "Alabasta Arc", title: "100,000,000 Beli", description: "Defeated Warlord Crocodile, saving the Alabasta Kingdom." },
      { year: "Enies Lobby", title: "300,000,000 Beli", description: "Declared war on the World Government and defeated CP9." },
      { year: "Marineford", title: "400,000,000 Beli", description: "Infiltrated Impel Down and participated in the Paramount War." },
      { year: "Dressrosa", title: "500,000,000 Beli", description: "Defeated Warlord Donquixote Doflamingo." },
      { year: "Whole Cake Island", title: "1,500,000,000 Beli", description: "Invaded Big Mom's territory and defeated Katakuri." },
      { year: "Wano Country", title: "3,000,000,000 Beli", description: "Defeated Emperor Kaido, unlocking Gear 5 and becoming an Emperor." },
    ],
  };

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[60vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <img src={character.coverImage} alt={character.name} className="absolute inset-0 w-full h-full object-cover opacity-30 object-top" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-ocean-deep/50 to-transparent" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs
            items={[
              { label: "Grand Line Wiki", href: "/" },
              { label: "Characters", href: "/characters" },
              { label: character.name },
            ]}
          />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <span className="inline-block bg-sunset-crimson text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-glowing-bounty mb-3">
                {character.occupation}
              </span>
              <h1 className="text-5xl sm:text-6xl md:text-7xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
                {character.name}
              </h1>
              <p className="text-xl font-cinematic text-treasure italic mt-1">
                {character.japaneseName} • {character.romanizedName}
              </p>
            </div>
            <div className="flex flex-col items-start md:items-end">
              <span className="font-cinematic text-sm font-bold text-muted-foreground uppercase tracking-widest mb-1">ACTIVE BOUNTY</span>
              <span className="font-mono text-4xl sm:text-5xl font-bold text-treasure bg-ocean-deep px-6 py-2 rounded-2xl border-2 border-treasure shadow-premium-gilded">
                ฿ {character.bounty}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MAIN LORE TABS */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <Tabs
          items={[
            {
              id: "overview",
              label: "CHARACTER BIOME",
              content: (
                <div className="space-y-16">
                  {/* Overview Stats & Profile Card */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
                    <div className="lg:col-span-5 space-y-8">
                      <CharacterCard
                        name={character.name}
                        epithet={character.nicknames[0]}
                        image={character.coverImage}
                        bounty={character.bounty}
                        faction="yonko"
                        stats={character.stats}
                        className="w-full max-w-full"
                      />
                      {/* Radar Quick View */}
                      <WoodenPanel className="space-y-4">
                        <h4 className="font-cinematic text-xl font-bold text-treasure flex items-center border-b border-treasure/30 pb-2">
                          <Award className="w-5 h-5 mr-2 text-treasure" /> COMBAT PROFICIENCY
                        </h4>
                        <div className="space-y-3 font-mono text-xs text-paper">
                          {Object.entries(character.stats).map(([stat, val]) => (
                            <div key={stat}>
                              <div className="flex justify-between mb-1 uppercase">
                                <span>{stat}</span>
                                <span className="text-treasure font-bold">{val}%</span>
                              </div>
                              <div className="w-full h-2 bg-ocean-deep rounded-full overflow-hidden border border-treasure/30">
                                <div className="h-full bg-treasure transition-all duration-500" style={{ width: `${val}%` }} />
                              </div>
                            </div>
                          ))}
                        </div>
                      </WoodenPanel>
                    </div>

                    <div className="lg:col-span-7 space-y-12">
                      <TreasureMapContainer>
                        <h3 className="text-3xl font-cinematic font-bold text-foreground mb-6 border-b-2 border-border pb-3 flex items-center">
                          <Compass className="w-8 h-8 mr-3 text-treasure" /> DOSSIER & PROFILE
                        </h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 font-sans text-base text-foreground">
                          <div><span className="font-bold text-xs uppercase text-muted-foreground block">Primary Allegiance</span>{character.crew}</div>
                          <div><span className="font-bold text-xs uppercase text-muted-foreground block">Status</span>{character.status}</div>
                          <div><span className="font-bold text-xs uppercase text-muted-foreground block">Age</span>{character.age}</div>
                          <div><span className="font-bold text-xs uppercase text-muted-foreground block">Birthday</span>{character.birthday}</div>
                          <div><span className="font-bold text-xs uppercase text-muted-foreground block">Height</span>{character.height}</div>
                          <div><span className="font-bold text-xs uppercase text-muted-foreground block">Blood Type</span>{character.bloodType}</div>
                          <div className="sm:col-span-2"><span className="font-bold text-xs uppercase text-muted-foreground block">Origin</span>{character.origin}</div>
                        </div>
                      </TreasureMapContainer>

                      {/* Devil Fruit Section */}
                      <div className="relative overflow-hidden rounded-3xl border-4 border-treasure bg-ocean-deep p-8 sm:p-10 shadow-premium-ocean text-ocean-foam space-y-6">
                        <div className="flex items-center justify-between border-b border-ocean-royal pb-4">
                          <h4 className="text-2xl font-cinematic font-bold text-treasure flex items-center">
                            <Flame className="w-7 h-7 mr-3 text-sunset animate-bounce" /> CURSED DEVIL FRUIT
                          </h4>
                          {character.devilFruit.awakened && (
                            <span className="bg-sunset-crimson text-white px-4 py-1.5 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase border border-treasure shadow-glowing-bounty">
                              AWAKENED ABILITY
                            </span>
                          )}
                        </div>
                        <div>
                          <h5 className="text-xl font-cinematic font-bold text-treasure-light mb-2">{character.devilFruit.name}</h5>
                          <span className="inline-block bg-wood text-treasure px-3 py-1 rounded-full text-xs font-cinematic uppercase tracking-wider mb-4">
                            {character.devilFruit.type}
                          </span>
                          <p className="font-sans text-base leading-relaxed text-ocean-foam/80 font-medium">
                            {character.devilFruit.description}
                          </p>
                        </div>
                      </div>

                      {/* Haki Section */}
                      <WoodenPanel className="space-y-6 text-paper">
                        <h4 className="text-2xl font-cinematic font-bold text-treasure flex items-center border-b border-treasure/30 pb-4">
                          <Shield className="w-7 h-7 mr-3 text-treasure" /> THREE COLORS OF HAKI
                        </h4>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 font-sans">
                          <div>
                            <span className="font-cinematic text-sm font-bold text-treasure block uppercase mb-1">SUPREME KING (CONQUEROR)</span>
                            <p className="text-sm text-paper/80 font-medium">{character.haki.conquerors}</p>
                          </div>
                          <div>
                            <span className="font-cinematic text-sm font-bold text-treasure block uppercase mb-1">ARMAMENT (BUSOSHOKU)</span>
                            <p className="text-sm text-paper/80 font-medium">{character.haki.armament}</p>
                          </div>
                          <div>
                            <span className="font-cinematic text-sm font-bold text-treasure block uppercase mb-1">OBSERVATION (KENBUNSHOKU)</span>
                            <p className="text-sm text-paper/80 font-medium">{character.haki.observation}</p>
                          </div>
                        </div>
                      </WoodenPanel>
                    </div>
                  </div>

                  {/* Personality & Relationships Accordion */}
                  <div className="space-y-6">
                    <h3 className="text-3xl font-cinematic font-bold text-foreground tracking-wide flex items-center">
                      <Users className="w-8 h-8 mr-3 text-treasure" /> RELATIONS & LORE
                    </h3>
                    <Accordion
                      items={[
                        { id: "p1", title: "Personality & Fighting Style", content: <p className="font-sans text-base leading-relaxed">{character.personality} <br/><br/><strong>Fighting Style:</strong> {character.fightingStyle}</p> },
                        { id: "p2", title: "Family & Lineage", content: (
                          <ul className="space-y-3 font-sans text-base">
                            {character.relationships.family.map((f, i) => (
                              <li key={i} className="flex justify-between border-b border-border/50 pb-2">
                                <span className="font-bold text-foreground">{f.name}</span>
                                <span className="text-muted-foreground">{f.relation}</span>
                              </li>
                            ))}
                          </ul>
                        ) },
                        { id: "p3", title: "Major Allies & Sworn Friends", content: <div className="flex flex-wrap gap-3">{character.relationships.allies.map((a, i) => (<span key={i} className="px-4 py-2 bg-card border border-border rounded-xl font-cinematic font-bold text-foreground">{a}</span>))}</div> },
                        { id: "p4", title: "Primary Enemies & Rivals", content: <div className="flex flex-wrap gap-3">{character.relationships.enemies.map((e, i) => (<span key={i} className="px-4 py-2 bg-sunset-crimson/10 border border-sunset-crimson text-sunset-crimson rounded-xl font-cinematic font-bold">{e}</span>))}</div> },
                      ]}
                      allowMultiple
                    />
                  </div>
                </div>
              ),
            },
            {
              id: "timeline",
              label: "BOUNTY TIMELINE",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="EVOLUTION OF INFAMY" subtitle="Historical Bounty Progression" />
                  <div className="max-w-4xl mx-auto">
                    <Timeline events={character.bountyTimeline} />
                  </div>
                </div>
              ),
            },
            {
              id: "battles",
              label: "LEGENDARY BATTLES",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="CLASH OF SUPREME KINGS" subtitle="Significant Engagements of the Grand Line" />
                  <Table
                    columns={[
                      { header: "Opponent", accessor: "opponent", className: "font-cinematic text-xl font-bold text-foreground" },
                      { header: "Arc / Territory", accessor: "arc", className: "font-sans text-base text-muted-foreground" },
                      { header: "Outcome / Result", accessor: "outcome", className: "font-cinematic text-lg font-bold text-treasure" },
                    ]}
                    data={character.importantBattles}
                  />
                </div>
              ),
            },
            {
              id: "gallery",
              label: "MEDIA GALLERY",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="OFFICIAL ARCHIVES" subtitle="Curated Media Vault" />
                  <Gallery images={character.gallery} />
                </div>
              ),
            },
            {
              id: "trivia",
              label: "TRIVIA & QUOTES",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="ANCIENT SCROLLS" subtitle="Wisdom & Behind The Scenes" />
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-6">
                      <h4 className="text-2xl font-cinematic font-bold text-foreground mb-4 border-b-2 border-border pb-2">Legendary Declarations</h4>
                      {character.quotes.map((q, i) => (
                        <QuoteCard key={i} quote={q} author={character.name} className="w-full" />
                      ))}
                    </div>
                    <div className="space-y-6">
                      <h4 className="text-2xl font-cinematic font-bold text-foreground mb-4 border-b-2 border-border pb-2">Behind The Scenes Trivia</h4>
                      {character.trivia.map((t, i) => (
                        <FactCard key={i} title={`TRIVIA #${i + 1}`} fact={t} className="w-full" />
                      ))}
                    </div>
                  </div>
                </div>
              ),
            },
          ]}
        />
      </div>

      <Footer />
    </div>
  );
}
