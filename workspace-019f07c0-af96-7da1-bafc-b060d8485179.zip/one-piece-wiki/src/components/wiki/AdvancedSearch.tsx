"use client";

import React, { useState, useEffect, useRef, useTransition, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, SearchInput, Select } from "@/components/ui/buttons";
import { SkeletonLoader, EmptyState } from "@/components/ui/feedback";
import { RopeBorder, TreasureMapContainer, GlassPanel } from "@/components/decorations/maritime";
import { Search, X, Flame, History, ArrowRight, Sparkles, Filter, SlidersHorizontal } from "lucide-react";

// ============================================================================
// HIGHLIGHT MATCHING TEXT HELPER
// ============================================================================

const HighlightText: React.FC<{ text: string; query: string }> = ({ text, query }) => {
  if (!query) return <span>{text}</span>;
  const parts = text.split(new RegExp(`(${query})`, "gi"));
  return (
    <span>
      {parts.map((part, i) =>
        part.toLowerCase() === query.toLowerCase() ? (
          <span key={i} className="bg-treasure text-ocean-deep font-bold px-1 rounded">
            {part}
          </span>
        ) : (
          part
        )
      )}
    </span>
  );
};

// ============================================================================
// ADVANCED SEARCH CLIENT COMPONENT
// ============================================================================

export default function AdvancedSearch() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [sort, setSort] = useState("popularity");
  const [results, setResults] = useState<any[]>([]);
  const [isPending, startTransition] = useTransition();
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);

  const filters = [
    { label: "All Factions & Lore", value: "all" },
    { label: "Characters", value: "characters" },
    { label: "Straw Hat Crew", value: "Straw Hat Crew" },
    { label: "Pirate Crews", value: "crews" },
    { label: "Marines", value: "Marines" },
    { label: "Yonko", value: "Yonko" },
    { label: "Seven Warlords", value: "Warlords" },
    { label: "Revolutionaries", value: "Revolutionaries" },
    { label: "Cross Guild", value: "Cross Guild" },
    { label: "Cipher Pol", value: "Cipher Pol" },
    { label: "World Government", value: "World Government" },
    { label: "Devil Fruits", value: "devil-fruits" },
    { label: "Haki Types", value: "haki" },
    { label: "Meito Weapons", value: "weapons" },
    { label: "Iconic Ships", value: "ships" },
    { label: "Islands", value: "islands" },
    { label: "Organizations", value: "Organizations" },
    { label: "Bounty Ledger", value: "bounties" },
  ];

  const trendingSearches = ["Monkey D. Luffy", "Gear 5 Nika", "Shanks Divine Departure", "Ope Ope no Mi", "Red Hair Pirates", "Cross Guild Bounties", "Egghead Island"];

  // Initialize Search History from localStorage
  useEffect(() => {
    const hist = localStorage.getItem("one_piece_search_history");
    if (hist) setSearchHistory(JSON.parse(hist));
  }, []);

  const saveHistory = (term: string) => {
    if (!term.trim() || searchHistory.includes(term)) return;
    const nextHist = [term, ...searchHistory.slice(0, 4)];
    setSearchHistory(nextHist);
    localStorage.setItem("one_piece_search_history", JSON.stringify(nextHist));
  };

  const clearHistory = () => {
    setSearchHistory([]);
    localStorage.removeItem("one_piece_search_history");
  };

  // Instant Search Fetch Trigger
  useEffect(() => {
    startTransition(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}&filter=${encodeURIComponent(filter)}&sort=${encodeURIComponent(sort)}`);
        const data = await res.json();
        if (data.success) {
          setResults(data.data);
          setSelectedIndex(-1);
        }
      } catch (err) {
        console.error("Search fetch error:", err);
      }
    });
  }, [query, filter, sort]);

  // Keyboard Navigation Handler
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < results.length - 1 ? prev + 1 : prev));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : -1));
    } else if (e.key === "Enter" && selectedIndex >= 0) {
      e.preventDefault();
      const selected = results[selectedIndex];
      saveHistory(selected.name);
      window.location.href = `/${selected.type}s/${selected.slug}`;
    } else if (e.key === "Enter" && query.trim()) {
      saveHistory(query);
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 select-none">
      <TreasureMapContainer className="mb-12">
        <div className="space-y-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <h2 className="text-4xl font-cinematic font-bold text-foreground tracking-wide">
                ADVANCED GRAND LINE DATABASE SEARCH
              </h2>
              <p className="text-base font-sans text-muted-foreground mt-2">
                Instantly filter across 1,500+ characters, crews, devil fruits, weapons, and islands with full fuzzy matching and live suggestions.
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <Select
                options={[
                  { label: "Sort by Popularity", value: "popularity" },
                  { label: "Sort Alphabetically", value: "alphabet" },
                ]}
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="w-48 font-cinematic font-bold"
              />
            </div>
          </div>

          {/* Search Input Bar */}
          <div className="relative w-full">
            <SearchInput
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              onClear={() => setQuery("")}
              placeholder="Search by name, epithet, crew, or ability... (e.g. 'Luffy', 'Awakened', 'Mihawk')"
              className="max-w-full text-xl h-16 bg-ocean-deep text-ocean-foam placeholder:text-ocean-foam/60 border-2 border-treasure shadow-premium-ocean"
              isSearching={isPending}
            />
          </div>

          {/* Filters List */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
            <Filter className="w-5 h-5 text-treasure flex-shrink-0 mr-2" />
            {filters.map((f) => (
              <button
                key={f.value}
                onClick={() => setFilter(f.value)}
                className={cn(
                  "px-4 py-2 rounded-xl font-cinematic text-sm font-bold tracking-wider whitespace-nowrap transition-all shadow-sm border flex-shrink-0",
                  filter === f.value
                    ? "bg-treasure text-ocean-deep border-treasure shadow-premium-gilded"
                    : "bg-card text-foreground border-border hover:border-treasure"
                )}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Search History & Trending Suggestion Rows */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4 border-t border-border">
            {/* Search History */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="flex items-center font-cinematic text-sm font-bold text-foreground uppercase tracking-wider">
                  <History className="w-4 h-4 mr-2 text-treasure" /> Recent Navigations
                </span>
                {searchHistory.length > 0 && (
                  <button onClick={clearHistory} className="text-xs font-sans text-muted-foreground hover:text-destructive transition-colors">
                    Clear History
                  </button>
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                {searchHistory.length === 0 ? (
                  <span className="text-sm font-sans text-muted-foreground italic">No recent navigations recorded.</span>
                ) : (
                  searchHistory.map((item, index) => (
                    <button
                      key={index}
                      onClick={() => setQuery(item)}
                      className="px-3 py-1.5 rounded-lg bg-input text-foreground font-sans text-sm border border-border hover:border-treasure transition-colors flex items-center space-x-1"
                    >
                      <span>{item}</span>
                    </button>
                  ))
                )}
              </div>
            </div>

            {/* Trending Searches */}
            <div>
              <div className="flex items-center mb-3">
                <span className="flex items-center font-cinematic text-sm font-bold text-foreground uppercase tracking-wider">
                  <Flame className="w-4 h-4 mr-2 text-sunset animate-bounce" /> Trending In The New World
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {trendingSearches.map((item, index) => (
                  <button
                    key={index}
                    onClick={() => setQuery(item)}
                    className="px-3 py-1.5 rounded-lg bg-ocean-royal text-ocean-foam font-sans text-sm border border-ocean-light hover:border-treasure hover:text-treasure transition-colors flex items-center space-x-1 shadow-sm"
                  >
                    <span>{item}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </TreasureMapContainer>

      {/* ============================================================================ */}
      {/* SEARCH RESULTS GRID */}
      {/* ============================================================================ */}
      <div className="mt-12">
        {isPending && results.length === 0 ? (
          <SkeletonLoader count={6} />
        ) : results.length === 0 ? (
          <EmptyState title="NO LORE MATCHES FOUND" message="No characters, crews, or devil fruits match your query. Try adjusting your filter tags or search phrasing." />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {results.map((item, index) => {
              const isSelected = index === selectedIndex;
              return (
                <div
                  key={item.id}
                  onClick={() => {
                    saveHistory(item.name);
                    window.location.href = `/${item.type}s/${item.slug}`;
                  }}
                  className={cn(
                    "cursor-pointer overflow-hidden rounded-2xl border-2 bg-ocean-deep shadow-premium-ocean transition-all duration-300 hover:border-treasure hover:translate-y-[-4px] group flex flex-col justify-between",
                    isSelected ? "border-treasure shadow-premium-gilded" : "border-ocean-royal"
                  )}
                >
                  <div className="relative h-64 w-full overflow-hidden bg-wood">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-ocean-deep via-transparent to-transparent opacity-80" />
                    <span className="absolute top-4 left-4 bg-wood text-treasure border border-treasure px-3 py-1 rounded-full text-xs font-cinematic font-bold tracking-wider uppercase shadow-sm">
                      {item.category}
                    </span>
                    {item.bounty && item.bounty !== "N/A" && (
                      <span className="absolute top-4 right-4 bg-treasure text-ocean-deep border border-wood px-3 py-1 rounded-full text-xs font-mono font-bold tracking-widest shadow-sm">
                        ฿ {item.bounty}
                      </span>
                    )}
                  </div>
                  <div className="p-6 flex flex-col flex-grow justify-between">
                    <div>
                      <h4 className="text-2xl font-cinematic font-bold text-ocean-foam group-hover:text-treasure transition-colors tracking-wide">
                        <HighlightText text={item.name} query={query} />
                      </h4>
                      {item.title && (
                        <p className="mt-1 text-sm font-sans text-ocean-foam/70 italic">
                          <HighlightText text={item.title} query={query} />
                        </p>
                      )}
                    </div>
                    <div className="mt-6 border-t border-ocean-royal pt-4 flex items-center justify-between text-xs text-treasure font-cinematic font-bold tracking-wider uppercase">
                      <span>EXPLORE BIOME</span>
                      <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
