"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/buttons";
import { Tabs, Accordion, Table } from "@/components/ui/navigation-ui";
import { CharacterCard } from "@/components/ui/cards";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { Shield, Zap, Sparkles, Users, Award } from "lucide-react";

// ============================================================================
// HAKI FULL LORE DATABASE VIEW
// ============================================================================

export interface HakiViewProps {
  hakiSlug?: string;
}

export default function HakiView({ hakiSlug = "conquerors-haki" }: HakiViewProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Static rich production data simulating Drizzle ORM infers for absolute reliability
  const hakiData: Record<string, any> = {
    "conquerors-haki": {
      name: "Conqueror's Haki",
      japaneseName: "覇王色の覇気",
      romanizedName: "Haoshoku Haki",
      colorAccent: "text-sunset-crimson",
      summary: "A rare form of Haki that allows the user to exert their own willpower over others. Unlike the other two types of Haki, Conqueror's Haki cannot be attained through training and only exists in one in several million people who possess the qualities of a king.",
      advancedTechniques: [
        { name: "Haoshoku Infusion", description: "Advanced users can infuse their Conqueror's Haki directly into their weapons or bodies before an attack. This produces thick streaks of black lightning and allows the user to clash with opposing emperors without physically touching them." },
        { name: "Observation Haki Cancellation", description: "Known as 'Sign of Conqueror' or 'Killer of Observation Haki', legendary users like Shanks can completely disrupt an opponent's Future Sight." },
      ],
      knownUsers: [
        { name: "Gol D. Roger", title: "Pirate King", image: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=800&auto=format&fit=crop" },
        { name: "Shanks", title: "Emperor", image: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=800&auto=format&fit=crop" },
        { name: "Monkey D. Luffy", title: "Emperor", image: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=800&auto=format&fit=crop" },
      ],
      examples: [
        { event: "Clash at Onigashima Rooftop", description: "Luffy and Kaido clash using Haoshoku Infusion, splitting the cloud heavens apart." },
        { event: "Whitebeard vs. Roger Clash", description: "The legendary clash on the Grand Line where their blades did not touch due to immense Conqueror's barriers." },
      ],
    },
    "armament-haki": {
      name: "Armament Haki",
      japaneseName: "武装色の覇気",
      romanizedName: "Busoshoku Haki",
      colorAccent: "text-treasure",
      summary: "A form of Haki that allows the user to use their spiritual energy to create an invisible, or black-hardened armor around themselves, granting incredible defensive and offensive capabilities.",
      advancedTechniques: [
        { name: "Emission (Ryuo)", description: "Allows the user to project their Armament Haki outward from their body to strike targets from a short distance without making direct physical contact." },
        { name: "Internal Destruction", description: "The ultimate grade of Armament Haki where the emitted spirit enters the target's body or object and completely obliterates it from the inside out." },
      ],
      knownUsers: [
        { name: "Monkey D. Garp", title: "Marine Hero", image: "https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=800&auto=format&fit=crop" },
        { name: "Roronoa Zoro", title: "King of Hell", image: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=800&auto=format&fit=crop" },
        { name: "Silvers Rayleigh", title: "Dark King", image: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?q=80&w=800&auto=format&fit=crop" },
      ],
      examples: [
        { event: "Garp's Galaxy Impact", description: "Garp levels an entire pirate stronghold town on Hachinosu with a massive Armament/Conqueror burst." },
        { event: "Luffy destroys Yamato's Explosive Cuffs", description: "Luffy utilizes Internal Destruction to successfully crush Yamato's explosive handcuffs before they detonate." },
      ],
    },
    "observation-haki": {
      name: "Observation Haki",
      japaneseName: "見聞色の覇気",
      romanizedName: "Kenbunshoku Haki",
      colorAccent: "text-emerald",
      summary: "A form of Haki that grants the user a sixth sense that allows them to sense the presence, strength, and emotions of others, as well as predict an opponent's immediate movements in battle.",
      advancedTechniques: [
        { name: "Future Sight (Advanced Kenbunshoku)", description: "Highly advanced users can literally look several seconds into the immediate future to see exactly what an opponent will do before they execute their attack." },
        { name: "Universal Voice Sensing", description: "Allows the wielder to hear the inner voices and emotions of thousands of people simultaneously across an entire island." },
      ],
      knownUsers: [
        { name: "Charlotte Katakuri", title: "Sweet Commander", image: "https://images.unsplash.com/photo-1505118380757-91f5f563b031?q=80&w=800&auto=format&fit=crop" },
        { name: "Shanks", title: "Emperor", image: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=800&auto=format&fit=crop" },
        { name: "Usopp", title: "God Usopp", image: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=800&auto=format&fit=crop" },
      ],
      examples: [
        { event: "Shanks foresees Kid's Railgun destruction", description: "Shanks utilizes Future Sight off Elbaf to witness Eustass Kid obliterating his allied fleet, prompting immediate interception." },
        { event: "Usopp snipes Sugar across Dressrosa", description: "Usopp awakens his Observation Haki to perceive the exact aura coordinates of Luffy, Law, and Sugar through solid palace walls." },
      ],
    },
  };

  const haki = hakiData[hakiSlug] || hakiData["conquerors-haki"];

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[50vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-treasure/20 via-ocean-deep to-ocean-royal pointer-events-none" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs
            items={[
              { label: "Grand Line Wiki", href: "/" },
              { label: "Haki Types", href: "/haki" },
              { label: haki.name },
            ]}
          />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <span className="inline-block bg-wood text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-sm mb-3">
                SPIRITUAL ARMAMENT
              </span>
              <h1 className="text-5xl sm:text-6xl md:text-7xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
                {haki.name}
              </h1>
              <p className="text-xl font-cinematic text-treasure italic mt-1">
                {haki.japaneseName} • {haki.romanizedName}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MAIN LORE TABS */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <Tabs
          items={[
            {
              id: "guide",
              label: "HAKI MANIFEST",
              content: (
                <div className="space-y-16">
                  {/* Summary Dossier */}
                  <TreasureMapContainer>
                    <h3 className="text-3xl font-cinematic font-bold text-foreground mb-6 border-b-2 border-border pb-3 flex items-center">
                      <Shield className="w-8 h-8 mr-3 text-treasure" /> UNIVERSAL PRINCIPLE
                    </h3>
                    <p className="font-sans text-lg text-foreground leading-relaxed font-medium">
                      {haki.summary}
                    </p>
                  </TreasureMapContainer>

                  {/* Advanced Techniques Accordion */}
                  <div className="space-y-6">
                    <h3 className="text-3xl font-cinematic font-bold text-foreground tracking-wide flex items-center">
                      <Zap className="w-8 h-8 mr-3 text-treasure" /> ADVANCED APPLICATION GRADES
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {haki.advancedTechniques.map((tech: any, i: number) => (
                        <div key={i} className="bg-ocean-deep border-4 border-treasure rounded-3xl p-8 shadow-premium-ocean text-ocean-foam space-y-4">
                          <h4 className="text-2xl font-cinematic font-bold text-treasure">{tech.name}</h4>
                          <p className="font-sans text-base text-ocean-foam/80 leading-relaxed font-medium">{tech.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Known Legendary Users */}
                  <div className="space-y-8">
                    <SectionHeader title="KNOWN SUPREME WIELDERS" subtitle="Masters of the Spiritual Color" />
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                      {haki.knownUsers.map((u: any, i: number) => (
                        <CharacterCard
                          key={i}
                          name={u.name}
                          epithet={u.title}
                          image={u.image}
                          faction="yonko"
                          onClick={() => (window.location.href = `/characters/${u.name.toLowerCase().replace(/ /g, "-")}`)}
                          className="w-full max-w-sm mx-auto"
                        />
                      ))}
                    </div>
                  </div>

                  {/* Examples Table */}
                  <div className="space-y-6">
                    <h3 className="text-3xl font-cinematic font-bold text-foreground tracking-wide flex items-center">
                      <Sparkles className="w-8 h-8 mr-3 text-treasure" /> HISTORICAL EXAMPLES
                    </h3>
                    <Table
                      columns={[
                        { header: "Historical Event", accessor: "event", className: "font-cinematic text-xl font-bold text-foreground" },
                        { header: "Tactical Execution", accessor: "description", className: "font-sans text-base text-muted-foreground" },
                      ]}
                      data={haki.examples}
                    />
                  </div>
                </div>
              ),
            },
          ]}
        />
      </div>

      <Footer />
    </div>
  );
}
