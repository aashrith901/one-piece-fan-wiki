"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/buttons";
import { Tabs, Accordion, Gallery, Table } from "@/components/ui/navigation-ui";
import { CharacterCard } from "@/components/ui/cards";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { Shield, Flame, Compass, Anchor, Sparkles, Award } from "lucide-react";

// ============================================================================
// WEAPON FULL LORE DATABASE VIEW
// ============================================================================

export interface WeaponViewProps {
  weaponSlug?: string;
}

export default function WeaponView({ weaponSlug = "ace-supreme-grade" }: WeaponViewProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Static rich production data simulating Drizzle ORM infers for absolute reliability
  const weaponsData: Record<string, any> = {
    "ace-supreme-grade": {
      name: "Ace",
      japaneseName: "エース",
      type: "Cutlass",
      grade: "Supreme Grade (Saijo O Wazamono)",
      creator: "Unknown Legendary Bladesmith",
      owner: { name: "Gol D. Roger", title: "Pirate King", image: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=800&auto=format&fit=crop" },
      imageUrl: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=1200&auto=format&fit=crop",
      summary: "A cutlass that was wielded by the Pirate King, Gol D. Roger, as his signature primary weapon throughout his entire piratical career. It is one of the 12 Supreme Grade Meito blades.",
      abilities: "Capable of withstanding immense Conqueror's and Armament Haki infusion, capable of executing legendary attacks like 'Kamusari' (Divine Departure) that can send opposing emperors flying without physical blade touch.",
      history: "Accompanied Roger across the entire Grand Line, clashing with Whitebeard's Murakumogiri and Garp's fists. Following Roger's execution, the whereabouts of Ace remain undisclosed in the annals of history.",
      gallery: [
        { src: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=800&auto=format&fit=crop", title: "Ace Cutlass", alt: "Roger's Sword" },
        { src: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=800&auto=format&fit=crop", title: "Divine Departure", alt: "Roger clashing with Oden" },
      ],
    },
    "yubashiri": {
      name: "Yubashiri",
      japaneseName: "雪走",
      type: "Katana",
      grade: "Skillful Grade (Ryo Wazamono)",
      creator: "Unknown Family Heirloom",
      owner: { name: "Roronoa Zoro", title: "Pirate Hunter", image: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=800&auto=format&fit=crop" },
      imageUrl: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=1200&auto=format&fit=crop",
      summary: "A lightweight katana given to Zoro by Ipponmatsu in Loguetown after witnessing Zoro's absolute dedication to his cursed Sandai Kitetsu blade.",
      abilities: "Extremely lightweight and fast blade, allowing Zoro to execute ultra-fast cutting techniques with minimal exertion.",
      history: "Tragically destroyed during the Buster Call at Enies Lobby by Shu, a Marine captain possessing the Sabi Sabi no Mi (Rust Fruit). Zoro later put its remains to rest at the Rumbar Pirates' gravesite on Thriller Bark.",
      gallery: [
        { src: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=800&auto=format&fit=crop", title: "Yubashiri Wielded", alt: "Zoro Katana" },
      ],
    },
  };

  const weapon = weaponsData[weaponSlug] || weaponsData["ace-supreme-grade"];

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[50vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <img src={weapon.imageUrl} alt={weapon.name} className="absolute inset-0 w-full h-full object-cover opacity-30 object-center" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-ocean-deep/50 to-transparent" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs
            items={[
              { label: "Grand Line Wiki", href: "/" },
              { label: "Meito Weapons", href: "/weapons" },
              { label: weapon.name },
            ]}
          />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <span className="inline-block bg-wood text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-sm mb-3">
                {weapon.grade}
              </span>
              <h1 className="text-5xl sm:text-6xl md:text-7xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
                {weapon.name}
              </h1>
              <p className="text-xl font-cinematic text-treasure italic mt-1">
                {weapon.japaneseName} • {weapon.type}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MAIN LORE TABS */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <Tabs
          items={[
            {
              id: "blueprint",
              label: "MEITO BLUEPRINT",
              content: (
                <div className="space-y-16">
                  {/* Wielder & Dossier */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
                    <div className="lg:col-span-5 space-y-8">
                      <h3 className="text-2xl font-cinematic font-bold text-foreground mb-4 border-b-2 border-border pb-2 flex items-center">
                        <Shield className="w-6 h-6 mr-2 text-treasure" /> MASTER WIELDER
                      </h3>
                      <CharacterCard
                        name={weapon.owner.name}
                        epithet={`Wielder of ${weapon.name}`}
                        image={weapon.owner.image}
                        faction="yonko"
                        onClick={() => (window.location.href = `/characters/${weapon.owner.name.toLowerCase().replace(/ /g, "-")}`)}
                        className="w-full max-w-full"
                      />
                    </div>
                    <div className="lg:col-span-7 space-y-12">
                      <TreasureMapContainer>
                        <h3 className="text-3xl font-cinematic font-bold text-foreground mb-6 border-b-2 border-border pb-3 flex items-center">
                          <Anchor className="w-8 h-8 mr-3 text-treasure" /> LEGENDARY SPECIFICATION
                        </h3>
                        <p className="font-sans text-lg text-foreground leading-relaxed font-medium mb-6">
                          {weapon.summary}
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 font-sans text-base border-t border-border pt-6">
                          <div><span className="font-bold text-xs uppercase text-muted-foreground block">Meito Grade</span>{weapon.grade}</div>
                          <div><span className="font-bold text-xs uppercase text-muted-foreground block">Armament Class</span>{weapon.type}</div>
                        </div>
                      </TreasureMapContainer>

                      {/* Combat Capabilities Panel */}
                      <WoodenPanel className="space-y-4 text-paper">
                        <h4 className="text-2xl font-cinematic font-bold text-treasure flex items-center border-b border-treasure/30 pb-4">
                          <Sparkles className="w-7 h-7 mr-3 text-treasure" /> COMBAT ARSENAL
                        </h4>
                        <p className="font-sans text-base text-paper/90 leading-relaxed font-medium">
                          {weapon.abilities}
                        </p>
                      </WoodenPanel>
                    </div>
                  </div>

                  {/* History & Origin */}
                  <TreasureMapContainer>
                    <h3 className="text-3xl font-cinematic font-bold text-foreground mb-6 border-b-2 border-border pb-3 flex items-center">
                      <Compass className="w-8 h-8 mr-3 text-treasure" /> HISTORICAL ANNALS
                    </h3>
                    <p className="font-sans text-lg text-foreground leading-relaxed font-medium">
                      {weapon.history}
                    </p>
                  </TreasureMapContainer>

                  {/* Gallery */}
                  <div className="space-y-12">
                    <SectionHeader title="MEITO EXHIBITION" subtitle="Official Curated Imagery" />
                    <Gallery images={weapon.gallery} />
                  </div>
                </div>
              ),
            },
          ]}
        />
      </div>

      <Footer />
    </div>
  );
}
