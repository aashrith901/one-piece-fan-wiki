"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, Select } from "@/components/ui/buttons";
import { Tabs, Accordion, Table } from "@/components/ui/navigation-ui";
import { DevilFruitCard, CharacterCard } from "@/components/ui/cards";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { Flame, Sparkles, AlertCircle, RefreshCw, Scale, Shield, Zap } from "lucide-react";

// ============================================================================
// DEVIL FRUIT FULL LORE DATABASE & COMPARISON VIEW
// ============================================================================

export interface DevilFruitViewProps {
  fruitSlug?: string;
}

export default function DevilFruitView({ fruitSlug = "ope-ope-no-mi" }: DevilFruitViewProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [compareFruit1, setCompareFruit1] = useState("ope-ope-no-mi");
  const [compareFruit2, setCompareFruit2] = useState("goro-goro-no-mi");

  // Static rich production data simulating Drizzle ORM infers for absolute reliability
  const fruitsData: Record<string, any> = {
    "ope-ope-no-mi": {
      name: "Ope Ope no Mi",
      meaning: "Surgery / Ultimate Operation",
      type: "Paramecia",
      isAwakened: true,
      currentUser: { name: "Trafalgar D. Water Law", image: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?q=80&w=800&auto=format&fit=crop", bounty: "3,000,000,000" },
      abilities: "Allows the user to create a spherical space called 'ROOM', within which they have complete control over the orientation, displacement, and configuration of anything inside.",
      strengths: "Ignores conventional durability within the ROOM; can instantly perform amputations, teleport objects/people, and generate high-voltage countershocks.",
      weaknesses: "Consumes immense stamina to maintain and expand the ROOM. Standard sea water and seastone weaknesses.",
      awakening: "Allows the user to apply miniature ROOMs directly to their weapons (e.g., KROOM), allowing their blade to phase through targets and release internal shockwaves directly into internal organs.",
      relatedCharacters: ["Donquixote Rosinante (Corazon)", "Donquixote Doflamingo", "Nefertari D. Lami"],
    },
    "goro-goro-no-mi": {
      name: "Goro Goro no Mi",
      meaning: "Thunder / Lightning",
      type: "Logia",
      isAwakened: false,
      currentUser: { name: "God Enel", image: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=800&auto=format&fit=crop", bounty: "500,000,000 (Estimate)" },
      abilities: "Grants the user the ability to create, control, and transform into lightning at will, allowing near-instantaneous travel at the speed of lightning.",
      strengths: "Utterly invulnerable to physical attacks without Armament Haki; can produce up to 200 million volts of electricity and restart the user's own heart if stopped.",
      weaknesses: "Completely ineffective against natural insulators like rubber (Monkey D. Luffy). Standard sea water and seastone weaknesses.",
      awakening: "Unknown / Not officially demonstrated in canon.",
      relatedCharacters: ["Monkey D. Luffy", "Gan Fall", "Wyper"],
    },
    "uwo-uwo-no-mi-seiryu": {
      name: "Uwo Uwo no Mi, Model: Seiryu",
      meaning: "Azure Dragon",
      type: "Mythical Zoan",
      isAwakened: true,
      currentUser: { name: "Kaido of the Beasts", image: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=800&auto=format&fit=crop", bounty: "4,611,100,000" },
      abilities: "Allows the user to transform into a massive, legendary full Azure Dragon or a hybrid human-dragon form at will.",
      strengths: "Provides near-impenetrable dragon scales, immense physical lifting strength, and the ability to breathe destructive fire blasts (Bolo Breath), lightning, and wind blades.",
      weaknesses: "Massive size in full dragon form makes the user an easy target for fast opponents. Standard sea water and seastone weaknesses.",
      awakening: "Greatly increased recovery rate, expanded muscle mass in hybrid form, and the ultimate Flaming Drum Dragon form (Kaen Daiko) which vaporizes anything it touches.",
      relatedCharacters: ["Big Mom (Charlotte Linlin - Gave him the fruit)", "Monkey D. Luffy", "Kozuki Oden", "Yamato"],
    },
  };

  const fruit = fruitsData[fruitSlug] || fruitsData["ope-ope-no-mi"];
  const comp1 = fruitsData[compareFruit1];
  const comp2 = fruitsData[compareFruit2];

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[50vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-treasure/20 via-ocean-deep to-ocean-royal pointer-events-none" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs
            items={[
              { label: "Grand Line Wiki", href: "/" },
              { label: "Devil Fruits", href: "/devil-fruits" },
              { label: fruit.name },
            ]}
          />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <div className="flex items-center space-x-3 mb-3">
                <span className="inline-block bg-wood text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-sm">
                  {fruit.type}
                </span>
                {fruit.isAwakened && (
                  <span className="flex items-center bg-sunset-crimson text-white px-4 py-1.5 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase border border-treasure shadow-glowing-bounty">
                    <Sparkles className="w-4 h-4 mr-1 text-treasure" /> AWAKENED
                  </span>
                )}
              </div>
              <h1 className="text-5xl sm:text-6xl md:text-7xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
                {fruit.name}
              </h1>
              <p className="text-xl font-sans text-ocean-foam/80 italic mt-1">
                Meaning: "{fruit.meaning}"
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MAIN LORE TABS */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <Tabs
          items={[
            {
              id: "encyclopedia",
              label: "FRUIT ENCYCLOPEDIA",
              content: (
                <div className="space-y-16">
                  {/* Dossier & Current User */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
                    <div className="lg:col-span-5 space-y-8">
                      <h3 className="text-2xl font-cinematic font-bold text-foreground mb-4 border-b-2 border-border pb-2 flex items-center">
                        <Zap className="w-6 h-6 mr-2 text-treasure" /> CURRENT WIELDER
                      </h3>
                      <CharacterCard
                        name={fruit.currentUser.name}
                        epithet={`Wielder of ${fruit.name}`}
                        image={fruit.currentUser.image}
                        bounty={fruit.currentUser.bounty}
                        faction="pirate"
                        onClick={() => (window.location.href = `/characters/${fruit.currentUser.name.toLowerCase().replace(/ /g, "-")}`)}
                        className="w-full max-w-full"
                      />
                    </div>
                    <div className="lg:col-span-7 space-y-12">
                      <TreasureMapContainer>
                        <h3 className="text-3xl font-cinematic font-bold text-foreground mb-6 border-b-2 border-border pb-3 flex items-center">
                          <Flame className="w-8 h-8 mr-3 text-sunset animate-bounce" /> ABILITIES & COMBAT USAGE
                        </h3>
                        <p className="font-sans text-lg text-foreground leading-relaxed font-medium mb-6">
                          {fruit.abilities}
                        </p>
                        <div className="border-t border-border pt-6 space-y-6">
                          <div>
                            <span className="font-cinematic text-sm font-bold text-treasure-dark block uppercase mb-1">STRENGTHS & ADVANTAGES</span>
                            <p className="font-sans text-base text-foreground leading-relaxed">{fruit.strengths}</p>
                          </div>
                          <div>
                            <span className="font-cinematic text-sm font-bold text-destructive block uppercase mb-1">WEAKNESSES & VULNERABILITIES</span>
                            <p className="font-sans text-base text-foreground leading-relaxed">{fruit.weaknesses}</p>
                          </div>
                        </div>
                      </TreasureMapContainer>

                      {/* Awakening Callout Panel */}
                      <WoodenPanel className="space-y-4 text-paper">
                        <h4 className="text-2xl font-cinematic font-bold text-treasure flex items-center border-b border-treasure/30 pb-4">
                          <Sparkles className="w-7 h-7 mr-3 text-treasure" /> AWAKENING STAGE
                        </h4>
                        <p className="font-sans text-base text-paper/90 leading-relaxed font-medium">
                          {fruit.awakening}
                        </p>
                      </WoodenPanel>
                    </div>
                  </div>

                  {/* Related Characters */}
                  <div className="space-y-6">
                    <h3 className="text-3xl font-cinematic font-bold text-foreground tracking-wide flex items-center">
                      <Shield className="w-8 h-8 mr-3 text-treasure" /> RELATED LORE CHARACTERS
                    </h3>
                    <div className="flex flex-wrap gap-4">
                      {fruit.relatedCharacters.map((c: string, i: number) => (
                        <span key={i} className="px-6 py-3 rounded-2xl bg-card border-2 border-border font-cinematic text-lg font-bold text-foreground shadow-sm">
                          {c}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ),
            },
            {
              id: "comparison",
              label: "DEVIL FRUIT COMPARISON TOOL",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="CURSED FRUIT COMPARISON" subtitle="Side-by-Side Analytical Engine" />
                  
                  {/* Selectors */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 bg-card border-2 border-border rounded-3xl p-8 shadow-paper-lift">
                    <div>
                      <span className="font-cinematic text-sm font-bold text-muted-foreground block uppercase mb-2">SLOT 1: SELECT FRUIT</span>
                      <Select
                        options={[
                          { label: "Ope Ope no Mi (Law)", value: "ope-ope-no-mi" },
                          { label: "Goro Goro no Mi (Enel)", value: "goro-goro-no-mi" },
                          { label: "Uwo Uwo no Mi: Seiryu (Kaido)", value: "uwo-uwo-no-mi-seiryu" },
                        ]}
                        value={compareFruit1}
                        onChange={(e) => setCompareFruit1(e.target.value)}
                        className="font-cinematic font-bold text-lg h-14"
                      />
                    </div>
                    <div>
                      <span className="font-cinematic text-sm font-bold text-muted-foreground block uppercase mb-2">SLOT 2: SELECT FRUIT</span>
                      <Select
                        options={[
                          { label: "Ope Ope no Mi (Law)", value: "ope-ope-no-mi" },
                          { label: "Goro Goro no Mi (Enel)", value: "goro-goro-no-mi" },
                          { label: "Uwo Uwo no Mi: Seiryu (Kaido)", value: "uwo-uwo-no-mi-seiryu" },
                        ]}
                        value={compareFruit2}
                        onChange={(e) => setCompareFruit2(e.target.value)}
                        className="font-cinematic font-bold text-lg h-14"
                      />
                    </div>
                  </div>

                  {/* Comparison Columns */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Slot 1 View */}
                    <div className="bg-ocean-deep border-4 border-treasure rounded-3xl p-8 shadow-premium-ocean text-ocean-foam space-y-6">
                      <div className="flex items-center justify-between border-b border-ocean-royal pb-4">
                        <h4 className="text-3xl font-cinematic font-bold text-treasure">{comp1.name}</h4>
                        <span className="bg-wood text-treasure px-3 py-1 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase border border-treasure">
                          {comp1.type}
                        </span>
                      </div>
                      <div className="space-y-6 font-sans text-base">
                        <div><span className="font-cinematic font-bold text-treasure block text-xs uppercase mb-1">CURRENT USER</span>{comp1.currentUser.name}</div>
                        <div><span className="font-cinematic font-bold text-treasure block text-xs uppercase mb-1">CORE ABILITIES</span>{comp1.abilities}</div>
                        <div><span className="font-cinematic font-bold text-treasure block text-xs uppercase mb-1">STRENGTHS</span>{comp1.strengths}</div>
                        <div><span className="font-cinematic font-bold text-destructive block text-xs uppercase mb-1">WEAKNESSES</span>{comp1.weaknesses}</div>
                        <div><span className="font-cinematic font-bold text-sunset block text-xs uppercase mb-1">AWAKENING STATUS</span>{comp1.awakening}</div>
                      </div>
                    </div>

                    {/* Slot 2 View */}
                    <div className="bg-ocean-deep border-4 border-treasure rounded-3xl p-8 shadow-premium-ocean text-ocean-foam space-y-6">
                      <div className="flex items-center justify-between border-b border-ocean-royal pb-4">
                        <h4 className="text-3xl font-cinematic font-bold text-treasure">{comp2.name}</h4>
                        <span className="bg-wood text-treasure px-3 py-1 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase border border-treasure">
                          {comp2.type}
                        </span>
                      </div>
                      <div className="space-y-6 font-sans text-base">
                        <div><span className="font-cinematic font-bold text-treasure block text-xs uppercase mb-1">CURRENT USER</span>{comp2.currentUser.name}</div>
                        <div><span className="font-cinematic font-bold text-treasure block text-xs uppercase mb-1">CORE ABILITIES</span>{comp2.abilities}</div>
                        <div><span className="font-cinematic font-bold text-treasure block text-xs uppercase mb-1">STRENGTHS</span>{comp2.strengths}</div>
                        <div><span className="font-cinematic font-bold text-destructive block text-xs uppercase mb-1">WEAKNESSES</span>{comp2.weaknesses}</div>
                        <div><span className="font-cinematic font-bold text-sunset block text-xs uppercase mb-1">AWAKENING STATUS</span>{comp2.awakening}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ),
            },
          ]}
        />
      </div>

      <Footer />
    </div>
  );
}
