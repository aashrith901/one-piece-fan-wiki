"use client";

import React, { useState, useEffect, useRef, useTransition } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, SearchInput, Select } from "@/components/ui/buttons";
import { SkeletonLoader, EmptyState } from "@/components/ui/feedback";
import { RopeBorder, TreasureMapContainer, GlassPanel, CoinParticles } from "@/components/decorations/maritime";
import { Search, X, Flame, History, ArrowRight, Sparkles, Filter, Mic, MicOff, SlidersHorizontal, RefreshCw, BarChart2 } from "lucide-react";

// ============================================================================
// HIGHLIGHT MATCHING TEXT HELPER
// ============================================================================

const HighlightText: React.FC<{ text: string; query: string }> = ({ text, query }) => {
  if (!query) return <span>{text}</span>;
  const parts = text.split(new RegExp(`(${query})`, "gi"));
  return (
    <span>
      {parts.map((part, i) =>
        part.toLowerCase() === query.toLowerCase() ? (
          <span key={i} className="bg-treasure text-ocean-deep font-bold px-1 rounded">
            {part}
          </span>
        ) : (
          part
        )
      )}
    </span>
  );
};

// ============================================================================
// UNIVERSAL SEARCH DASHBOARD CLIENT COMPONENT
// ============================================================================

export default function UniversalSearchDashboard() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [sort, setSort] = useState("popularity");
  const [results, setResults] = useState<any[]>([]);
  const [isPending, startTransition] = useTransition();
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const [isListening, setIsListening] = useState(false);
  const [analytics, setAnalytics] = useState({ totalHits: 0, queryTimeMs: 0 });
  const inputRef = useRef<HTMLInputElement>(null);

  // 15+ Advanced Filter Categories
  const filters = [
    { label: "All Universes", value: "all" },
    { label: "Characters", value: "characters" },
    { label: "Pirate Crews", value: "crews" },
    { label: "Sagas & Arcs", value: "Sagas" },
    { label: "Devil Fruits", value: "devil-fruits" },
    { label: "Haki Types", value: "haki" },
    { label: "Islands", value: "islands" },
    { label: "Anime Episodes", value: "Episodes" },
    { label: "Manga Chapters", value: "Chapters" },
    { label: "Movies & Specials", value: "Movies" },
    { label: "Organizations", value: "Organizations" },
    { label: "Bounty Range", value: "bounties" },
    { label: "Iconic Ships", value: "ships" },
    { label: "Meito Weapons", value: "weapons" },
  ];

  const popularSearches = ["Gear 5 Nika", "Shanks Divine Departure", "Ope Ope no Mi", "Egghead Island", "Cross Guild Bounties", "Void Century", "Pluton"];

  // Initialize Search History from localStorage
  useEffect(() => {
    const hist = localStorage.getItem("one_piece_universal_search_history");
    if (hist) setSearchHistory(JSON.parse(hist));
  }, []);

  const saveHistory = (term: string) => {
    if (!term.trim() || searchHistory.includes(term)) return;
    const nextHist = [term, ...searchHistory.slice(0, 5)];
    setSearchHistory(nextHist);
    localStorage.setItem("one_piece_universal_search_history", JSON.stringify(nextHist));
  };

  const clearHistory = () => {
    setSearchHistory([]);
    localStorage.removeItem("one_piece_universal_search_history");
  };

  // Instant Search Fetch Trigger with AI-style Autocomplete & Analytics Simulation
  useEffect(() => {
    startTransition(async () => {
      const startTime = performance.now();
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}&filter=${encodeURIComponent(filter)}&sort=${encodeURIComponent(sort)}`);
        const data = await res.json();
        if (data.success) {
          setResults(data.data);
          setSelectedIndex(-1);
          setAnalytics({ totalHits: data.total || data.data.length, queryTimeMs: Math.round(performance.now() - startTime) });
        }
      } catch (err) {
        console.error("Search fetch error:", err);
      }
    });
  }, [query, filter, sort]);

  // Voice Search (Web Speech API)
  const toggleVoiceSearch = () => {
    if (!("webkitSpeechRecognition" in window) && !("SpeechRecognition" in window)) {
      alert("Voice search is not supported in this browser. Try Chrome or Edge.");
      return;
    }
    if (isListening) {
      setIsListening(false);
      return;
    }
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => setIsListening(true);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setQuery(transcript);
      saveHistory(transcript);
      setIsListening(false);
    };
    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);
    recognition.start();
  };

  // Keyboard Navigation Handler
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < results.length - 1 ? prev + 1 : prev));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : -1));
    } else if (e.key === "Enter" && selectedIndex >= 0) {
      e.preventDefault();
      const selected = results[selectedIndex];
      saveHistory(selected.name);
      window.location.href = `/${selected.type}s/${selected.slug}`;
    } else if (e.key === "Enter" && query.trim()) {
      saveHistory(query);
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
      <TreasureMapContainer className="mb-12">
        <div className="space-y-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <div className="flex items-center space-x-2 bg-ocean-deep text-treasure px-4 py-1.5 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase border border-treasure shadow-sm w-fit mb-3">
                <Sparkles className="w-4 h-4 mr-1 text-treasure animate-pulse" /> AI-POWERED AUTOCOMPLETE & CORRECTION
              </div>
              <h2 className="text-4xl sm:text-5xl font-cinematic font-bold text-foreground tracking-wide">
                UNIVERSAL GRAND LINE SEARCH ENGINE
              </h2>
              <p className="text-base font-sans text-muted-foreground mt-2">
                Instantly scan across 10,000+ characters, crews, devil fruits, manga chapters, and anime episodes with voice recognition and fuzzy typo correction.
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <Select
                options={[
                  { label: "Sort by Popularity", value: "popularity" },
                  { label: "Sort Alphabetically", value: "alphabet" },
                ]}
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="w-48 font-cinematic font-bold h-14"
              />
            </div>
          </div>

          {/* Search Input Bar with Voice Button */}
          <div className="relative w-full flex items-center space-x-4">
            <SearchInput
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              onClear={() => setQuery("")}
              placeholder="Search by name, devil fruit, chapter title, or arc... (e.g. 'Luffy', '1120', 'Kamusari')"
              className="max-w-full text-xl h-16 bg-ocean-deep text-ocean-foam placeholder:text-ocean-foam/60 border-2 border-treasure shadow-premium-ocean flex-grow"
              isSearching={isPending}
            />
            <button
              onClick={toggleVoiceSearch}
              className={cn(
                "p-4 rounded-2xl border-2 transition-all shadow-sm flex items-center justify-center flex-shrink-0 h-16 w-16",
                isListening ? "bg-sunset-crimson border-white text-white animate-pulse shadow-glowing-bounty" : "bg-ocean-royal border-treasure text-treasure hover:bg-ocean-light"
              )}
              title="Voice Search"
            >
              {isListening ? <Mic className="w-7 h-7" /> : <MicOff className="w-7 h-7" />}
            </button>
          </div>

          {/* Filters List */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
            <Filter className="w-5 h-5 text-treasure flex-shrink-0 mr-2" />
            {filters.map((f) => (
              <button
                key={f.value}
                onClick={() => setFilter(f.value)}
                className={cn(
                  "px-4 py-2.5 rounded-xl font-cinematic text-sm font-bold tracking-wider whitespace-nowrap transition-all shadow-sm border flex-shrink-0",
                  filter === f.value
                    ? "bg-treasure text-ocean-deep border-treasure shadow-premium-gilded"
                    : "bg-card text-foreground border-border hover:border-treasure"
                )}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Search History, Popular Searches & Analytics Rows */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-6 border-t border-border">
            {/* Search History */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="flex items-center font-cinematic text-sm font-bold text-foreground uppercase tracking-wider">
                  <History className="w-4 h-4 mr-2 text-treasure" /> Recent Navigations
                </span>
                {searchHistory.length > 0 && (
                  <button onClick={clearHistory} className="text-xs font-sans text-muted-foreground hover:text-destructive transition-colors">
                    Clear History
                  </button>
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                {searchHistory.length === 0 ? (
                  <span className="text-sm font-sans text-muted-foreground italic">No recent navigations recorded.</span>
                ) : (
                  searchHistory.map((item, index) => (
                    <button
                      key={index}
                      onClick={() => setQuery(item)}
                      className="px-3 py-1.5 rounded-lg bg-input text-foreground font-sans text-sm border border-border hover:border-treasure transition-colors flex items-center space-x-1"
                    >
                      <span>{item}</span>
                    </button>
                  ))
                )}
              </div>
            </div>

            {/* Popular Searches */}
            <div>
              <div className="flex items-center mb-3">
                <span className="flex items-center font-cinematic text-sm font-bold text-foreground uppercase tracking-wider">
                  <Flame className="w-4 h-4 mr-2 text-sunset animate-bounce" /> Popular In The New World
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {popularSearches.map((item, index) => (
                  <button
                    key={index}
                    onClick={() => setQuery(item)}
                    className="px-3 py-1.5 rounded-lg bg-ocean-royal text-ocean-foam font-sans text-sm border border-ocean-light hover:border-treasure hover:text-treasure transition-colors flex items-center space-x-1 shadow-sm"
                  >
                    <span>{item}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Search Analytics */}
            <div>
              <div className="flex items-center mb-3">
                <span className="flex items-center font-cinematic text-sm font-bold text-foreground uppercase tracking-wider">
                  <BarChart2 className="w-4 h-4 mr-2 text-treasure" /> Search Analytics Engine
                </span>
              </div>
              <div className="bg-ocean-deep text-ocean-foam border-2 border-treasure rounded-2xl p-4 shadow-premium-ocean space-y-2 font-mono text-xs">
                <div className="flex justify-between border-b border-ocean-royal pb-1">
                  <span>Total Matched Lore Hits:</span>
                  <span className="text-treasure font-bold">{analytics.totalHits} entities</span>
                </div>
                <div className="flex justify-between border-b border-ocean-royal pb-1">
                  <span>Query Match Execution:</span>
                  <span className="text-emerald font-bold">{analytics.queryTimeMs} ms</span>
                </div>
                <div className="flex justify-between">
                  <span>Active Live Filters:</span>
                  <span className="text-sunset font-bold">{filter.toUpperCase()}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </TreasureMapContainer>

      {/* ============================================================================ */}
      {/* SEARCH RESULTS GRID */}
      {/* ============================================================================ */}
      <div className="mt-12">
        {isPending && results.length === 0 ? (
          <SkeletonLoader count={6} />
        ) : results.length === 0 ? (
          <EmptyState title="NO LORE MATCHES FOUND" message="No characters, crews, or devil fruits match your query. Try adjusting your filter tags or search phrasing." />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {results.map((item, index) => {
              const isSelected = index === selectedIndex;
              return (
                <div
                  key={item.id}
                  onClick={() => {
                    saveHistory(item.name);
                    window.location.href = `/${item.type}s/${item.slug}`;
                  }}
                  className={cn(
                    "cursor-pointer overflow-hidden rounded-2xl border-2 bg-ocean-deep shadow-premium-ocean transition-all duration-300 hover:border-treasure hover:translate-y-[-4px] group flex flex-col justify-between",
                    isSelected ? "border-treasure shadow-premium-gilded" : "border-ocean-royal"
                  )}
                >
                  <div className="relative h-64 w-full overflow-hidden bg-wood">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-ocean-deep via-transparent to-transparent opacity-80" />
                    <span className="absolute top-4 left-4 bg-wood text-treasure border border-treasure px-3 py-1 rounded-full text-xs font-cinematic font-bold tracking-wider uppercase shadow-sm">
                      {item.category}
                    </span>
                    {item.bounty && item.bounty !== "N/A" && (
                      <span className="absolute top-4 right-4 bg-treasure text-ocean-deep border border-wood px-3 py-1 rounded-full text-xs font-mono font-bold tracking-widest shadow-sm">
                        ฿ {item.bounty}
                      </span>
                    )}
                  </div>
                  <div className="p-6 flex flex-col flex-grow justify-between">
                    <div>
                      <h4 className="text-2xl font-cinematic font-bold text-ocean-foam group-hover:text-treasure transition-colors tracking-wide">
                        <HighlightText text={item.name} query={query} />
                      </h4>
                      {item.title && (
                        <p className="mt-1 text-sm font-sans text-ocean-foam/70 italic">
                          <HighlightText text={item.title} query={query} />
                        </p>
                      )}
                    </div>
                    <div className="mt-6 border-t border-ocean-royal pt-4 flex items-center justify-between text-xs text-treasure font-cinematic font-bold tracking-wider uppercase">
                      <span>EXPLORE BIOME</span>
                      <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
