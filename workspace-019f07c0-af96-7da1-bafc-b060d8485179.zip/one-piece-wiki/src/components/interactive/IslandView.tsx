"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/buttons";
import { Tabs, Accordion, Timeline, Gallery, Table } from "@/components/ui/navigation-ui";
import { CharacterCard, FactCard, IslandCard } from "@/components/ui/cards";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { Compass, Anchor, Shield, Flame, MapPin, Users, Award, CloudRain } from "lucide-react";

// ============================================================================
// ISLAND FULL DEEP EXPLORER VIEW
// ============================================================================

export interface IslandViewProps {
  islandSlug?: string;
}

export default function IslandView({ islandSlug = "egghead-island" }: IslandViewProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Static rich production data simulating Drizzle ORM infers for absolute reliability
  const islandsData: Record<string, any> = {
    "egghead-island": {
      name: "Egghead Island",
      japaneseName: "エッグヘッド",
      region: "New World",
      climate: "Winter Island (Scientifically Controlled Island Climate)",
      logPoseLockTime: "A few days",
      affiliation: "World Government (Research Center)",
      population: "Unknown (Researchers, Pacifista, Seraphim)",
      coverImageUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=1200&auto=format&fit=crop",
      overview: "Known as the 'Future Island' (Mirai-jima), Egghead is the high-tech island housing the legendary laboratory of Dr. Vegapunk. The island is powered by an advanced energy system and is split into the Fabiriophase (factory town) and the Labophase (research platform in the clouds).",
      storyArcs: ["Egghead Island Arc (Final Saga)"],
      importantCharacters: [
        { name: "Dr. Vegapunk", title: "Smartest Man in the World", image: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=800&auto=format&fit=crop" },
        { name: "Monkey D. Luffy", title: "Sun God Nika", image: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=800&auto=format&fit=crop" },
        { name: "Bartholomew Kuma", title: "Former Warlord / Revolutionary", image: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?q=80&w=800&auto=format&fit=crop" },
      ],
      battles: [
        { opponent: "Five Elders (Gorosei) / Marine Buster Call Fleet", location: "Egghead Shores & Labophase", outcome: "Giant Warrior Pirates Intercept / Broadcast Climax" },
        { opponent: "Rob Lucci (CP0)", location: "Fabiriophase", outcome: "Victory for Luffy (Gear 5 vs Awakened Zoan)" },
      ],
      timeline: [
        { year: "Pre-Arc", title: "MADS Research Hub", description: "Vegapunk establishes the island as the ultimate sci-fi research facility." },
        { year: "Straw Hat Arrival", title: "Docking at Egghead", description: "Luffy's crew arrives, befriending Lilith, Atlas, and the Vegapunk satellites." },
        { year: "Buster Call Assault", title: "The Five Elders Descend", description: "Saturn and the Gorosei arrive to obliterate Vegapunk before his worldwide broadcast completes." },
      ],
      locations: [
        { name: "Labophase", desc: "Floating cloud facility containing Vegapunk's Punk Records brain." },
        { name: "Fabiriophase", desc: "Ground-level futuristic town housing researchers and holographic tourism." },
        { name: "Frontier Dome", desc: "Advanced laser defense grid protecting the Labophase from intruders." },
      ],
      gallery: [
        { src: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=800&auto=format&fit=crop", title: "Egghead Labophase", alt: "Future Island" },
        { src: "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?q=80&w=800&auto=format&fit=crop", title: "Pacifista Defense Grid", alt: "Defense Matrix" },
      ],
      trivia: [
        "The climate is artificially manipulated using the Island Air Conditioning system created by Vegapunk.",
        "Egghead's advanced technology is actually an ancient reflection of the highly advanced kingdom from the Void Century 900 years ago.",
      ],
      relatedIslands: ["Wano Country", "Elbaf", "Enies Lobby"],
    },
    "wano-country": {
      name: "Wano Country",
      japaneseName: "ワノ国",
      region: "New World",
      climate: "Various Severe Weather across 6 distinct regions",
      logPoseLockTime: "Untraceable (Requires Vivre Card or special octopus navigation)",
      affiliation: "Straw Hat Territory (Kozuki Shogunate)",
      population: "Millions (Samurai, Citizens, Minks)",
      coverImageUrl: "https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=1200&auto=format&fit=crop",
      overview: "An isolated samurai nation in the New World that was ruled by the tyrannical Shogun Kurozumi Orochi and Emperor Kaido of the Beasts Pirates for 20 years before being liberated by the Straw Hat Alliance.",
      storyArcs: ["Wano Country Arc (Wano Country Saga)"],
      importantCharacters: [
        { name: "Kozuki Oden", title: "Daimyo of Kuri / Legendary Samurai", image: "https://images.unsplash.com/photo-1505118380757-91f5f563b031?q=80&w=800&auto=format&fit=crop" },
        { name: "Monkey D. Luffy", title: "Sun God Nika", image: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=800&auto=format&fit=crop" },
        { name: "Yamato", title: "Oni Princess / Son of Kaido", image: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=800&auto=format&fit=crop" },
      ],
      battles: [
        { opponent: "Kaido & Big Mom Alliance", location: "Onigashima Island Rooftop", outcome: "Victory for Straw Hat Alliance (Emperors Defeated)" },
      ],
      timeline: [
        { year: "20 Years Ago", title: "The Legendary Hour", description: "Kozuki Oden boils to save the Akazaya Nine, entrusting them to open Wano's borders." },
        { year: "Raid on Onigashima", title: "The Fire Festival", description: "Luffy, Law, Kid, and the Samurai invade Onigashima to take down two Emperors." },
      ],
      locations: [
        { name: "Flower Capital", desc: "The beautiful cherry blossom capital where Shogun Momonosuke rules." },
        { name: "Onigashima", desc: "The skull island fortress of the Beasts Pirates." },
        { name: "Kuri Region", desc: "The former lawless wasteland turned into a peaceful farm by Oden." },
      ],
      gallery: [
        { src: "https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=800&auto=format&fit=crop", title: "Flower Capital Palace", alt: "Wano Palace" },
      ],
      trivia: [
        "Wano's borders are physically closed due to massive waterfall walls surrounding the country, which prevent standard Log Pose navigation.",
        "The ancient weapon Pluton is buried deep underneath the old sunken Wano Country.",
      ],
      relatedIslands: ["Zou", "Egghead Island", "Onigashima"],
    },
  };

  const island = islandsData[islandSlug] || islandsData["egghead-island"];

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[60vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <img src={island.coverImageUrl} alt={island.name} className="absolute inset-0 w-full h-full object-cover opacity-30 object-center" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-ocean-deep/50 to-transparent" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs
            items={[
              { label: "Grand Line Wiki", href: "/" },
              { label: "Islands & Realms", href: "/islands" },
              { label: island.name },
            ]}
          />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <span className="inline-block bg-wood text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-sm mb-3">
                {island.region}
              </span>
              <h1 className="text-5xl sm:text-6xl md:text-7xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
                {island.name}
              </h1>
              <p className="text-xl font-cinematic text-treasure italic mt-1">
                {island.japaneseName} • {island.climate}
              </p>
            </div>
            <div>
              <Button variant="gilded" size="lg" onClick={() => (window.location.href = "/world-map")} leftIcon={<Compass className="w-5 h-5 text-ocean-deep" />}>
                VIEW ON INTERACTIVE MAP
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MAIN LORE TABS */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <Tabs
          items={[
            {
              id: "explorer",
              label: "ISLAND EXPLORER",
              content: (
                <div className="space-y-16">
                  {/* Overview Dossier */}
                  <TreasureMapContainer>
                    <h3 className="text-3xl font-cinematic font-bold text-foreground mb-6 border-b-2 border-border pb-3 flex items-center">
                      <MapPin className="w-8 h-8 mr-3 text-treasure" /> GAZETTEER & TOPOGRAPHY
                    </h3>
                    <p className="font-sans text-lg text-foreground leading-relaxed font-medium mb-6">
                      {island.overview}
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 font-sans text-base border-t border-border pt-6">
                      <div><span className="font-bold text-xs uppercase text-muted-foreground block">Climate & Biome</span>{island.climate}</div>
                      <div><span className="font-bold text-xs uppercase text-muted-foreground block">Log Pose Reset Time</span>{island.logPoseLockTime}</div>
                      <div><span className="font-bold text-xs uppercase text-muted-foreground block">Ruler / Affiliation</span>{island.affiliation}</div>
                    </div>
                  </TreasureMapContainer>

                  {/* Topographic Locations Accordion */}
                  <div className="space-y-6">
                    <h3 className="text-3xl font-cinematic font-bold text-foreground tracking-wide flex items-center">
                      <Anchor className="w-8 h-8 mr-3 text-treasure" /> KEY LOCATIONS & SECTORS
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      {island.locations.map((loc: any, i: number) => (
                        <div key={i} className="bg-ocean-deep border-4 border-treasure rounded-3xl p-8 shadow-premium-ocean text-ocean-foam space-y-3">
                          <h4 className="text-2xl font-cinematic font-bold text-treasure">{loc.name}</h4>
                          <p className="font-sans text-base text-ocean-foam/80 leading-relaxed font-medium">{loc.desc}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Important Characters */}
                  <div className="space-y-8">
                    <SectionHeader title="NOTABLE INHABITANTS" subtitle="Legendary Figures of the Territory" />
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                      {island.importantCharacters.map((c: any, i: number) => (
                        <CharacterCard
                          key={i}
                          name={c.name}
                          epithet={c.title}
                          image={c.image}
                          faction="yonko"
                          onClick={() => (window.location.href = `/characters/${c.name.toLowerCase().replace(/ /g, "-")}`)}
                          className="w-full max-w-sm mx-auto"
                        />
                      ))}
                    </div>
                  </div>
                </div>
              ),
            },
            {
              id: "timeline",
              label: "ISLAND CHRONOLOGY",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="ANNALS OF THE ISLAND" subtitle="Historical Events & Sagas" />
                  <div className="max-w-4xl mx-auto">
                    <Timeline events={island.timeline} />
                  </div>
                </div>
              ),
            },
            {
              id: "battles",
              label: "TERRITORIAL CONFLICTS",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="THE BATTLEGROUNDS" subtitle="Fierce Engagements on Island Soil" />
                  <Table
                    columns={[
                      { header: "Clash of Factions", accessor: "opponent", className: "font-cinematic text-xl font-bold text-foreground" },
                      { header: "Specific Sector", accessor: "location", className: "font-sans text-base text-muted-foreground" },
                      { header: "Historical Outcome", accessor: "outcome", className: "font-cinematic text-lg font-bold text-treasure" },
                    ]}
                    data={island.battles}
                  />
                </div>
              ),
            },
            {
              id: "gallery",
              label: "TOPOGRAPHICAL GALLERY",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="SCENIC EXHIBITION" subtitle="Official Curated Imagery" />
                  <Gallery images={island.gallery} />
                </div>
              ),
            },
            {
              id: "trivia",
              label: "TRIVIA & REALMS",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="ANCIENT LORE" subtitle="Secrets & Related Archipelagoes" />
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-6">
                      <h4 className="text-2xl font-cinematic font-bold text-foreground mb-4 border-b-2 border-border pb-2">Geographic Trivia</h4>
                      {island.trivia.map((t: string, i: number) => (
                        <FactCard key={i} title={`FACT #${i + 1}`} fact={t} className="w-full" />
                      ))}
                    </div>
                    <div className="space-y-6">
                      <h4 className="text-2xl font-cinematic font-bold text-foreground mb-4 border-b-2 border-border pb-2">Related Realms</h4>
                      <div className="flex flex-wrap gap-4">
                        {island.relatedIslands.map((r: string, i: number) => (
                          <span key={i} className="px-6 py-3 rounded-2xl bg-card border-2 border-border font-cinematic text-lg font-bold text-foreground shadow-sm">
                            {r}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ),
            },
          ]}
        />
      </div>

      <Footer />
    </div>
  );
}
