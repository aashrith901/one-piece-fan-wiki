"use client";

import React, { useState, useEffect, useTransition } from "react";
import dynamic from "next/dynamic";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, SearchInput, Select, Badge } from "@/components/ui/buttons";
import { SkeletonLoader, LoadingScreen } from "@/components/ui/feedback";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs } from "@/components/navigation/navigation-system";
import { Compass, Search, X, Flame, Anchor, Moon, Sun, CloudRain, SunMedium, Cloud, ChevronRight, Shield, BookOpen } from "lucide-react";

// Dynamically import the Three.js World Map canvas with no SSR for perfect client rendering
const WorldMapCanvas = dynamic(() => import("@/components/three/WorldMapCanvas"), {
  ssr: false,
  loading: () => <LoadingScreen text="Initializing Grand Line Navigation Table..." className="min-h-[75vh]" />,
});

// ============================================================================
// WORLD MAP EXPLORER MAIN SHELL
// ============================================================================

export default function WorldMapExplorer() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [seaFilter, setSeaFilter] = useState("all");
  const [sagaFilter, setSagaFilter] = useState("all");
  const [importanceFilter, setImportanceFilter] = useState("all");

  // Map States
  const [islands, setIslands] = useState<any[]>([]);
  const [seaRoutesData, setSeaRoutesData] = useState<Record<string, any>>({});
  const [selectedIsland, setSelectedIsland] = useState<any | null>(null);
  const [hoveredIsland, setHoveredIsland] = useState<any | null>(null);
  const [activeRoutes, setActiveRoutes] = useState<string[]>(["strawHat"]);
  const [isNight, setIsNight] = useState(false);
  const [weather, setWeather] = useState<"clear" | "clouds" | "storm">("clear");
  const [isPending, startTransition] = useTransition();

  // Timeline Events
  const timelineEvents = [
    { year: "East Blue Saga", title: "Romance Dawn at Foosha Village", desc: "Luffy sets sail, acquiring Zoro, Nami, Usopp, and Sanji.", islandSlug: "foosha-village" },
    { year: "Alabasta Saga", title: "Defeating Crocodile", desc: "Saving Vivi's kingdom from drought and Baroque Works.", islandSlug: "alabasta-kingdom" },
    { year: "Sky Island Saga", title: "Ringing the Golden Bell", desc: "Defeating God Enel in the clouds of Skypiea.", islandSlug: "skypiea" },
    { year: "Water 7 Saga", title: "Buster Call at Enies Lobby", desc: "Declaring war on the World Government to save Nico Robin.", islandSlug: "enies-lobby" },
    { year: "Summit War Saga", title: "The Paramount War", desc: "The tragic clash between Whitebeard, Ace, and the Marines.", islandSlug: "marineford" },
    { year: "Wano Country Saga", title: "Gear 5 Liberation", desc: "Defeating Kaido and restoring the Kozuki Shogunate.", islandSlug: "wano-country" },
    { year: "Final Saga", title: "Egghead Island Incident", desc: "Vegapunk's global broadcast and the Five Elders' assault.", islandSlug: "egghead-island" },
  ];

  useEffect(() => {
    startTransition(async () => {
      try {
        const res = await fetch(`/api/islands?q=${encodeURIComponent(query)}&sea=${encodeURIComponent(seaFilter)}&saga=${encodeURIComponent(sagaFilter)}&importance=${encodeURIComponent(importanceFilter)}`);
        const data = await res.json();
        if (data.success) {
          setIslands(data.data);
          setSeaRoutesData(data.seaRoutes);
        }
      } catch (err) {
        console.error("Island fetch error:", err);
      }
    });
  }, [query, seaFilter, sagaFilter, importanceFilter]);

  const toggleRoute = (route: string) => {
    setActiveRoutes((prev) => (prev.includes(route) ? prev.filter((r) => r !== route) : [...prev, route]));
  };

  const jumpToIsland = (slug: string) => {
    const found = islands.find((i) => i.slug === slug);
    if (found) setSelectedIsland(found);
  };

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* ============================================================================ */}
      {/* 1. 3D INTERACTIVE NAVIGATION TABLE MAP */}
      {/* ============================================================================ */}
      <div className="relative w-full h-[75vh] sm:h-[85vh] bg-ocean-deep overflow-hidden flex flex-col justify-between select-none">
        {/* React Three Fiber Canvas */}
        <WorldMapCanvas
          islands={islands}
          selectedIsland={selectedIsland}
          onSelectIsland={setSelectedIsland}
          onHoverIsland={setHoveredIsland}
          activeRoutes={activeRoutes}
          seaRoutesData={seaRoutesData}
          isNight={isNight}
          weather={weather}
        />

        {/* Top Floating Controls Bar */}
        <div className="relative z-10 p-6 pointer-events-auto flex items-center justify-between max-w-7xl mx-auto w-full gap-4 flex-wrap">
          <Breadcrumbs items={[{ label: "Grand Line Wiki", href: "/" }, { label: "Interactive World Map" }]} className="bg-ocean-deep/80 px-4 py-2 rounded-2xl border border-treasure shadow-sm" />
          
          {/* Day/Night & Weather Panel */}
          <div className="flex items-center space-x-2 bg-ocean-deep/80 border border-treasure p-2 rounded-2xl shadow-premium-ocean">
            <button onClick={() => setIsNight(!isNight)} className={cn("p-2.5 rounded-xl transition-all", isNight ? "bg-treasure text-ocean-deep font-bold" : "text-ocean-foam hover:text-treasure")}>
              {isNight ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </button>
            <div className="h-6 w-[1px] bg-treasure/40" />
            <button onClick={() => setWeather("clear")} className={cn("p-2.5 rounded-xl transition-all", weather === "clear" ? "bg-treasure text-ocean-deep font-bold" : "text-ocean-foam hover:text-treasure")}>
              <SunMedium className="w-5 h-5" />
            </button>
            <button onClick={() => setWeather("clouds")} className={cn("p-2.5 rounded-xl transition-all", weather === "clouds" ? "bg-treasure text-ocean-deep font-bold" : "text-ocean-foam hover:text-treasure")}>
              <Cloud className="w-5 h-5" />
            </button>
            <button onClick={() => setWeather("storm")} className={cn("p-2.5 rounded-xl transition-all", weather === "storm" ? "bg-treasure text-ocean-deep font-bold" : "text-ocean-foam hover:text-treasure")}>
              <CloudRain className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Hover Tooltip Popup */}
        <AnimatePresence>
          {hoveredIsland && !selectedIsland && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="absolute top-28 left-1/2 -translate-x-1/2 z-20 pointer-events-none bg-wooden-plank border-2 border-treasure text-paper px-6 py-4 rounded-3xl shadow-premium-gilded flex items-center space-x-4"
            >
              <Compass className="w-6 h-6 text-treasure animate-spin" />
              <div>
                <h4 className="font-cinematic text-xl font-bold text-treasure">{hoveredIsland.name}</h4>
                <span className="text-xs font-sans text-paper/80 uppercase">{hoveredIsland.region} • {hoveredIsland.climate}</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Bottom Wooden Control Panel / Sea Routes Selectors */}
        <div className="relative z-10 max-w-7xl mx-auto w-full px-4 pb-6 pointer-events-auto">
          <div className="bg-wooden-plank border-4 border-treasure rounded-3xl p-6 shadow-premium-ocean flex flex-col lg:flex-row items-center justify-between gap-6">
            <div>
              <h4 className="font-cinematic text-xl font-bold text-treasure flex items-center">
                <Anchor className="w-6 h-6 mr-2 text-treasure" /> SEA ROUTES NAVIGATION TABLE
              </h4>
              <p className="text-xs font-sans text-paper/80 mt-1">Toggle legendary voyage tracks to view glowing paths across the seas.</p>
            </div>
            <div className="flex flex-wrap gap-2 justify-center">
              {[
                { key: "strawHat", label: "Straw Hat Fleet", color: "border-treasure text-treasure" },
                { key: "rogerPirates", label: "Roger Pirates", color: "border-sunset text-sunset" },
                { key: "marines", label: "Marine Routes", color: "border-ocean-foam text-ocean-foam" },
                { key: "revolutionaries", label: "Revolutionaries", color: "border-sunset-crimson text-sunset-crimson" },
                { key: "yonkoTerritories", label: "Yonko Territories", color: "border-emerald text-emerald" },
              ].map((route) => {
                const isActive = activeRoutes.includes(route.key);
                return (
                  <button
                    key={route.key}
                    onClick={() => toggleRoute(route.key)}
                    className={cn(
                      "px-4 py-2 rounded-xl font-cinematic text-sm font-bold tracking-wider uppercase border-2 transition-all shadow-sm",
                      isActive ? "bg-ocean-deep border-treasure text-treasure shadow-premium-gilded" : "bg-card/20 border-border/40 text-paper/60 hover:border-treasure"
                    )}
                  >
                    {route.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Island Preview Side Drawer */}
        <AnimatePresence>
          {selectedIsland && (
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: "0%" }}
              exit={{ x: "100%" }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="absolute top-0 right-0 bottom-0 w-full sm:w-96 bg-ocean-deep/95 border-l-4 border-treasure p-8 z-30 pointer-events-auto overflow-y-auto shadow-premium-ocean flex flex-col justify-between text-ocean-foam"
            >
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-ocean-royal pb-4">
                  <span className="font-cinematic text-sm font-bold text-treasure uppercase tracking-wider">{selectedIsland.region}</span>
                  <button onClick={() => setSelectedIsland(null)} className="p-2 rounded-full bg-ocean-royal hover:bg-sunset-crimson transition-colors">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="relative h-48 w-full rounded-2xl overflow-hidden border-2 border-treasure bg-wood">
                  <img src={selectedIsland.coverImageUrl} alt={selectedIsland.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <h3 className="text-3xl font-cinematic font-bold text-treasure">{selectedIsland.name}</h3>
                  <p className="text-sm font-sans text-ocean-foam/70 italic mt-1">{selectedIsland.japaneseName}</p>
                </div>
                <div className="space-y-3 font-sans text-sm border-t border-ocean-royal pt-4">
                  <div><span className="font-cinematic font-bold text-treasure block text-xs uppercase mb-1">CLIMATE / ENVIRONMENT</span>{selectedIsland.climate}</div>
                  <div><span className="font-cinematic font-bold text-treasure block text-xs uppercase mb-1">LOG POSE LOCK TIME</span>{selectedIsland.logPoseLockTime}</div>
                  <div><span className="font-cinematic font-bold text-treasure block text-xs uppercase mb-1">GOVERNMENT / AFFILIATION</span>{selectedIsland.affiliation}</div>
                </div>
                <div>
                  <span className="font-cinematic font-bold text-treasure block text-xs uppercase mb-2">ISLAND HISTORY</span>
                  <p className="font-sans text-sm text-ocean-foam/80 leading-relaxed font-medium">{selectedIsland.history}</p>
                </div>
              </div>
              <div className="pt-8 border-t border-ocean-royal">
                <Button variant="gilded" size="default" onClick={() => (window.location.href = `/islands/${selectedIsland.slug}`)} className="w-full">
                  OPEN DEEP EXPLORER
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ============================================================================ */}
      {/* 2. ADVANCED SEARCH & FILTER BAR */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <TreasureMapContainer className="mb-16">
          <div className="space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <h3 className="text-3xl font-cinematic font-bold text-foreground tracking-wide">ISLAND EXPLORER INDEX</h3>
                <p className="text-base font-sans text-muted-foreground mt-1">Instantly filter across the Four Blues, Grand Line, and New World.</p>
              </div>
              <div className="flex items-center space-x-4">
                <Select
                  options={[
                    { label: "All Regions", value: "all" },
                    { label: "East Blue", value: "East Blue" },
                    { label: "Grand Line", value: "Grand Line" },
                    { label: "New World", value: "New World" },
                    { label: "Sky Island", value: "Sky Island" },
                    { label: "Undersea", value: "Undersea" },
                  ]}
                  value={seaFilter}
                  onChange={(e) => setSeaFilter(e.target.value)}
                  className="w-48 font-cinematic font-bold"
                />
              </div>
            </div>

            <div className="relative w-full">
              <SearchInput
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onClear={() => setQuery("")}
                placeholder="Search islands by name, climate, or ruling faction..."
                className="max-w-full text-xl h-16 bg-ocean-deep text-ocean-foam border-2 border-treasure shadow-premium-ocean"
                isSearching={isPending}
              />
            </div>
          </div>
        </TreasureMapContainer>

        {/* ============================================================================ */}
        {/* 3. WORLD CHRONOLOGICAL TIMELINE */}
        {/* ============================================================================ */}
        <div className="space-y-12">
          <div className="text-center my-12">
            <h2 className="text-4xl sm:text-5xl font-cinematic font-bold text-foreground tracking-wide">CHRONOLOGY OF THE SEAS</h2>
            <p className="font-cinematic text-lg text-treasure tracking-widest uppercase mt-2">Follow the Straw Hat Journey</p>
            <RopeBorder className="w-64 mx-auto my-4" />
          </div>

          <div className="max-w-4xl mx-auto relative border-l-4 border-treasure ml-4 sm:ml-8 space-y-12 py-4">
            {timelineEvents.map((ev, idx) => (
              <div key={idx} className="relative pl-8 sm:pl-12 group">
                <div className="absolute -left-[22px] top-1.5 w-10 h-10 rounded-full bg-ocean-deep border-4 border-treasure flex items-center justify-center shadow-premium-gilded group-hover:scale-110 transition-transform">
                  <Anchor className="w-4 h-4 text-treasure" />
                </div>
                <div className="bg-card border-2 border-border rounded-3xl p-8 shadow-paper-lift group-hover:border-treasure transition-colors flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
                  <div>
                    <span className="inline-block font-mono font-bold text-treasure bg-ocean-deep px-3 py-1 rounded-full text-xs mb-3">
                      {ev.year}
                    </span>
                    <h4 className="text-2xl font-cinematic font-bold text-foreground mb-2">{ev.title}</h4>
                    <p className="text-muted-foreground font-sans text-base leading-relaxed">{ev.desc}</p>
                  </div>
                  <Button variant="gilded" size="default" onClick={() => jumpToIsland(ev.islandSlug)} className="whitespace-nowrap flex-shrink-0">
                    FOCUS MAP ON ISLAND
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
