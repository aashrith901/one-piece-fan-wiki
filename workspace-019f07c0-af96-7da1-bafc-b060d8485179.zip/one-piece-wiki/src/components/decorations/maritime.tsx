"use client";

import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { cn, seededRandom } from "@/lib/utils";
import { Anchor, Compass } from "lucide-react";

// ============================================================================
// 1. ROPE BORDER SEPARATOR
// ============================================================================

export interface RopeBorderProps {
  className?: string;
}

export const RopeBorder: React.FC<RopeBorderProps> = ({ className }) => {
  return (
    <div className={cn("w-full h-6 relative overflow-hidden select-none my-6", className)}>
      <div className="absolute inset-0 flex items-center justify-center space-x-1 opacity-80">
        {Array.from({ length: 40 }).map((_, i) => (
          <div key={i} className="w-8 h-4 rounded-full border-2 border-treasure bg-wood-plank shadow-sm transform -rotate-12 flex-shrink-0" />
        ))}
      </div>
    </div>
  );
};

// ============================================================================
// 2. GOLDEN ANCHOR DECORATION
// ============================================================================

export interface AnchorDecorationProps {
  className?: string;
}

export const AnchorDecoration: React.FC<AnchorDecorationProps> = ({ className }) => {
  return (
    <div className={cn("flex items-center justify-center w-full my-8 select-none", className)}>
      <div className="h-[2px] flex-grow bg-gradient-to-r from-transparent via-treasure to-transparent opacity-50" />
      <div className="mx-4 p-3 rounded-full bg-ocean-deep border-2 border-treasure shadow-premium-gilded flex items-center justify-center animate-float">
        <Anchor className="w-6 h-6 text-treasure" />
      </div>
      <div className="h-[2px] flex-grow bg-gradient-to-r from-transparent via-treasure to-transparent opacity-50" />
    </div>
  );
};

// ============================================================================
// 3. WAVE SEPARATOR
// ============================================================================

export interface WaveSeparatorProps {
  className?: string;
}

export const WaveSeparator: React.FC<WaveSeparatorProps> = ({ className }) => {
  return (
    <div className={cn("w-full overflow-hidden select-none leading-none my-6 h-12 relative", className)}>
      <svg
        viewBox="0 0 1200 120"
        preserveAspectRatio="none"
        className="relative block w-full h-full text-ocean-deep fill-current transform rotate-180"
      >
        <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" />
      </svg>
    </div>
  );
};

// ============================================================================
// 4. DEEP OCEAN BACKGROUND CONTAINER
// ============================================================================

export interface OceanBackgroundProps {
  children: React.ReactNode;
  className?: string;
}

export const OceanBackground: React.FC<OceanBackgroundProps> = ({ children, className }) => {
  return (
    <div className={cn("relative w-full min-h-screen bg-gradient-to-b from-ocean via-ocean-deep to-ocean-royal overflow-hidden", className)}>
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-treasure/10 via-transparent to-transparent pointer-events-none" />
      <div className="relative z-10 w-full h-full">{children}</div>
    </div>
  );
};

// ============================================================================
// 5. MOVING CLOUD EFFECTS
// ============================================================================

export interface CloudEffectsProps {
  className?: string;
}

export const CloudEffects: React.FC<CloudEffectsProps> = ({ className }) => {
  return (
    <div className={cn("absolute inset-x-0 top-0 h-64 overflow-hidden pointer-events-none select-none z-0", className)}>
      <motion.div
        animate={{ x: ["-50%", "0%"] }}
        transition={{ repeat: Infinity, duration: 40, ease: "linear" }}
        className="absolute top-0 left-0 w-[200%] h-full flex items-center justify-around opacity-10"
      >
        <div className="w-96 h-32 bg-white rounded-full blur-3xl" />
        <div className="w-80 h-24 bg-white rounded-full blur-2xl" />
        <div className="w-96 h-32 bg-white rounded-full blur-3xl" />
        <div className="w-80 h-24 bg-white rounded-full blur-2xl" />
      </motion.div>
    </div>
  );
};

// ============================================================================
// 6. FLYING BIRD ANIMATION (NEWS COO)
// ============================================================================

export interface BirdAnimationsProps {
  className?: string;
}

export const BirdAnimations: React.FC<BirdAnimationsProps> = ({ className }) => {
  return (
    <div className={cn("absolute inset-x-0 top-12 h-32 overflow-hidden pointer-events-none select-none z-10", className)}>
      <motion.div
        animate={{ x: ["-20vw", "120vw"], y: [0, -20, 0] }}
        transition={{ repeat: Infinity, duration: 22, ease: "linear" }}
        className="absolute left-0 top-4 w-12 h-6 flex items-center justify-center text-ocean-foam opacity-75"
      >
        <svg viewBox="0 0 24 24" className="w-8 h-8 fill-current">
          <path d="M2,12 C6,8 10,12 12,12 C14,12 18,8 22,12 C18,14 14,12 12,12 C10,12 6,14 2,12 Z" />
        </svg>
      </motion.div>
      <motion.div
        animate={{ x: ["-10vw", "130vw"], y: [0, 15, 0] }}
        transition={{ repeat: Infinity, duration: 28, ease: "linear", delay: 5 }}
        className="absolute left-10 top-12 w-10 h-5 flex items-center justify-center text-ocean-foam opacity-60"
      >
        <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
          <path d="M2,12 C6,8 10,12 12,12 C14,12 18,8 22,12 C18,14 14,12 12,12 C10,12 6,14 2,12 Z" />
        </svg>
      </motion.div>
    </div>
  );
};

// ============================================================================
// 7. COIN PARTICLES (BELI TREASURE)
// ============================================================================

export interface CoinParticlesProps {
  count?: number;
  className?: string;
}

export const CoinParticles: React.FC<CoinParticlesProps> = ({ count = 15, className }) => {
  const [coins, setCoins] = useState<{ id: number; x: number; delay: number }[]>([]);

  useEffect(() => {
    setCoins(
      Array.from({ length: count }, (_, i) => ({
        id: i,
        x: seededRandom(`coin-${i}`) * 100,
        delay: seededRandom(`delay-${i}`) * 5,
      }))
    );
  }, [count]);

  return (
    <div className={cn("absolute inset-0 overflow-hidden pointer-events-none select-none z-20", className)}>
      {coins.map((coin) => (
        <motion.div
          key={coin.id}
          initial={{ y: "100%", opacity: 0, rotate: 0 }}
          animate={{ y: "-10%", opacity: [0, 1, 1, 0], rotate: 360 }}
          transition={{ repeat: Infinity, duration: 6, delay: coin.delay, ease: "easeInOut" }}
          style={{ left: `${coin.x}%` }}
          className="absolute bottom-0 w-6 h-6 rounded-full bg-treasure border border-treasure-light flex items-center justify-center shadow-premium-gilded"
        >
          <span className="text-[10px] font-mono font-bold text-ocean-deep">฿</span>
        </motion.div>
      ))}
    </div>
  );
};

// ============================================================================
// 8. FLOATING AMBIENT PARTICLES
// ============================================================================

export interface FloatingParticlesProps {
  count?: number;
  className?: string;
}

export const FloatingParticles: React.FC<FloatingParticlesProps> = ({ count = 25, className }) => {
  const [particles, setParticles] = useState<{ id: number; x: number; y: number; delay: number }[]>([]);

  useEffect(() => {
    setParticles(
      Array.from({ length: count }, (_, i) => ({
        id: i,
        x: seededRandom(`px-${i}`) * 100,
        y: seededRandom(`py-${i}`) * 100,
        delay: seededRandom(`pdelay-${i}`) * 4,
      }))
    );
  }, [count]);

  return (
    <div className={cn("absolute inset-0 overflow-hidden pointer-events-none select-none z-10", className)}>
      {particles.map((p) => (
        <motion.div
          key={p.id}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: [0, 0.6, 0], scale: [0.8, 1.2, 0.8], y: p.y - 15 }}
          transition={{ repeat: Infinity, duration: 5, delay: p.delay, ease: "easeInOut" }}
          style={{ left: `${p.x}%`, top: `${p.y}%` }}
          className="absolute w-1.5 h-1.5 rounded-full bg-treasure-light shadow-sm"
        />
      ))}
    </div>
  );
};

// ============================================================================
// 9. GLASS PANEL (TRANSLUCENT MODERN)
// ============================================================================

export interface GlassPanelProps {
  children: React.ReactNode;
  className?: string;
}

export const GlassPanel: React.FC<GlassPanelProps> = ({ children, className }) => {
  return (
    <div className={cn("relative w-full rounded-3xl border border-treasure/30 bg-ocean-deep/60 backdrop-blur-md p-8 shadow-premium-ocean z-10", className)}>
      {children}
    </div>
  );
};

// ============================================================================
// 10. WOODEN PANEL
// ============================================================================

export interface WoodenPanelProps {
  children: React.ReactNode;
  className?: string;
}

export const WoodenPanel: React.FC<WoodenPanelProps> = ({ children, className }) => {
  return (
    <div className={cn("relative w-full rounded-3xl border-4 border-treasure bg-wooden-plank p-8 shadow-premium-ocean z-10 overflow-hidden", className)}>
      {/* Brass Rivet Decorations */}
      <div className="absolute top-3 left-3 w-3 h-3 rounded-full bg-treasure border border-wood shadow-sm" />
      <div className="absolute top-3 right-3 w-3 h-3 rounded-full bg-treasure border border-wood shadow-sm" />
      <div className="absolute bottom-3 left-3 w-3 h-3 rounded-full bg-treasure border border-wood shadow-sm" />
      <div className="absolute bottom-3 right-3 w-3 h-3 rounded-full bg-treasure border border-wood shadow-sm" />
      <div className="relative z-10">{children}</div>
    </div>
  );
};

// ============================================================================
// 11. TREASURE MAP CONTAINER (AGED PARCHMENT)
// ============================================================================

export interface TreasureMapContainerProps {
  children: React.ReactNode;
  className?: string;
}

export const TreasureMapContainer: React.FC<TreasureMapContainerProps> = ({ children, className }) => {
  return (
    <div className={cn("relative w-full rounded-3xl border-4 border-border bg-parchment p-8 sm:p-12 shadow-paper-lift z-10 overflow-hidden", className)}>
      <Compass className="absolute -bottom-10 -right-10 w-64 h-64 text-border/20 pointer-events-none transform rotate-45" />
      <div className="relative z-10">{children}</div>
    </div>
  );
};
