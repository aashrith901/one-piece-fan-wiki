"use client";

import React, { useState, useEffect, useTransition } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, Input, Select } from "@/components/ui/buttons";
import { Tabs, Table, Dialog } from "@/components/ui/navigation-ui";
import { StatCard } from "@/components/ui/cards";
import { SkeletonLoader } from "@/components/ui/feedback";
import { RopeBorder, TreasureMapContainer, WoodenPanel, CoinParticles } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { Shield, Users, Database, FileText, Image as ImageIcon, Settings, ShieldAlert, BarChart2, CheckCircle2, RefreshCw, AlertTriangle, Key, Download, Upload, Pin } from "lucide-react";

// ============================================================================
// GOROSEI ADMIN CMS & ANALYTICS DASHBOARD CLIENT COMPONENT
// ============================================================================

export default function GoroseiAdminDashboard() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  // Admin Data Store States
  const [adminData, setAdminData] = useState<any>({
    roleSystem: [],
    usersList: [],
    auditLogs: [],
    mediaLibrary: [],
    backups: [],
    homepageConfig: {},
    bannerManagement: [],
    systemHealth: "100% Healthy",
  });

  // Analytics Store States
  const [analyticsData, setAnalyticsData] = useState<any>({
    overview: { totalUsers: 142850, activeUsers: 48920, onlineUsers: 1420, newRegistrationsToday: 890 },
    visits: { daily: [], weeklyTotal: 0, monthlyTotal: 0 },
    searchAnalytics: { totalQueriesToday: 0, averageLatencyMs: 0, topKeywords: [] },
    popularEntities: { characters: [], islands: [], devilFruits: [], discussions: [] },
    trackersStats: { readingTracker: { totalChaptersLogged: 0, completionAverage: 0 }, watchTracker: { totalEpisodesLogged: 0, completionAverage: 0 } },
    trafficSources: [],
    devices: [],
    browsers: [],
    engagementMetrics: {},
  });

  // Form States
  const [selectedUsername, setSelectedUsername] = useState("Admiral Koby");
  const [targetRole, setTargetRole] = useState("Moderator");
  const [newHeroTitle, setNewHeroTitle] = useState("THE ULTIMATE FAN ENCYCLOPEDIA OF THE GRAND LINE");
  const [newHeroSub, setNewHeroSub] = useState("Set sail across 1,100+ manga chapters, explore legendary pirate fleets, analyze awakened devil fruits, and craft custom high-fidelity bounty posters.");
  const [backupTitle, setBackupTitle] = useState("Manual Gorosei Snapshot");
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);

  useEffect(() => {
    startTransition(async () => {
      try {
        const resAdmin = await fetch("/api/admin");
        const dataAdmin = await resAdmin.json();
        if (dataAdmin.success) setAdminData(dataAdmin.data);

        const resAnal = await fetch("/api/analytics");
        const dataAnal = await resAnal.json();
        if (dataAnal.success) setAnalyticsData(dataAnal.data);
      } catch (err) {
        console.error("Admin fetch error:", err);
      }
    });
  }, []);

  const handleUpdateRole = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "updateUserRole", username: selectedUsername, newRole: targetRole }),
      });
      const data = await res.json();
      if (data.success) {
        setToastMessage(data.message);
        // Refresh local users list simulation
        setAdminData((prev: any) => ({
          ...prev,
          usersList: prev.usersList.map((u: any) => u.username === selectedUsername ? { ...u, role: targetRole } : u),
          auditLogs: [{ id: Date.now(), action: "User Role Updated", target: selectedUsername, previousRole: "Member", newRole: targetRole, executedBy: "Super Admin Gorosei", timestamp: new Date().toISOString() }, ...prev.auditLogs],
        }));
      } else {
        setToastMessage(`Error: ${data.error}`);
      }
    } catch (err) {
      setToastMessage("Network error during role update.");
    }
  };

  const handleCreateBackup = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "createBackup", title: backupTitle }),
      });
      const data = await res.json();
      if (data.success) {
        setToastMessage(data.message);
        setIsBackupModalOpen(false);
        setAdminData((prev: any) => ({
          ...prev,
          backups: [{ id: data.backupId, title: backupTitle, size: "14.5 GB", totalEntities: 495120, status: "Secure / Encrypted", createdAt: new Date().toISOString() }, ...prev.backups],
        }));
      } else {
        setToastMessage(`Error: ${data.error}`);
      }
    } catch (err) {
      setToastMessage("Network error during backup creation.");
    }
  };

  const handleUpdateHomepage = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "updateHomepage", config: { heroTitle: newHeroTitle, heroSubtitle: newHeroSub } }),
      });
      const data = await res.json();
      if (data.success) setToastMessage(data.message);
    } catch (err) {
      setToastMessage("Network error updating homepage cache.");
    }
  };

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* Toast Notification Popup */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 bg-ocean-royal text-ocean-foam border-2 border-treasure p-6 rounded-2xl shadow-premium-ocean flex items-center space-x-4 max-w-sm"
          >
            <CheckCircle2 className="w-6 h-6 text-treasure flex-shrink-0" />
            <span className="font-sans text-sm font-medium">{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="text-xs text-treasure hover:underline">Close</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Backup Creation Modal */}
      <Dialog isOpen={isBackupModalOpen} onClose={() => setIsBackupModalOpen(false)} title="INITIALIZE GOROSEI STORAGE BACKUP">
        <form onSubmit={handleCreateBackup} className="space-y-6">
          <p className="font-sans text-base text-foreground leading-relaxed">
            Encrypt and capture a complete snapshot of all PostgreSQL Drizzle tables, including user profiles, reading trackers, active polls, and Canva bounty layers.
          </p>
          <div>
            <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">BACKUP SNAPSHOT TITLE</span>
            <Input value={backupTitle} onChange={(e) => setBackupTitle(e.target.value)} placeholder="e.g., Post-Egghead Climax Backup" />
          </div>
          <div className="flex justify-end pt-4 border-t border-border">
            <Button variant="gilded" size="default" type="submit">ENCRYPT & SAVE TO CLOUD STORAGE</Button>
          </div>
        </form>
      </Dialog>

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[45vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-treasure/20 via-ocean-deep to-ocean-royal pointer-events-none" />
        <CoinParticles count={15} />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs items={[{ label: "Grand Line Wiki", href: "/" }, { label: "Gorosei Administration" }, { label: "Master CMS & Analytics" }]} />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <span className="inline-block bg-sunset-crimson text-white font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-widest uppercase border border-treasure shadow-glowing-bounty mb-3">
                MARY GEOISE CENTRAL REPOSITORY
              </span>
              <h1 className="text-5xl sm:text-6xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
                MASTER ADMIN CMS & ANALYTICS
              </h1>
              <p className="text-lg font-sans text-ocean-foam/80 italic mt-1">Manage user roles, inspect search analytics, configure homepage hero layouts, and review audit logs.</p>
            </div>
            <div>
              <Button variant="gilded" size="lg" onClick={() => setIsBackupModalOpen(true)} leftIcon={<Database className="w-5 h-5 text-ocean-deep" />}>
                GENERATE BACKUP SNAPSHOT
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MASTER ADMIN TABS */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <Tabs
          items={[
            {
              id: "analytics_overview",
              label: "ANALYTICS & METRICS",
              content: (
                <div className="space-y-16">
                  {/* Overview Metric Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                    <StatCard label="Total Registered Users" value={analyticsData.overview.totalUsers} icon={<Users className="w-6 h-6" />} progress={100} />
                    <StatCard label="Active Community Admirals" value={analyticsData.overview.activeUsers} icon={<Shield className="w-6 h-6 text-treasure" />} progress={92} />
                    <StatCard label="Online Right Now" value={analyticsData.overview.onlineUsers} icon={<RefreshCw className="w-6 h-6 text-emerald animate-spin" />} />
                    <StatCard label="New Fleet Registrations Today" value={analyticsData.overview.newRegistrationsToday} icon={<BarChart2 className="w-6 h-6 text-sunset" />} />
                  </div>

                  {/* Search Analytics Row */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 bg-parchment border-2 border-border rounded-3xl p-8 shadow-paper-lift space-y-6">
                      <h4 className="font-cinematic text-2xl font-bold text-foreground flex items-center border-b border-border pb-3">
                        <BarChart2 className="w-6 h-6 mr-3 text-treasure" /> SEARCH ENGINE METRICS
                      </h4>
                      <div className="grid grid-cols-2 gap-6 font-mono text-sm border-b border-border pb-6">
                        <div><span className="text-xs uppercase font-bold text-muted-foreground block mb-1">Total Queries Today</span><span className="text-3xl font-bold text-foreground">{analyticsData.searchAnalytics.totalQueriesToday?.toLocaleString()} hits</span></div>
                        <div><span className="text-xs uppercase font-bold text-muted-foreground block mb-1">Average Match Latency</span><span className="text-3xl font-bold text-emerald">{analyticsData.searchAnalytics.averageLatencyMs} ms</span></div>
                      </div>
                      <div>
                        <span className="font-cinematic text-sm font-bold text-foreground block uppercase mb-3">Top Keyword Navigations</span>
                        <div className="space-y-2">
                          {analyticsData.searchAnalytics.topKeywords?.map((kw: any, idx: number) => (
                            <div key={idx} className="flex items-center justify-between p-3 bg-card border border-border rounded-2xl font-mono text-xs">
                              <span className="font-bold text-foreground">#{idx + 1} {kw.keyword}</span>
                              <span className="bg-ocean-deep text-treasure px-3 py-1 rounded-full border border-treasure">{kw.hits.toLocaleString()} hits</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Engagement & Trackers Tile */}
                    <div className="bg-ocean-deep text-ocean-foam border-4 border-treasure rounded-3xl p-8 shadow-premium-ocean space-y-8 flex flex-col justify-between">
                      <div className="space-y-6">
                        <h4 className="font-cinematic text-xl font-bold text-treasure flex items-center border-b border-ocean-royal pb-2">
                          <Settings className="w-5 h-5 mr-2 text-treasure" /> ENGAGEMENT & TRACKERS
                        </h4>
                        <div className="space-y-3 font-mono text-xs text-ocean-foam/80 border-b border-ocean-royal pb-6">
                          <div className="flex justify-between"><span>Avg Session Duration:</span><span className="text-treasure font-bold">{analyticsData.engagementMetrics.averageSessionDuration}</span></div>
                          <div className="flex justify-between"><span>Bounce Rate:</span><span className="text-sunset font-bold">{analyticsData.engagementMetrics.bounceRate}</span></div>
                          <div className="flex justify-between"><span>Pages Per Session:</span><span className="text-emerald font-bold">{analyticsData.engagementMetrics.pagesPerSession}</span></div>
                        </div>
                        <div className="space-y-4 font-sans text-sm">
                          <div>
                            <span className="font-cinematic font-bold text-treasure block text-xs uppercase mb-1">MANGA TRACKER TOTAL LOGS</span>
                            <span className="font-mono text-lg font-bold text-ocean-foam block">{analyticsData.trackersStats.readingTracker?.totalChaptersLogged.toLocaleString()} chs ({analyticsData.trackersStats.readingTracker?.completionAverage}% avg)</span>
                          </div>
                          <div>
                            <span className="font-cinematic font-bold text-treasure block text-xs uppercase mb-1">ANIME TRACKER TOTAL LOGS</span>
                            <span className="font-mono text-lg font-bold text-ocean-foam block">{analyticsData.trackersStats.watchTracker?.totalEpisodesLogged.toLocaleString()} eps ({analyticsData.trackersStats.watchTracker?.completionAverage}% avg)</span>
                          </div>
                        </div>
                      </div>
                      <Button variant="gilded" size="sm" onClick={() => setToastMessage("Analytics reports compiled to CSV!")} className="w-full text-xs">
                        EXPORT ANALYTICS METRICS (CSV)
                      </Button>
                    </div>
                  </div>

                  {/* Popular Lore Entities Tables */}
                  <div className="space-y-8">
                    <SectionHeader title="MOST POPULAR LORE ENTITIES" subtitle="Highest Viewer Retention Across Categories" />
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      <div className="bg-card border-2 border-border rounded-3xl p-6 shadow-paper-lift space-y-4">
                        <h5 className="font-cinematic text-lg font-bold text-foreground border-b border-border pb-2">Popular Characters</h5>
                        {analyticsData.popularEntities.characters?.map((c: any, i: number) => (
                          <div key={i} className="flex items-center justify-between p-2 border-b border-border/50 font-mono text-xs">
                            <span className="font-sans font-bold text-foreground">{c.name}</span><span className="text-treasure-dark font-bold">{c.views.toLocaleString()} views</span>
                          </div>
                        ))}
                      </div>
                      <div className="bg-card border-2 border-border rounded-3xl p-6 shadow-paper-lift space-y-4">
                        <h5 className="font-cinematic text-lg font-bold text-foreground border-b border-border pb-2">Popular Islands</h5>
                        {analyticsData.popularEntities.islands?.map((c: any, i: number) => (
                          <div key={i} className="flex items-center justify-between p-2 border-b border-border/50 font-mono text-xs">
                            <span className="font-sans font-bold text-foreground">{c.name}</span><span className="text-treasure-dark font-bold">{c.views.toLocaleString()} views</span>
                          </div>
                        ))}
                      </div>
                      <div className="bg-card border-2 border-border rounded-3xl p-6 shadow-paper-lift space-y-4">
                        <h5 className="font-cinematic text-lg font-bold text-foreground border-b border-border pb-2">Popular Devil Fruits</h5>
                        {analyticsData.popularEntities.devilFruits?.map((c: any, i: number) => (
                          <div key={i} className="flex items-center justify-between p-2 border-b border-border/50 font-mono text-xs">
                            <span className="font-sans font-bold text-foreground">{c.name}</span><span className="text-treasure-dark font-bold">{c.views.toLocaleString()} views</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Traffic, Devices & Browsers Tables */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-6 border-t border-border">
                    <div className="bg-card border-2 border-border rounded-3xl p-6 shadow-paper-lift space-y-4">
                      <h5 className="font-cinematic text-lg font-bold text-foreground border-b border-border pb-2">Traffic Sources</h5>
                      {analyticsData.trafficSources?.map((ts: any, i: number) => (<div key={i} className="flex justify-between font-mono text-xs"><span>{ts.source}</span><span className="font-bold">{ts.percentage}%</span></div>))}
                    </div>
                    <div className="bg-card border-2 border-border rounded-3xl p-6 shadow-paper-lift space-y-4">
                      <h5 className="font-cinematic text-lg font-bold text-foreground border-b border-border pb-2">Device Analytics</h5>
                      {analyticsData.devices?.map((ts: any, i: number) => (<div key={i} className="flex justify-between font-mono text-xs"><span>{ts.device}</span><span className="font-bold">{ts.percentage}%</span></div>))}
                    </div>
                    <div className="bg-card border-2 border-border rounded-3xl p-6 shadow-paper-lift space-y-4">
                      <h5 className="font-cinematic text-lg font-bold text-foreground border-b border-border pb-2">Browser Analytics</h5>
                      {analyticsData.browsers?.map((ts: any, i: number) => (<div key={i} className="flex justify-between font-mono text-xs"><span>{ts.browser}</span><span className="font-bold">{ts.percentage}%</span></div>))}
                    </div>
                  </div>
                </div>
              ),
            },
            {
              id: "users_roles",
              label: "USER & ROLE MANAGEMENT",
              content: (
                <form onSubmit={handleUpdateRole} className="space-y-12">
                  <TreasureMapContainer className="space-y-8">
                    <h3 className="text-3xl font-cinematic font-bold text-foreground flex items-center border-b border-border pb-4">
                      <Users className="w-8 h-8 mr-3 text-treasure" /> ROLE & PERMISSION HIERARCHY
                    </h3>
                    <p className="font-sans text-base text-foreground leading-relaxed">
                      Assign permission-based access control roles to community Admirals. Available tiers: Super Admin, Admin, Moderator, Editor, Contributor, Verified User, Member, Guest.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div>
                        <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">SELECT PIRATE ALIAS</span>
                        <Select options={adminData.usersList?.map((u: any) => ({ label: `${u.username} (${u.role})`, value: u.username }))} value={selectedUsername} onChange={(e) => setSelectedUsername(e.target.value)} className="font-cinematic font-bold text-lg h-12" />
                      </div>
                      <div>
                        <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">ASSIGN NEW PERMISSION ROLE</span>
                        <Select options={adminData.roleSystem?.map((r: string) => ({ label: r, value: r }))} value={targetRole} onChange={(e) => setTargetRole(e.target.value)} className="font-cinematic font-bold text-lg h-12" />
                      </div>
                    </div>
                    <div className="flex justify-end border-t border-border pt-6">
                      <Button variant="gilded" size="lg" type="submit">BROADCAST ROLE UPDATE</Button>
                    </div>
                  </TreasureMapContainer>

                  {/* Users Table */}
                  <div className="space-y-6">
                    <SectionHeader title="REGISTERED FLEET OFFICERS" subtitle="Authority Matrix & Reputation Ledger" />
                    <Table
                      columns={[
                        { header: "Admiral Alias", accessor: "username", className: "font-cinematic text-xl font-bold text-foreground" },
                        { header: "Email Address", accessor: "email", className: "font-sans text-base text-muted-foreground" },
                        { header: "Assigned Role", accessor: (row) => <span className="font-cinematic text-sm font-bold text-treasure bg-ocean-deep px-4 py-1.5 rounded-full border border-treasure shadow-sm uppercase">{row.role}</span>, className: "w-40" },
                        { header: "Account Status", accessor: "status", className: "font-sans text-base text-emerald-dark font-bold w-32" },
                        { header: "Reputation Score", accessor: (row) => <span className="font-mono text-base font-bold text-treasure-dark">{row.reputation.toLocaleString()} Rep</span>, className: "text-right w-40" },
                      ]}
                      data={adminData.usersList}
                    />
                  </div>
                </form>
              ),
            },
            {
              id: "content_cms",
              label: "LORE CMS MANAGEMENT",
              content: (
                <TreasureMapContainer className="space-y-8">
                  <h3 className="text-3xl font-cinematic font-bold text-foreground flex items-center border-b border-border pb-4">
                    <FileText className="w-8 h-8 mr-3 text-treasure" /> UNIVERSAL LORE CMS ENGINE
                  </h3>
                  <p className="font-sans text-base text-foreground leading-relaxed">
                    Access master editing manifests for Characters, Episodes, Manga Chapters, News Dispatches, Polls, and Discussion Boards.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-4">
                    {[
                      { title: "Character Management", desc: "Add or update stat radars and bounty timelines.", link: "/characters" },
                      { title: "Episode Management", desc: "Sync Toei simulcast metadata and ratings.", link: "/episodes" },
                      { title: "Manga Management", desc: "Upload chapter summaries and cover story logs.", link: "/chapters" },
                      { title: "News Management", desc: "Draft breaking dispatches and editorial reviews.", link: "/news" },
                      { title: "Poll Management", desc: "Establish or close universal voting ballots.", link: "/community/polls" },
                      { title: "Discussion Management", desc: "Lock offending threads or pin fan theories.", link: "/community/boards" },
                    ].map((tab, idx) => (
                      <div key={idx} onClick={() => (window.location.href = tab.link)} className="bg-card border-2 border-border rounded-2xl p-6 cursor-pointer hover:border-treasure shadow-sm group transition-all flex flex-col justify-between">
                        <div>
                          <h5 className="font-cinematic text-xl font-bold text-foreground group-hover:text-treasure-dark transition-colors mb-2">{tab.title}</h5>
                          <p className="font-sans text-xs text-muted-foreground leading-relaxed">{tab.desc}</p>
                        </div>
                        <span className="font-cinematic text-xs font-bold text-treasure mt-6 block uppercase border-t border-border pt-4">OPEN MASTER ARCHIVE →</span>
                      </div>
                    ))}
                  </div>
                </TreasureMapContainer>
              ),
            },
            {
              id: "homepage_editor",
              label: "HOMEPAGE & BANNERS",
              content: (
                <form onSubmit={handleUpdateHomepage} className="space-y-12">
                  <TreasureMapContainer className="space-y-8">
                    <h3 className="text-3xl font-cinematic font-bold text-foreground flex items-center border-b border-border pb-4">
                      <Pin className="w-8 h-8 mr-3 text-treasure" /> HOMEPAGE HERO & BANNER EDITOR
                    </h3>
                    <div>
                      <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">HOMEPAGE HERO TITLE</span>
                      <Input value={newHeroTitle} onChange={(e) => setNewHeroTitle(e.target.value)} className="h-12 font-cinematic font-bold text-base" />
                    </div>
                    <div>
                      <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">HOMEPAGE HERO SUBTITLE</span>
                      <textarea value={newHeroSub} onChange={(e) => setNewHeroSub(e.target.value)} rows={3} className="w-full rounded-xl bg-input border border-border p-4 text-foreground focus:outline-none focus:ring-2 focus:ring-treasure font-sans text-sm shadow-sm" />
                    </div>
                    <div className="flex items-center justify-between p-6 bg-card border border-border rounded-2xl">
                      <div><h5 className="font-cinematic text-xl font-bold text-foreground">MAINTENANCE MODE TOGGLE</h5><p className="font-sans text-xs text-muted-foreground mt-1">Redirect all public navigations to the custom Maintenance Mode page.</p></div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" onChange={(e) => setToastMessage(e.target.checked ? "Maintenance mode active!" : "Maintenance mode disabled.")} className="sr-only peer" />
                        <div className="w-11 h-6 bg-muted peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-paper after:border-border after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-sunset-crimson"></div>
                      </label>
                    </div>
                    <div className="flex justify-end border-t border-border pt-6">
                      <Button variant="gilded" size="lg" type="submit">PUBLISH HOMEPAGE CONFIGURATION</Button>
                    </div>
                  </TreasureMapContainer>

                  {/* Banner Management Table */}
                  <div className="space-y-6">
                    <SectionHeader title="ACTIVE GLOBAL BANNERS" subtitle="Community & News Promos" />
                    <Table
                      columns={[
                        { header: "Banner Title", accessor: "title", className: "font-cinematic text-xl font-bold text-foreground" },
                        { header: "Target Navigation URL", accessor: "targetUrl", className: "font-sans text-base text-muted-foreground" },
                        { header: "Display Status", accessor: (row) => <span className="font-cinematic text-xs font-bold text-emerald-dark bg-card px-3 py-1 rounded-full border border-emerald uppercase">Active</span>, className: "w-32" },
                        { header: "Action", accessor: (row) => <Button variant="crimson" size="sm" onClick={() => setToastMessage("Removed banner from homepage loop.")}>REVOKE BANNER</Button>, className: "text-right w-40" },
                      ]}
                      data={adminData.bannerManagement}
                    />
                  </div>
                </form>
              ),
            },
            {
              id: "media_backups",
              label: "MEDIA & BACKUPS",
              content: (
                <div className="space-y-16">
                  {/* Backups Table */}
                  <div className="space-y-6">
                    <div className="flex items-center justify-between border-b-2 border-border pb-3">
                      <h4 className="font-cinematic text-2xl font-bold text-foreground flex items-center">
                        <Database className="w-6 h-6 mr-3 text-treasure" /> AUTOMATED & MANUAL BACKUP SNAPSHOTS
                      </h4>
                      <Button variant="gilded" size="sm" onClick={() => setIsBackupModalOpen(true)}>CREATE SNAPSHOT</Button>
                    </div>
                    <Table
                      columns={[
                        { header: "Backup Title", accessor: "title", className: "font-cinematic text-xl font-bold text-foreground" },
                        { header: "Snapshot Size", accessor: (row) => <span className="font-mono text-base font-bold text-treasure-dark">{row.size}</span>, className: "w-32" },
                        { header: "Total Entities Captured", accessor: (row) => <span className="font-mono text-sm text-muted-foreground">{row.totalEntities.toLocaleString()} items</span>, className: "w-44" },
                        { header: "Encryption Status", accessor: "status", className: "font-sans text-sm text-emerald-dark font-bold w-40" },
                        { header: "Action", accessor: (row) => <Button variant="royal" size="sm" onClick={() => setToastMessage("Restoring database backup... Snapshot verified!")}>RESTORE</Button>, className: "text-right w-32" },
                      ]}
                      data={adminData.backups}
                    />
                  </div>

                  {/* Media Library Table */}
                  <div className="space-y-6">
                    <div className="flex items-center justify-between border-b-2 border-border pb-3">
                      <h4 className="font-cinematic text-2xl font-bold text-foreground flex items-center">
                        <ImageIcon className="w-6 h-6 mr-3 text-treasure" /> GOROSEI MEDIA LIBRARY & FILE MANAGER
                      </h4>
                      <Button variant="royal" size="sm" onClick={() => setToastMessage("Asset upload simulation active!")}>UPLOAD ASSET</Button>
                    </div>
                    <Table
                      columns={[
                        { header: "Thumbnail", accessor: (row) => <img src={row.url} alt={row.title} className="w-16 h-12 rounded-lg object-cover border border-treasure shadow-sm" />, className: "w-24" },
                        { header: "Asset Title", accessor: "title", className: "font-cinematic text-lg font-bold text-foreground" },
                        { header: "Dimensions", accessor: "dimensions", className: "font-mono text-sm text-muted-foreground w-32" },
                        { header: "Asset Size", accessor: (row) => <span className="font-mono text-sm text-muted-foreground">{row.size} ({row.format})</span>, className: "w-32" },
                        { header: "Action", accessor: (row) => <Button variant="crimson" size="sm" onClick={() => setToastMessage("Asset permanently obliterated from media vault.")}>DELETE</Button>, className: "text-right w-32" },
                      ]}
                      data={adminData.mediaLibrary}
                    />
                  </div>
                </div>
              ),
            },
            {
              id: "audit_logs",
              label: "SYSTEM AUDIT LOGS",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="SECURITY AUDIT & ACTIVITY LOGS" subtitle="Immutable System Modification Records" />
                  <Table
                    columns={[
                      { header: "Admin Action", accessor: (row) => <span className="font-cinematic text-base font-bold text-foreground">{row.action}</span>, className: "w-48" },
                      { header: "Target Entity", accessor: "target", className: "font-sans text-base text-muted-foreground" },
                      { header: "Modification Parameters", accessor: (row) => <span className="font-mono text-xs text-muted-foreground">{row.previousRole} → {row.newRole}</span>, className: "w-44" },
                      { header: "Executed By", accessor: (row) => <span className="font-cinematic text-xs font-bold text-treasure bg-ocean-deep px-3 py-1 rounded-full border border-treasure uppercase">{row.executedBy}</span>, className: "w-48" },
                      { header: "Time Stamp", accessor: (row) => <span className="font-mono text-xs text-muted-foreground">{new Date(row.timestamp).toLocaleString()}</span>, className: "text-right w-40" },
                    ]}
                    data={adminData.auditLogs}
                  />
                </div>
              ),
            },
          ]}
        />
      </div>

      <Footer />
    </div>
  );
}
