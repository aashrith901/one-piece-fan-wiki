"use client";

import React, { useRef, useState, useMemo } from "react";
import { Canvas, useFrame, ThreeEvent } from "@react-three/fiber";
import { OrbitControls, Sky, PerspectiveCamera, Text } from "@react-three/drei";
import * as THREE from "three";

// ============================================================================
// 1. PROCEDURAL ANIMATED NAVIGATION TABLE SEA
// ============================================================================

interface SeaPlaneProps {
  isNight: boolean;
}

const SeaPlane: React.FC<SeaPlaneProps> = ({ isNight }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const geometry = useMemo(() => new THREE.PlaneGeometry(300, 300, 64, 64), []);

  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    const elapsedTime = clock.getElapsedTime();
    meshRef.current.position.y = Math.sin(elapsedTime * 1.5) * 0.3;
  });

  return (
    <mesh ref={meshRef} geometry={geometry} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
      <meshStandardMaterial
        color={isNight ? "#051329" : "#0b203a"}
        roughness={0.2}
        metalness={0.8}
        emissive={isNight ? "#020914" : "#051329"}
        emissiveIntensity={0.3}
      />
    </mesh>
  );
};

// ============================================================================
// 2. PROCEDURAL 3D ISLAND MARKERS WITH HOVER & CLICK RAYCASTING
// ============================================================================

interface IslandMarkerProps {
  island: any;
  isSelected: boolean;
  onSelect: (island: any) => void;
  onHover: (island: any | null) => void;
}

const IslandMarker: React.FC<IslandMarkerProps> = ({ island, isSelected, onSelect, onHover }) => {
  const groupRef = useRef<THREE.Group>(null);
  const [hovered, setHovered] = useState(false);

  useFrame(({ clock }) => {
    if (!groupRef.current) return;
    const t = clock.getElapsedTime();
    if (isSelected || hovered) {
      groupRef.current.position.y = island.mapCoordY + Math.sin(t * 4) * 0.5;
      groupRef.current.rotation.y += 0.02;
    } else {
      groupRef.current.position.y = island.mapCoordY;
    }
  });

  const colorConfig: Record<string, string> = {
    "East Blue": "#ff6b35",
    "Grand Line": "#d4af37",
    "New World": "#d90429",
    "Sky Island": "#e6f4f8",
    "Undersea": "#06d6a0",
  };

  const baseColor = colorConfig[island.region] || "#d4af37";

  return (
    <group
      ref={groupRef}
      position={[island.mapCoordX, island.mapCoordY, island.mapCoordZ]}
      onClick={(e: ThreeEvent<MouseEvent>) => {
        e.stopPropagation();
        onSelect(island);
      }}
      onPointerOver={(e: ThreeEvent<MouseEvent>) => {
        e.stopPropagation();
        setHovered(true);
        onHover(island);
      }}
      onPointerOut={(e: ThreeEvent<MouseEvent>) => {
        e.stopPropagation();
        setHovered(false);
        onHover(null);
      }}
    >
      {/* Mountain Base */}
      <mesh castShadow receiveShadow position={[0, 1.5, 0]}>
        <coneGeometry args={[2, 3, 16]} />
        <meshStandardMaterial color={hovered || isSelected ? "#fff3a8" : baseColor} roughness={0.4} metalness={0.3} />
      </mesh>
      {/* Outer Glow Ring */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.2, 0]}>
        <ringGeometry args={[2.2, 2.8, 32]} />
        <meshBasicMaterial color={hovered || isSelected ? "#ff6b35" : "#d4af37"} side={THREE.DoubleSide} transparent opacity={hovered || isSelected ? 0.8 : 0.4} />
      </mesh>
      {/* 3D Title Floating Above Island */}
      <Text position={[0, 4, 0]} fontSize={1.5} color={hovered || isSelected ? "#d4af37" : "#e6f4f8"} anchorX="center" anchorY="middle">
        {island.name}
      </Text>
    </group>
  );
};

// ============================================================================
// 3. GLOWING ANIMATED SEA ROUTES
// ============================================================================

interface SeaRouteLineProps {
  points: { x: number; y: number; z: number }[];
  color: string;
}

const SeaRouteLine: React.FC<SeaRouteLineProps> = ({ points, color }) => {
  const lineRef = useRef<THREE.Line>(null);
  const v3Points = useMemo(() => points.map((p) => new THREE.Vector3(p.x, p.y + 0.5, p.z)), [points]);
  const lineGeom = useMemo(() => new THREE.BufferGeometry().setFromPoints(v3Points), [v3Points]);

  return (
    <line ref={lineRef} geometry={lineGeom}>
      <lineBasicMaterial color={color} linewidth={3} transparent opacity={0.8} />
    </line>
  );
};

// ============================================================================
// 4. WEATHER & DAY/NIGHT EFFECTS
// ============================================================================

interface AtmosphereProps {
  isNight: boolean;
  weather: "clear" | "clouds" | "storm";
}

const Atmosphere: React.FC<AtmosphereProps> = ({ isNight, weather }) => {
  const cloudsRef = useRef<THREE.Group>(null);
  const rainRef = useRef<THREE.Points>(null);

  const rainGeom = useMemo(() => {
    const geom = new THREE.BufferGeometry();
    const pos = [];
    for (let i = 0; i < 500; i++) {
      pos.push((Math.random() - 0.5) * 200, Math.random() * 50, (Math.random() - 0.5) * 200);
    }
    geom.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    return geom;
  }, []);

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime();
    if (cloudsRef.current) cloudsRef.current.rotation.y = t * 0.01;
    if (rainRef.current && weather === "storm") {
      const positions = rainRef.current.geometry.attributes.position.array as Float32Array;
      for (let i = 1; i < positions.length; i += 3) {
        positions[i] -= 0.8;
        if (positions[i] < 0) positions[i] = 50;
      }
      rainRef.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  return (
    <>
      {/* Cloud Layers */}
      {weather !== "clear" && (
        <group ref={cloudsRef} position={[0, 20, 0]}>
          {Array.from({ length: 15 }).map((_, i) => (
            <mesh key={i} position={[(Math.random() - 0.5) * 150, (Math.random() - 0.5) * 5, (Math.random() - 0.5) * 150]} scale={[15, 6, 10]}>
              <sphereGeometry args={[1, 16, 16]} />
              <meshStandardMaterial color={weather === "storm" ? "#2b5c8f" : "#e6f4f8"} transparent opacity={weather === "storm" ? 0.8 : 0.4} />
            </mesh>
          ))}
        </group>
      )}

      {/* Storm Rain Particles */}
      {weather === "storm" && (
        <points ref={rainRef} geometry={rainGeom}>
          <pointsMaterial color="#e6f4f8" size={0.5} transparent opacity={0.6} />
        </points>
      )}
    </>
  );
};

// ============================================================================
// 5. MAIN WORLD MAP CANVAS EXPORT
// ============================================================================

export interface WorldMapCanvasProps {
  islands: any[];
  selectedIsland: any | null;
  onSelectIsland: (island: any) => void;
  onHoverIsland: (island: any | null) => void;
  activeRoutes: string[];
  seaRoutesData: Record<string, any>;
  isNight: boolean;
  weather: "clear" | "clouds" | "storm";
}

export default function WorldMapCanvas({
  islands,
  selectedIsland,
  onSelectIsland,
  onHoverIsland,
  activeRoutes,
  seaRoutesData,
  isNight,
  weather,
}: WorldMapCanvasProps) {
  const routeColors: Record<string, string> = {
    strawHat: "#d4af37", // Treasure Gold
    rogerPirates: "#ff6b35", // Sunset Orange
    marines: "#e6f4f8", // White Foam
    revolutionaries: "#d90429", // Crimson Red
    yonkoTerritories: "#06d6a0", // Emerald Green
  };

  return (
    <div className="absolute inset-0 w-full h-full pointer-events-none select-none z-0 overflow-hidden">
      <Canvas shadows className="w-full h-full pointer-events-auto">
        <PerspectiveCamera makeDefault position={[0, 45, 65]} fov={40} />
        <OrbitControls
          enableZoom={true}
          enablePan={true}
          maxPolarAngle={Math.PI / 2 - 0.05}
          minPolarAngle={0.1}
          maxDistance={120}
          minDistance={15}
        />

        {/* Dynamic Lighting */}
        <ambientLight intensity={isNight ? 0.2 : 0.7} color={isNight ? "#2b5c8f" : "#e5d3b3"} />
        <directionalLight position={[50, 60, 40]} intensity={isNight ? 0.5 : 2.5} color={isNight ? "#8ea4c8" : "#d4af37"} castShadow />
        {weather === "storm" && <pointLight position={[0, 30, 0]} intensity={2} color="#fff3a8" />}

        {/* Dynamic Sky environment */}
        <Sky distance={450000} sunPosition={isNight ? [10, -10, 10] : [40, 25, 30]} inclination={isNight ? 0 : 0.2} azimuth={0.25} />

        {/* 3D Elements */}
        <SeaPlane isNight={isNight} />
        <Atmosphere isNight={isNight} weather={weather} />

        {/* Islands */}
        {islands.map((island) => (
          <IslandMarker
            key={island.id}
            island={island}
            isSelected={selectedIsland?.id === island.id}
            onSelect={onSelectIsland}
            onHover={onHoverIsland}
          />
        ))}

        {/* Sea Routes */}
        {activeRoutes.map((routeKey) => {
          const routePoints = seaRoutesData[routeKey];
          if (!routePoints) return null;
          return <SeaRouteLine key={routeKey} points={routePoints} color={routeColors[routeKey] || "#d4af37"} />;
        })}
      </Canvas>
    </div>
  );
}
