"use client";

import React, { useRef, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Sky, Float, PerspectiveCamera } from "@react-three/drei";
import * as THREE from "three";

// ============================================================================
// 1. PROCEDURAL ANIMATED OCEAN MESH
// ============================================================================

const OceanWater: React.FC = () => {
  const meshRef = useRef<THREE.Mesh>(null);

  // Generate a custom grid geometry that we can deform or simulate wave motion upon
  const geometry = useMemo(() => new THREE.PlaneGeometry(300, 300, 64, 64), []);

  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    const elapsedTime = clock.getElapsedTime();
    // Slowly shift texture or bump positioning if using standard materials
    meshRef.current.position.y = Math.sin(elapsedTime * 1.5) * 0.5 - 2;
  });

  return (
    <mesh ref={meshRef} geometry={geometry} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
      <meshStandardMaterial
        color="#0b203a"
        roughness={0.1}
        metalness={0.8}
        wireframe={false}
        emissive="#051329"
        emissiveIntensity={0.2}
      />
    </mesh>
  );
};

// ============================================================================
// 2. PROCEDURAL THOUSAND SUNNY / GOING MERRY SHIP MESH
// ============================================================================

const SailingShip: React.FC = () => {
  const shipGroup = useRef<THREE.Group>(null);
  const flagRef = useRef<THREE.Mesh>(null);

  useFrame(({ clock }) => {
    if (!shipGroup.current) return;
    const t = clock.getElapsedTime();

    // Gentle forward sailing oscillation and rocking on the ocean swells
    shipGroup.current.position.y = Math.sin(t * 2) * 0.4;
    shipGroup.current.position.z = Math.sin(t * 0.5) * 3;
    shipGroup.current.rotation.z = Math.sin(t * 1.5) * 0.05;
    shipGroup.current.rotation.x = Math.cos(t * 1.5) * 0.05;

    // Flag waving simulation
    if (flagRef.current) {
      flagRef.current.rotation.y = Math.sin(t * 8) * 0.2;
    }
  });

  return (
    <group ref={shipGroup} position={[0, 0, 0]} scale={[1.2, 1.2, 1.2]}>
      {/* Ship Hull */}
      <mesh position={[0, 0.5, 0]} castShadow receiveShadow>
        <boxGeometry args={[4.5, 2.5, 12]} />
        <meshStandardMaterial color="#5c3821" roughness={0.6} metalness={0.1} />
      </mesh>

      {/* Ship Bow / Figurehead (Golden Lion / Animal Head) */}
      <mesh position={[0, 1.2, 6.2]} rotation={[0, 0, 0]} castShadow>
        <sphereGeometry args={[1.2, 32, 32]} />
        <meshStandardMaterial color="#d4af37" roughness={0.3} metalness={0.8} />
      </mesh>
      {/* Figurehead Mane */}
      <mesh position={[0, 1.2, 5.8]} rotation={[0, 0, 0]} castShadow>
        <torusGeometry args={[1.5, 0.4, 16, 32]} />
        <meshStandardMaterial color="#ff6b35" roughness={0.4} metalness={0.2} />
      </mesh>

      {/* Main Mast */}
      <mesh position={[0, 5, 1]} castShadow>
        <cylinderGeometry args={[0.25, 0.35, 9, 16]} />
        <meshStandardMaterial color="#3d2314" roughness={0.5} />
      </mesh>

      {/* Main Sail (White Curved Sheet) */}
      <mesh position={[0, 5.5, 1.4]} rotation={[0, Math.PI, 0]} castShadow>
        <planeGeometry args={[7, 5, 8, 8]} />
        <meshStandardMaterial color="#e6f4f8" roughness={0.4} side={THREE.DoubleSide} />
      </mesh>

      {/* Crow's Nest */}
      <mesh position={[0, 8.5, 1]} castShadow>
        <cylinderGeometry args={[0.8, 0.6, 1, 16]} />
        <meshStandardMaterial color="#3d2314" roughness={0.6} />
      </mesh>

      {/* Pirate Jolly Roger Flag */}
      <group position={[0, 9.5, 0.8]}>
        <mesh ref={flagRef} position={[0, 0, -1]}>
          <planeGeometry args={[2.5, 1.5]} />
          <meshStandardMaterial color="#051329" roughness={0.5} side={THREE.DoubleSide} />
        </mesh>
      </group>

      {/* Fore Mast */}
      <mesh position={[0, 4, 4.5]} castShadow>
        <cylinderGeometry args={[0.2, 0.28, 7, 16]} />
        <meshStandardMaterial color="#3d2314" roughness={0.5} />
      </mesh>
      {/* Fore Sail */}
      <mesh position={[0, 4.2, 4.8]} rotation={[0, Math.PI, 0]} castShadow>
        <planeGeometry args={[5, 4, 8, 8]} />
        <meshStandardMaterial color="#e6f4f8" roughness={0.4} side={THREE.DoubleSide} />
      </mesh>

      {/* Rear Cabin / Deckhouse */}
      <mesh position={[0, 2.2, -3.5]} castShadow receiveShadow>
        <boxGeometry args={[3.8, 2, 4]} />
        <meshStandardMaterial color="#4a2e19" roughness={0.6} />
      </mesh>
      {/* Rear Mast / Mizzen Sail */}
      <mesh position={[0, 4.5, -3.5]} castShadow>
        <cylinderGeometry args={[0.18, 0.25, 6, 16]} />
        <meshStandardMaterial color="#3d2314" roughness={0.5} />
      </mesh>
      <mesh position={[0, 4.8, -3.2]} rotation={[0, Math.PI, 0]} castShadow>
        <planeGeometry args={[4, 3.5, 8, 8]} />
        <meshStandardMaterial color="#e6f4f8" roughness={0.4} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
};

// ============================================================================
// 3. PROCEDURAL CLOUDS & FLYING BIRDS
// ============================================================================

const Atmosphere: React.FC = () => {
  const cloudsRef = useRef<THREE.Group>(null);
  const birdsRef = useRef<THREE.Group>(null);

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime();
    if (cloudsRef.current) {
      cloudsRef.current.rotation.y = t * 0.02;
    }
    if (birdsRef.current) {
      birdsRef.current.position.x = Math.sin(t * 0.5) * 15;
      birdsRef.current.position.y = Math.sin(t * 2) * 1 + 18;
      birdsRef.current.position.z = Math.cos(t * 0.5) * 15;
    }
  });

  return (
    <>
      {/* Cloud Deck */}
      <group ref={cloudsRef} position={[0, 25, 0]}>
        {Array.from({ length: 12 }).map((_, i) => {
          const angle = (i / 12) * Math.PI * 2;
          const radius = 40 + Math.random() * 20;
          const x = Math.cos(angle) * radius;
          const z = Math.sin(angle) * radius;
          const y = (Math.random() - 0.5) * 10;
          return (
            <mesh key={i} position={[x, y, z]} scale={[12, 6, 8]}>
              <sphereGeometry args={[1, 16, 16]} />
              <meshStandardMaterial color="#e6f4f8" transparent opacity={0.6} roughness={1} />
            </mesh>
          );
        })}
      </group>

      {/* Flock of Birds (News Coo) */}
      <group ref={birdsRef} position={[0, 18, 0]}>
        {Array.from({ length: 5 }).map((_, i) => (
          <mesh key={i} position={[i * 1.5 - 3, (i % 2) * 0.5, i * 0.8]} scale={[0.4, 0.1, 0.4]}>
            <coneGeometry args={[1, 2, 4]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
        ))}
      </group>
    </>
  );
};

// ============================================================================
// 4. MAIN THREE.JS CANVAS HERO WRAPPER
// ============================================================================

export default function OceanHero() {
  return (
    <div className="absolute inset-0 w-full h-full pointer-events-none select-none z-0 overflow-hidden">
      <Canvas shadows className="w-full h-full pointer-events-auto">
        <PerspectiveCamera makeDefault position={[18, 12, 28]} fov={45} />
        <OrbitControls
          enableZoom={false}
          enablePan={false}
          maxPolarAngle={Math.PI / 2 - 0.05}
          minPolarAngle={Math.PI / 4}
          autoRotate
          autoRotateSpeed={0.5}
        />

        {/* Cinematic Dynamic Lighting */}
        <ambientLight intensity={0.6} color="#e5d3b3" />
        <directionalLight
          position={[40, 50, 30]}
          intensity={2.5}
          color="#d4af37"
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
          shadow-camera-far={100}
          shadow-camera-left={-30}
          shadow-camera-right={30}
          shadow-camera-top={30}
          shadow-camera-bottom={-30}
        />
        <pointLight position={[-20, 20, -20]} intensity={1} color="#ff6b35" />

        {/* Dynamic Sky environment */}
        <Sky distance={450000} sunPosition={[40, 25, 30]} inclination={0.2} azimuth={0.25} />

        {/* Core Animated Scene Elements */}
        <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.5}>
          <SailingShip />
        </Float>
        <OceanWater />
        <Atmosphere />
      </Canvas>
    </div>
  );
}
