"use client";

import React from "react";
import BountyStudioToolbar from "@/components/bounty/BountyStudioToolbar";
import BountyStudioSidebar from "@/components/bounty/BountyStudioSidebar";
import BountyStudioCanvas from "@/components/bounty/BountyStudioCanvas";

// ============================================================================
// CANVA-GRADE BOUNTY STUDIO MAIN WRAPPER
// ============================================================================

export default function BountyStudioMain() {
  return (
    <div className="w-full h-screen bg-background flex flex-col overflow-hidden selection:bg-treasure selection:text-ocean-deep">
      {/* Wooden Top Toolbar */}
      <BountyStudioToolbar />
      {/* Studio Workspace Split View */}
      <div className="flex-grow flex flex-col md:flex-row overflow-hidden w-full h-full">
        <BountyStudioSidebar />
        <main className="flex-grow relative overflow-hidden h-full">
          <BountyStudioCanvas />
        </main>
      </div>
    </div>
  );
}
