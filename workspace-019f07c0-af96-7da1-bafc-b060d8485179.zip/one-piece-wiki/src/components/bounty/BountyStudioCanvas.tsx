"use client";

import React, { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useBountyStudioStore } from "@/store/bountyStudioStore";
import { BountyCanvasLayer } from "@/lib/validations";
import { Move, RotateCw, Maximize2, Lock, EyeOff } from "lucide-react";

// ============================================================================
// CANVA-GRADE BOUNTY STUDIO CANVAS CORE
// ============================================================================

export default function BountyStudioCanvas() {
  const {
    layers,
    activeLayerId,
    zoom,
    panX,
    panY,
    snapToGrid,
    showSmartGuides,
    showRulers,
    setActiveLayerId,
    updateLayer,
    setEditorParam,
  } = useBountyStudioStore();

  const containerRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [isResizing, setIsResizing] = useState(false);
  const [isRotating, setIsRotating] = useState(false);
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });

  const activeLayer = layers.find((l) => l.id === activeLayerId);

  // Pan & Zoom Mouse Handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 1 || e.shiftKey) { // Middle click or shift click for pan
      e.preventDefault();
      setIsPanning(true);
      setPanStart({ x: e.clientX - panX, y: e.clientY - panY });
    } else if (e.target === containerRef.current) {
      setActiveLayerId(null);
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      setEditorParam({ panX: e.clientX - panStart.x, panY: e.clientY - panStart.y });
      return;
    }

    if (!activeLayer || activeLayer.locked) return;

    if (isDragging) {
      let nextX = e.clientX - dragStart.x;
      let nextY = e.clientY - dragStart.y;
      if (snapToGrid) {
        nextX = Math.round(nextX / 20) * 20;
        nextY = Math.round(nextY / 20) * 20;
      }
      updateLayer(activeLayer.id, { x: nextX, y: nextY });
    } else if (isResizing) {
      let nextW = Math.max(50, (e.clientX - dragStart.x) / zoom);
      let nextH = Math.max(50, (e.clientY - dragStart.y) / zoom);
      if (snapToGrid) {
        nextW = Math.round(nextW / 20) * 20;
        nextH = Math.round(nextH / 20) * 20;
      }
      updateLayer(activeLayer.id, { width: nextW, height: nextH });
    } else if (isRotating) {
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) return;
      const centerTargetX = rect.left + (activeLayer.x + activeLayer.width / 2) * zoom + panX;
      const centerTargetY = rect.top + (activeLayer.y + activeLayer.height / 2) * zoom + panY;
      const rad = Math.atan2(e.clientY - centerTargetY, e.clientX - centerTargetX);
      let deg = Math.round(rad * (180 / Math.PI));
      if (snapToGrid && Math.abs(deg % 15) < 5) {
        deg = Math.round(deg / 15) * 15;
      }
      updateLayer(activeLayer.id, { rotation: deg });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setIsResizing(false);
    setIsRotating(false);
    setIsPanning(false);
  };

  const initLayerDrag = (e: React.MouseEvent, layer: BountyCanvasLayer) => {
    e.stopPropagation();
    setActiveLayerId(layer.id);
    if (layer.locked) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - layer.x, y: e.clientY - layer.y });
  };

  const initResize = (e: React.MouseEvent, layer: BountyCanvasLayer) => {
    e.stopPropagation();
    if (layer.locked) return;
    setIsResizing(true);
    setDragStart({ x: e.clientX - layer.width * zoom, y: e.clientY - layer.height * zoom });
  };

  const initRotate = (e: React.MouseEvent, layer: BountyCanvasLayer) => {
    e.stopPropagation();
    if (layer.locked) return;
    setIsRotating(true);
  };

  return (
    <div
      ref={containerRef}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className="relative w-full h-full bg-ocean-deep overflow-hidden flex items-center justify-center cursor-default select-none shadow-inner"
      style={{
        backgroundImage: snapToGrid ? "radial-gradient(rgba(212, 175, 55, 0.15) 1px, transparent 0)" : "none",
        backgroundSize: `${20 * zoom}px ${20 * zoom}px`,
      }}
    >
      {/* Smart Rulers Overlay */}
      {showRulers && (
        <>
          <div className="absolute top-0 left-0 right-0 h-6 bg-wooden-plank border-b border-treasure/50 z-20 flex items-center overflow-hidden font-mono text-[10px] text-paper">
            {Array.from({ length: 40 }).map((_, i) => (
              <div key={i} className="flex-shrink-0 border-l border-treasure/30 pl-1 h-full flex items-center" style={{ width: `${100 * zoom}px` }}>
                {i * 100}px
              </div>
            ))}
          </div>
          <div className="absolute top-0 left-0 bottom-0 w-6 bg-wooden-plank border-r border-treasure/50 z-20 flex flex-col overflow-hidden font-mono text-[10px] text-paper pt-6">
            {Array.from({ length: 40 }).map((_, i) => (
              <div key={i} className="flex-shrink-0 border-t border-treasure/30 pt-1 w-full flex items-start justify-center" style={{ height: `${100 * zoom}px` }}>
                {i * 100}
              </div>
            ))}
          </div>
        </>
      )}

      {/* Main Virtual Canvas Container */}
      <div
        className="relative shadow-2xl transition-transform duration-75 origin-center"
        style={{
          width: "800px",
          height: "1120px",
          transform: `scale(${zoom}) translate(${panX}px, ${panY}px)`,
          backgroundColor: "#e5d3b3", // Base Old Paper
        }}
      >
        {/* Render Layers Array */}
        {layers.map((layer) => {
          if (!layer.visible) return null;
          const isActive = layer.id === activeLayerId;
          const filter = layer.filterConfig;
          const filterString = filter
            ? `sepia(${filter.sepia * 100}%) contrast(${filter.contrast * 100}%) brightness(${filter.brightness * 100}%) blur(${filter.scratchIntensity * 5}px)`
            : "none";

          return (
            <div
              key={layer.id}
              onMouseDown={(e) => initLayerDrag(e, layer)}
              className={cn(
                "absolute origin-center select-none group",
                isActive ? "ring-2 ring-treasure ring-offset-2 ring-offset-ocean-deep z-50" : "",
                layer.locked ? "cursor-not-allowed opacity-90" : "cursor-move"
              )}
              style={{
                left: `${layer.x}px`,
                top: `${layer.y}px`,
                width: `${layer.width}px`,
                height: `${layer.height}px`,
                transform: `rotate(${layer.rotation}deg) scaleX(${layer.scaleX}) scaleY(${layer.scaleY})`,
                opacity: layer.opacity,
                zIndex: layer.zIndex,
              }}
            >
              {/* Layer Types Rendering */}
              {layer.type === "border" && (
                <img src={layer.content} alt={layer.name} className="w-full h-full object-cover pointer-events-none" />
              )}
              {layer.type === "image" && (
                <img src={layer.content} alt={layer.name} className="w-full h-full object-cover pointer-events-none rounded-sm" style={{ filter: filterString }} />
              )}
              {layer.type === "text" && (
                <div
                  className="w-full h-full flex items-center justify-center text-center font-bold tracking-wider leading-none drop-shadow-sm"
                  style={{
                    fontFamily: layer.fontFamily || "Cinzel",
                    fontSize: `${layer.fontSize || 60}px`,
                    color: layer.color || "#2b180d",
                    letterSpacing: `${layer.letterSpacing || 2}px`,
                  }}
                >
                  {layer.content}
                </div>
              )}
              {layer.type === "filter" && (
                <div className="w-full h-full border-[16px] border-wood/40 rounded-xl pointer-events-none shadow-inner opacity-80" />
              )}
              {layer.type === "seal" && (
                <div className="w-full h-full rounded-full bg-sunset-crimson border-4 border-wood flex items-center justify-center text-white font-cinematic font-bold text-xs shadow-premium-gilded animate-pulse">
                  MARINE SEAL
                </div>
              )}

              {/* Locked/Hide Badge Overlay */}
              {layer.locked && (
                <div className="absolute top-1 right-1 bg-wood text-treasure p-1 rounded shadow-sm z-50 pointer-events-none">
                  <Lock className="w-3.5 h-3.5" />
                </div>
              )}

              {/* Interactive Resize & Rotate Handles */}
              {isActive && !layer.locked && (
                <>
                  <div
                    onMouseDown={(e) => initResize(e, layer)}
                    className="absolute -bottom-2 -right-2 w-6 h-6 bg-treasure border-2 border-ocean-deep rounded-full flex items-center justify-center cursor-se-resize shadow-premium-gilded z-50 hover:scale-125 transition-transform"
                    title="Resize Handle"
                  >
                    <Maximize2 className="w-3.5 h-3.5 text-ocean-deep" />
                  </div>
                  <div
                    onMouseDown={(e) => initRotate(e, layer)}
                    className="absolute -top-6 left-1/2 -translate-x-1/2 w-6 h-6 bg-sunset border-2 border-ocean-deep rounded-full flex items-center justify-center cursor-grab active:cursor-grabbing shadow-glowing-bounty z-50 hover:scale-125 transition-transform"
                    title="Rotate Handle"
                  >
                    <RotateCw className="w-3.5 h-3.5 text-white" />
                  </div>
                </>
              )}
            </div>
          );
        })}

        {/* Smart Guides Display */}
        {showSmartGuides && activeLayer && !activeLayer.locked && (
          <>
            {/* Center Vertical Guide */}
            <div className="absolute top-0 bottom-0 left-1/2 w-[1px] bg-treasure/60 border-l border-dashed border-treasure z-40 pointer-events-none" />
            {/* Center Horizontal Guide */}
            <div className="absolute left-0 right-0 top-1/2 h-[1px] bg-treasure/60 border-t border-dashed border-treasure z-40 pointer-events-none" />
          </>
        )}
      </div>
    </div>
  );
}
