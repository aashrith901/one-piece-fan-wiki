"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { useBountyStudioStore } from "@/store/bountyStudioStore";
import { Button, Input, Select } from "@/components/ui/buttons";
import { Tabs } from "@/components/ui/navigation-ui";
import { Layers, Folder, Filter, Type, Palette, Lock, Unlock, Eye, EyeOff, Copy, Trash2, ArrowUp, ArrowDown, ChevronRight, Upload, Star, Plus } from "lucide-react";

// ============================================================================
// CANVA-GRADE BOUNTY STUDIO SIDEBAR TOOLS
// ============================================================================

export default function BountyStudioSidebar() {
  const {
    projectTitle,
    characterName,
    bountyAmount,
    folder,
    isFavorite,
    layers,
    activeLayerId,
    setProjectMetadata,
    setActiveLayerId,
    addLayer,
    updateLayer,
    duplicateLayer,
    deleteLayer,
    reorderLayer,
    toggleLayerLock,
    toggleLayerVisibility,
    resetToTemplate,
  } = useBountyStudioStore();

  const [activeTab, setActiveTab] = useState("layers");
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const activeLayer = layers.find((l) => l.id === activeLayerId);

  // Upload Simulation (5MB validation)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      setToastMessage("File size exceeds 5MB limit. Please compress your asset.");
      return;
    }
    const url = URL.createObjectURL(file);
    addLayer({
      type: "image",
      name: file.name,
      x: 100,
      y: 300,
      width: 600,
      height: 450,
      rotation: 0,
      content: url,
      filterConfig: { sepia: 0.1, contrast: 1.1, brightness: 1, scratchIntensity: 0, burnIntensity: 0, tornEdgeIntensity: 0 },
    });
    setToastMessage("Asset successfully verified, uploaded, and added to the layer stack!");
  };

  const templatesList = [
    { id: 1, name: "Pre-Timeskip Marine Classic", img: "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?q=80&w=600&auto=format&fit=crop", desc: "Classic bold World Government notice." },
    { id: 2, name: "New World Ancient Parchment", img: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=600&auto=format&fit=crop", desc: "Heavily burned and weathered parchment." },
    { id: 3, name: "Cross Guild Marine Wanted", img: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?q=80&w=600&auto=format&fit=crop", desc: "Dark Buggy organization framing." },
  ];

  const applyTemplate = (tmpl: any) => {
    const defaultLayers = [
      { id: "bg_1", type: "border" as const, name: "Base Background", x: 0, y: 0, width: 800, height: 1120, rotation: 0, scaleX: 1, scaleY: 1, opacity: 1, visible: true, locked: true, zIndex: 1, content: tmpl.img },
      { id: "img_1", type: "image" as const, name: "Character Photo", x: 100, y: 250, width: 600, height: 450, rotation: 0, scaleX: 1, scaleY: 1, opacity: 1, visible: true, locked: false, zIndex: 2, content: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=800&auto=format&fit=crop", filterConfig: { sepia: 0.2, contrast: 1.1, brightness: 1.05, scratchIntensity: 0.1, burnIntensity: 0.2, tornEdgeIntensity: 0 } },
      { id: "txt_name", type: "text" as const, name: "CHARACTER ALIAS", x: 100, y: 750, width: 600, height: 90, rotation: 0, scaleX: 1, scaleY: 1, opacity: 1, visible: true, locked: false, zIndex: 3, content: characterName || "MONKEY D. LUFFY", fontFamily: tmpl.id === 3 ? "Inter" : "Pirata One", fontSize: 75, color: tmpl.id === 3 ? "#ffffff" : "#2b180d", letterSpacing: 5 },
      { id: "txt_bounty", type: "text" as const, name: "BOUNTY AMOUNT", x: 100, y: 880, width: 600, height: 90, rotation: 0, scaleX: 1, scaleY: 1, opacity: 1, visible: true, locked: false, zIndex: 4, content: `฿ ${bountyAmount || "3,000,000,000"}`, fontFamily: "JetBrains Mono", fontSize: 65, color: tmpl.id === 3 ? "#ff6b35" : "#2b180d", letterSpacing: 3 },
    ];
    resetToTemplate(defaultLayers);
    setProjectMetadata({ templateId: tmpl.id, projectTitle: `${tmpl.name} Custom Poster` });
    setToastMessage(`Reset studio workspace to ${tmpl.name} template.`);
  };

  return (
    <aside className="w-80 sm:w-96 flex-shrink-0 bg-wooden-plank border-r-4 border-treasure flex flex-col justify-between select-none h-full z-20 text-paper overflow-hidden shadow-premium-ocean">
      {/* Toast Notification Popup */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="absolute bottom-6 left-6 right-6 z-50 bg-ocean-royal text-ocean-foam border-2 border-treasure p-4 rounded-2xl shadow-premium-ocean flex items-center justify-between text-xs"
          >
            <span>{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="text-treasure hover:underline font-bold">Close</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Primary Tools Navigation Header */}
      <div className="flex items-center justify-around border-b border-treasure/30 p-2 bg-ocean-deep">
        {[
          { key: "layers", label: "Layers", icon: <Layers className="w-5 h-5" /> },
          { key: "tools", label: "Inspect", icon: <Filter className="w-5 h-5" /> },
          { key: "effects", label: "Decals", icon: <Palette className="w-5 h-5" /> },
          { key: "project", label: "Project", icon: <Folder className="w-5 h-5" /> },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={cn(
              "flex flex-col items-center p-3 rounded-2xl font-cinematic text-xs tracking-wider transition-all",
              activeTab === tab.key ? "bg-treasure text-ocean-deep font-bold shadow-premium-gilded" : "text-ocean-foam/80 hover:text-treasure"
            )}
          >
            {tab.icon}
            <span className="mt-1">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Main Tab Viewport */}
      <div className="flex-grow overflow-y-auto p-6 space-y-8 scrollbar-none">
        {/* ============================================================================ */}
        {/* 1. LAYER MANAGER TAB */}
        {/* ============================================================================ */}
        {activeTab === "layers" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-treasure/30 pb-3">
              <h4 className="font-cinematic text-xl font-bold text-treasure flex items-center">
                <Layers className="w-5 h-5 mr-2 text-treasure" /> LAYER MANAGER ({layers.length})
              </h4>
              <button onClick={() => addLayer({ type: "text", name: "Custom Text", x: 200, y: 500, width: 400, height: 80, rotation: 0, content: "NEW HEADER", fontFamily: "Cinzel", fontSize: 60, color: "#2b180d", letterSpacing: 5 })} className="p-2 rounded-xl bg-ocean-deep text-treasure hover:bg-ocean-royal border border-treasure shadow-sm text-xs flex items-center space-x-1 font-cinematic font-bold">
                <Plus className="w-4 h-4" /> <span>ADD TEXT</span>
              </button>
            </div>

            {/* Custom Upload Button */}
            <div className="p-4 bg-ocean-deep border-2 border-dashed border-treasure rounded-2xl text-center shadow-sm">
              <label className="cursor-pointer flex flex-col items-center justify-center">
                <Upload className="w-6 h-6 text-treasure mb-2 animate-bounce" />
                <span className="font-cinematic text-sm font-bold text-ocean-foam block">UPLOAD IMAGE / LOGO</span>
                <span className="font-sans text-[10px] text-ocean-foam/60 block mt-1">PNG, JPG, SVG • Max 5MB</span>
                <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>

            {/* Layers Listing */}
            <div className="space-y-2">
              {layers.slice().reverse().map((layer) => {
                const isActive = layer.id === activeLayerId;
                return (
                  <div
                    key={layer.id}
                    onClick={() => setActiveLayerId(layer.id)}
                    className={cn(
                      "flex items-center justify-between p-4 rounded-2xl border-2 transition-all cursor-pointer group",
                      isActive ? "bg-ocean-deep border-treasure text-treasure shadow-premium-gilded" : "bg-card/20 border-border/40 text-paper hover:border-treasure"
                    )}
                  >
                    <div className="flex items-center space-x-3 overflow-hidden">
                      <span className="font-mono text-xs text-muted-foreground flex-shrink-0">#{layer.zIndex}</span>
                      <Input
                        value={layer.name}
                        onChange={(e) => updateLayer(layer.id, { name: e.target.value })}
                        className="bg-transparent border-transparent h-8 text-sm font-cinematic font-bold tracking-wide focus:bg-input focus:text-foreground w-36"
                      />
                    </div>
                    {/* Action Bar */}
                    <div className="flex items-center space-x-1 flex-shrink-0">
                      <button onClick={(e) => { e.stopPropagation(); toggleLayerVisibility(layer.id); }} className="p-1.5 rounded hover:bg-muted/30 text-paper" title="Toggle Visibility">
                        {layer.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4 text-muted-foreground" />}
                      </button>
                      <button onClick={(e) => { e.stopPropagation(); toggleLayerLock(layer.id); }} className="p-1.5 rounded hover:bg-muted/30 text-paper" title="Toggle Lock">
                        {layer.locked ? <Lock className="w-4 h-4 text-treasure" /> : <Unlock className="w-4 h-4 text-muted-foreground" />}
                      </button>
                      <button onClick={(e) => { e.stopPropagation(); duplicateLayer(layer.id); setToastMessage("Duplicated layer!"); }} className="p-1.5 rounded hover:bg-muted/30 text-paper" title="Duplicate Layer">
                        <Copy className="w-4 h-4 text-emerald" />
                      </button>
                      <button onClick={(e) => { e.stopPropagation(); deleteLayer(layer.id); setToastMessage("Deleted layer."); }} className="p-1.5 rounded hover:bg-sunset-crimson text-paper" title="Delete Layer">
                        <Trash2 className="w-4 h-4 text-destructive hover:text-white" />
                      </button>
                      {/* Reorder Arrows */}
                      <button onClick={(e) => { e.stopPropagation(); reorderLayer(layer.id, "up"); }} className="p-1 rounded hover:bg-muted/30 text-paper" title="Move Up">
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={(e) => { e.stopPropagation(); reorderLayer(layer.id, "down"); }} className="p-1 rounded hover:bg-muted/30 text-paper" title="Move Down">
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ============================================================================ */}
        {/* 2. INSPECTOR TOOLTAB (TEXT & IMAGE STYLING) */}
        {/* ============================================================================ */}
        {activeTab === "tools" && (
          <div className="space-y-8">
            <h4 className="font-cinematic text-xl font-bold text-treasure border-b border-treasure/30 pb-3 flex items-center">
              <Filter className="w-5 h-5 mr-2 text-treasure" /> ASSET INSPECTOR
            </h4>

            {!activeLayer ? (
              <div className="text-center py-12 text-paper/60 font-sans text-sm italic">
                Select a layer from the canvas or Layer Manager to inspect and configure its specific style parameters.
              </div>
            ) : (
              <div className="space-y-6">
                <div className="p-4 bg-ocean-deep border border-treasure rounded-2xl flex items-center justify-between">
                  <span className="font-cinematic font-bold text-treasure">{activeLayer.name}</span>
                  <span className="bg-wood text-treasure px-3 py-1 rounded-full text-xs font-cinematic uppercase tracking-widest border border-treasure shadow-sm">
                    {activeLayer.type}
                  </span>
                </div>

                {/* Common Transform Controls */}
                <div className="space-y-4 pt-4 border-t border-treasure/20">
                  <h5 className="font-cinematic text-sm font-bold text-paper uppercase tracking-wider">TRANSFORM PARAMETERS</h5>
                  <div className="grid grid-cols-2 gap-4">
                    <div><span className="text-xs font-mono text-paper/80 block mb-1">POS X (px)</span><Input type="number" value={Math.round(activeLayer.x)} onChange={(e) => updateLayer(activeLayer.id, { x: parseFloat(e.target.value) || 0 })} className="h-11 text-sm font-mono" /></div>
                    <div><span className="text-xs font-mono text-paper/80 block mb-1">POS Y (px)</span><Input type="number" value={Math.round(activeLayer.y)} onChange={(e) => updateLayer(activeLayer.id, { y: parseFloat(e.target.value) || 0 })} className="h-11 text-sm font-mono" /></div>
                    <div><span className="text-xs font-mono text-paper/80 block mb-1">WIDTH (px)</span><Input type="number" value={Math.round(activeLayer.width)} onChange={(e) => updateLayer(activeLayer.id, { width: Math.max(50, parseFloat(e.target.value) || 50) })} className="h-11 text-sm font-mono" /></div>
                    <div><span className="text-xs font-mono text-paper/80 block mb-1">HEIGHT (px)</span><Input type="number" value={Math.round(activeLayer.height)} onChange={(e) => updateLayer(activeLayer.id, { height: Math.max(50, parseFloat(e.target.value) || 50) })} className="h-11 text-sm font-mono" /></div>
                    <div><span className="text-xs font-mono text-paper/80 block mb-1">ROTATE (deg)</span><Input type="number" value={Math.round(activeLayer.rotation)} onChange={(e) => updateLayer(activeLayer.id, { rotation: parseFloat(e.target.value) || 0 })} className="h-11 text-sm font-mono" /></div>
                    <div><span className="text-xs font-mono text-paper/80 block mb-1">OPACITY</span><Input type="number" step="0.1" min="0" max="1" value={activeLayer.opacity} onChange={(e) => updateLayer(activeLayer.id, { opacity: parseFloat(e.target.value) || 1 })} className="h-11 text-sm font-mono" /></div>
                  </div>
                </div>

                {/* Text Specific Parameters */}
                {activeLayer.type === "text" && (
                  <div className="space-y-4 pt-4 border-t border-treasure/20">
                    <h5 className="font-cinematic text-sm font-bold text-paper uppercase tracking-wider">TEXT SPECIFICATIONS</h5>
                    <div>
                      <span className="text-xs font-mono text-paper/80 block mb-1">HEADER CONTENT</span>
                      <Input value={activeLayer.content} onChange={(e) => updateLayer(activeLayer.id, { content: e.target.value })} className="h-11 font-cinematic font-bold text-base" />
                    </div>
                    <div>
                      <span className="text-xs font-mono text-paper/80 block mb-1">FONT FAMILY</span>
                      <Select options={[{ label: "Cinzel (Cinematic Serif)", value: "Cinzel" }, { label: "Pirata One (Pirate Woodcut)", value: "Pirata One" }, { label: "JetBrains Mono", value: "JetBrains Mono" }, { label: "Inter (Modern Sans)", value: "Inter" }]} value={activeLayer.fontFamily || "Cinzel"} onChange={(e) => updateLayer(activeLayer.id, { fontFamily: e.target.value })} className="font-cinematic font-bold text-sm h-11" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div><span className="text-xs font-mono text-paper/80 block mb-1">FONT SIZE (px)</span><Input type="number" value={activeLayer.fontSize || 60} onChange={(e) => updateLayer(activeLayer.id, { fontSize: parseFloat(e.target.value) || 60 })} className="h-11 text-sm font-mono" /></div>
                      <div><span className="text-xs font-mono text-paper/80 block mb-1">SPACING (px)</span><Input type="number" value={activeLayer.letterSpacing || 2} onChange={(e) => updateLayer(activeLayer.id, { letterSpacing: parseFloat(e.target.value) || 2 })} className="h-11 text-sm font-mono" /></div>
                    </div>
                  </div>
                )}

                {/* Image Specific Filters */}
                {activeLayer.type === "image" && activeLayer.filterConfig && (
                  <div className="space-y-4 pt-4 border-t border-treasure/20">
                    <h5 className="font-cinematic text-sm font-bold text-paper uppercase tracking-wider">IMAGE CSS FILTERS</h5>
                    <div>
                      <div className="flex justify-between text-xs font-mono mb-1"><span>SEPIA TONE</span><span>{Math.round(activeLayer.filterConfig.sepia * 100)}%</span></div>
                      <input type="range" min="0" max="1" step="0.05" value={activeLayer.filterConfig.sepia} onChange={(e) => updateLayer(activeLayer.id, { filterConfig: { ...activeLayer.filterConfig!, sepia: parseFloat(e.target.value) } })} className="w-full accent-treasure cursor-pointer" />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs font-mono mb-1"><span>CONTRAST GAIN</span><span>{Math.round(activeLayer.filterConfig.contrast * 100)}%</span></div>
                      <input type="range" min="0" max="2" step="0.1" value={activeLayer.filterConfig.contrast} onChange={(e) => updateLayer(activeLayer.id, { filterConfig: { ...activeLayer.filterConfig!, contrast: parseFloat(e.target.value) } })} className="w-full accent-treasure cursor-pointer" />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs font-mono mb-1"><span>BRIGHTNESS</span><span>{Math.round(activeLayer.filterConfig.brightness * 100)}%</span></div>
                      <input type="range" min="0" max="2" step="0.1" value={activeLayer.filterConfig.brightness} onChange={(e) => updateLayer(activeLayer.id, { filterConfig: { ...activeLayer.filterConfig!, brightness: parseFloat(e.target.value) } })} className="w-full accent-treasure cursor-pointer" />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs font-mono mb-1"><span>BLUR SCRATCHES</span><span>{Math.round(activeLayer.filterConfig.scratchIntensity * 5)}px</span></div>
                      <input type="range" min="0" max="1" step="0.1" value={activeLayer.filterConfig.scratchIntensity} onChange={(e) => updateLayer(activeLayer.id, { filterConfig: { ...activeLayer.filterConfig!, scratchIntensity: parseFloat(e.target.value) } })} className="w-full accent-treasure cursor-pointer" />
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ============================================================================ */}
        {/* 3. DECALS & POSTER EFFECTS TAB */}
        {/* ============================================================================ */}
        {activeTab === "effects" && (
          <div className="space-y-6">
            <h4 className="font-cinematic text-xl font-bold text-treasure border-b border-treasure/30 pb-3 flex items-center">
              <Palette className="w-5 h-5 mr-2 text-treasure" /> POSTER EFFECTS VAULT
            </h4>
            <p className="font-sans text-xs text-paper/80 leading-relaxed">
              Attach original pirate-inspired decals, burn marks, wax seals, and distressed paper textures to your layer stack.
            </p>
            <div className="grid grid-cols-2 gap-4">
              {[
                { name: "Old Paper Texture", type: "filter", content: "old_paper_texture" },
                { name: "Burned Edge Decal", type: "filter", content: "burnt_edge_overlay" },
                { name: "Torn Paper Corner", type: "filter", content: "torn_paper_overlay" },
                { name: "Marine Wax Seal", type: "seal", content: "marine_red_seal" },
                { name: "Ink Stain Splatter", type: "filter", content: "ink_stain_overlay" },
                { name: "Coffee Ring Stain", type: "filter", content: "coffee_stain_overlay" },
                { name: "Rope Border Frame", type: "filter", content: "rope_border_overlay" },
                { name: "Compass Decal", type: "filter", content: "compass_decal_overlay" },
              ].map((eff, idx) => (
                <div key={idx} onClick={() => { addLayer({ type: eff.type as any, name: eff.name, x: 200, y: 300, width: 400, height: 400, rotation: 0, content: eff.content }); setToastMessage(`Added ${eff.name} decal!`); }} className="p-4 bg-ocean-deep border-2 border-ocean-royal hover:border-treasure rounded-2xl cursor-pointer text-center group shadow-sm transition-all">
                  <div className="w-12 h-12 mx-auto rounded-full bg-wood border border-treasure flex items-center justify-center text-treasure group-hover:scale-110 transition-transform mb-2 font-cinematic font-bold text-xs">
                    EFF
                  </div>
                  <span className="font-cinematic text-xs font-bold text-ocean-foam block group-hover:text-treasure transition-colors">{eff.name}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ============================================================================ */}
        {/* 4. PROJECT & TEMPLATES MANAGER TAB */}
        {/* ============================================================================ */}
        {activeTab === "project" && (
          <div className="space-y-8">
            <h4 className="font-cinematic text-xl font-bold text-treasure border-b border-treasure/30 pb-3 flex items-center">
              <Folder className="w-5 h-5 mr-2 text-treasure" /> PROJECT & TEMPLATES
            </h4>

            <div className="space-y-4">
              <div>
                <span className="text-xs font-mono text-paper/80 block mb-1">PROJECT TITLE</span>
                <Input value={projectTitle} onChange={(e) => setProjectMetadata({ projectTitle: e.target.value })} className="h-11 font-cinematic font-bold text-base" />
              </div>
              <div>
                <span className="text-xs font-mono text-paper/80 block mb-1">TARGET PIRATE NAME</span>
                <Input value={characterName} onChange={(e) => setProjectMetadata({ characterName: e.target.value })} className="h-11 font-cinematic font-bold text-base" />
              </div>
              <div>
                <span className="text-xs font-mono text-paper/80 block mb-1">WANTED REWARD AMOUNT</span>
                <Input value={bountyAmount} onChange={(e) => setProjectMetadata({ bountyAmount: e.target.value })} className="h-11 font-mono text-base font-bold" />
              </div>
              <div>
                <span className="text-xs font-mono text-paper/80 block mb-1">FOLDER ORGANIZATION</span>
                <Input value={folder} onChange={(e) => setProjectMetadata({ folder: e.target.value })} className="h-11 font-sans text-sm" />
              </div>
              <div className="flex items-center justify-between p-4 bg-ocean-deep border border-treasure rounded-xl">
                <span className="font-cinematic text-sm font-bold text-treasure flex items-center"><Star className="w-4 h-4 mr-1.5 text-treasure fill-current" /> FAVORITE PROJECT</span>
                <input type="checkbox" checked={isFavorite} onChange={(e) => setProjectMetadata({ isFavorite: e.target.checked })} className="rounded border-border text-treasure focus:ring-treasure w-4 h-4" />
              </div>
            </div>

            {/* Template Browser */}
            <div className="space-y-4 pt-6 border-t border-treasure/20">
              <h5 className="font-cinematic text-base font-bold text-paper uppercase tracking-wider">EDITABLE TEMPLATE LIBRARY</h5>
              <div className="space-y-4">
                {templatesList.map((tmpl) => (
                  <div key={tmpl.id} onClick={() => applyTemplate(tmpl)} className="bg-ocean-deep border-2 border-ocean-royal hover:border-treasure rounded-2xl p-4 cursor-pointer shadow-sm group transition-all">
                    <img src={tmpl.img} alt={tmpl.name} className="w-full h-28 object-cover rounded-xl mb-3 border border-treasure/40 group-hover:scale-102 transition-transform" />
                    <h6 className="font-cinematic text-sm font-bold text-treasure group-hover:text-treasure-light transition-colors">{tmpl.name}</h6>
                    <p className="font-sans text-xs text-ocean-foam/70 mt-1">{tmpl.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
