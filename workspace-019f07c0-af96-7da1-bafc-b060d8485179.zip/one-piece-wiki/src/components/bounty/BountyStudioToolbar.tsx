"use client";

import React, { useState, useEffect, useTransition } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { useBountyStudioStore } from "@/store/bountyStudioStore";
import { Button, Select, Input } from "@/components/ui/buttons";
import { Dialog } from "@/components/ui/navigation-ui";
import { Undo2, Redo2, ZoomIn, ZoomOut, Save, Download, HelpCircle, AlignLeft, AlignCenter, AlignRight, Shield, Flame, CheckCircle2, AlertTriangle, RefreshCw, Layers } from "lucide-react";

// ============================================================================
// CANVA-GRADE BOUNTY STUDIO WOODEN TOOLBAR
// ============================================================================

export default function BountyStudioToolbar() {
  const {
    projectId,
    projectTitle,
    characterName,
    bountyAmount,
    zoom,
    snapToGrid,
    showSmartGuides,
    showRulers,
    isDirty,
    lastSaved,
    layers,
    setProjectMetadata,
    setEditorParam,
    undo,
    redo,
    activeLayerId,
    updateLayer,
  } = useBountyStudioStore();

  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  const [exportFormat, setExportFormat] = useState("PNG");
  const [exportQuality, setExportQuality] = useState("High Resolution");
  const [isExporting, setIsExporting] = useState(false);
  const [downloadLink, setDownloadLink] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Background Autosave Engine Simulation
  useEffect(() => {
    if (!isDirty) return;
    const timer = setTimeout(() => {
      setProjectMetadata({ lastSaved: new Date().toLocaleTimeString(), isDirty: false });
      // Background fetch simulation
      fetch("/api/bounties/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "save", projectId, projectData: { title: projectTitle, characterName, bountyAmount, layersData: layers, templateId: 1, isPublic: true } }),
      }).catch((err) => console.error("Autosave err:", err));
    }, 3000);
    return () => clearTimeout(timer);
  }, [isDirty, layers, projectTitle, characterName, bountyAmount, projectId, setProjectMetadata]);

  // Keyboard Shortcuts Hook
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "z") {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
      } else if ((e.metaKey || e.ctrlKey) && e.key === "s") {
        e.preventDefault();
        setProjectMetadata({ lastSaved: new Date().toLocaleTimeString(), isDirty: false });
        setToastMessage("Project manually saved to the Drizzle ORM cloud storage!");
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [undo, redo, setProjectMetadata]);

  const handleExportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsExporting(true);
    setDownloadLink(null);

    try {
      const res = await fetch("/api/bounties/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "export", format: exportFormat, quality: exportQuality, previewUrl: layers[1]?.content || "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=1200&auto=format&fit=crop" }),
      });
      const data = await res.json();
      setIsExporting(false);

      if (data.success) {
        setDownloadLink(data.downloadUrl);
        setToastMessage(data.message);
      } else {
        setToastMessage(`Export failed: ${data.error}`);
      }
    } catch (err) {
      setIsExporting(false);
      setToastMessage("Network error during compilation.");
    }
  };

  const activeLayer = layers.find((l) => l.id === activeLayerId);

  return (
    <header className="sticky top-0 z-40 w-full bg-wooden-plank border-b-4 border-treasure shadow-premium-ocean select-none h-20 px-4 sm:px-6 lg:px-8 flex items-center justify-between text-paper overflow-hidden">
      {/* Toast Notification Popup */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 bg-ocean-royal text-ocean-foam border-2 border-treasure p-6 rounded-2xl shadow-premium-ocean flex items-center space-x-4 max-w-sm"
          >
            <CheckCircle2 className="w-6 h-6 text-treasure flex-shrink-0" />
            <span className="font-sans text-sm font-medium">{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="text-xs text-treasure hover:underline">Close</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Export Dialog */}
      <Dialog isOpen={isExportModalOpen} onClose={() => setIsExportModalOpen(false)} title="COMPILE BOUNTY POSTER EXPORT" className="max-w-2xl">
        <form onSubmit={handleExportSubmit} className="space-y-8">
          <p className="font-sans text-base text-foreground leading-relaxed">
            Select your preferred digital format and print-quality resolution. Our Sharp-powered rasterization engine will compile the complete layer stack, including custom burn marks and wax seals.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
            <div>
              <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">DIGITAL FILE FORMAT</span>
              <Select options={[{ label: "PNG (Lossless Bitmap)", value: "PNG" }, { label: "JPG (Standard Web)", value: "JPG" }, { label: "PDF (Press Vector)", value: "PDF" }, { label: "SVG (Scalable Vector)", value: "SVG" }]} value={exportFormat} onChange={(e) => setExportFormat(e.target.value)} className="font-cinematic font-bold text-lg h-12" />
            </div>
            <div>
              <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">OUTPUT QUALITY TIER</span>
              <Select options={[{ label: "Standard Resolution (800x1120)", value: "Standard" }, { label: "High Resolution (1600x2240)", value: "High Resolution" }, { label: "Print Quality (2400x3360)", value: "Print Quality" }]} value={exportQuality} onChange={(e) => setExportQuality(e.target.value)} className="font-cinematic font-bold text-lg h-12" />
            </div>
          </div>

          {downloadLink && (
            <div className="p-6 bg-emerald-dark/10 border-2 border-emerald text-emerald-dark rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
              <div><span className="font-cinematic text-lg font-bold block">COMPILE COMPLETE!</span><span className="font-sans text-xs italic block">Your high-fidelity poster is ready for download.</span></div>
              <Button variant="gilded" size="default" type="button" onClick={() => window.open(downloadLink, "_blank")}>DOWNLOAD ASSET NOW</Button>
            </div>
          )}

          <div className="flex justify-end pt-6 border-t border-border">
            <Button variant="gilded" size="lg" type="submit" isLoading={isExporting}>
              INITIALIZE EXPORT ENGINE
            </Button>
          </div>
        </form>
      </Dialog>

      {/* Keyboard Shortcuts Helper Modal */}
      <Dialog isOpen={isHelpModalOpen} onClose={() => setIsHelpModalOpen(false)} title="STUDIO KEYBOARD SHORTCUTS" className="max-w-2xl">
        <div className="space-y-6 font-sans text-base text-foreground">
          <p>Master the Canva-grade studio workspace using these global keymap ciphers:</p>
          <div className="space-y-3 font-mono text-sm border-t border-border pt-4">
            <div className="flex justify-between border-b border-border/40 pb-2"><span>Undo Previous Action</span><span className="bg-muted px-2 py-1 rounded font-bold">Ctrl / ⌘ + Z</span></div>
            <div className="flex justify-between border-b border-border/40 pb-2"><span>Redo Action Stack</span><span className="bg-muted px-2 py-1 rounded font-bold">Ctrl / ⌘ + Shift + Z</span></div>
            <div className="flex justify-between border-b border-border/40 pb-2"><span>Manual Project Save</span><span className="bg-muted px-2 py-1 rounded font-bold">Ctrl / ⌘ + S</span></div>
            <div className="flex justify-between border-b border-border/40 pb-2"><span>Pan Virtual Canvas</span><span className="bg-muted px-2 py-1 rounded font-bold">Shift + Drag / Middle Click</span></div>
          </div>
          <div className="flex justify-end pt-4"><Button variant="gilded" size="default" onClick={() => setIsHelpModalOpen(false)}>CLOSE CIPHER LOG</Button></div>
        </div>
      </Dialog>

      {/* ============================================================================ */}
      {/* TOOLBAR LEFT: PROJECT TITLE & AUTOSAVE INDICATOR */}
      {/* ============================================================================ */}
      <div className="flex items-center space-x-4 overflow-hidden">
        <a href="/" className="flex items-center space-x-2 flex-shrink-0 group">
          <Flame className="w-8 h-8 text-sunset animate-bounce" />
          <span className="hidden md:block font-cinematic text-2xl font-bold text-treasure group-hover:text-treasure-light transition-colors">BOUNTY STUDIO</span>
        </a>
        <div className="h-8 w-[1px] bg-treasure/40 hidden md:block" />
        <div className="overflow-hidden">
          <Input value={projectTitle} onChange={(e) => setProjectMetadata({ projectTitle: e.target.value })} className="bg-transparent border-transparent h-10 font-cinematic font-bold text-lg text-paper tracking-wide focus:bg-input focus:text-foreground w-40 sm:w-64" />
          <div className="flex items-center space-x-2 pl-4 -mt-1">
            <span className={cn("w-2 h-2 rounded-full", isDirty ? "bg-sunset animate-pulse" : "bg-emerald")} />
            <span className="font-mono text-[10px] text-paper/70">
              {isDirty ? "Saving changes..." : `Saved: ${lastSaved}`}
            </span>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* TOOLBAR MIDDLE: UNDO/REDO & ALIGNMENT TOOLS */}
      {/* ============================================================================ */}
      <div className="hidden lg:flex items-center space-x-3 bg-ocean-deep border border-treasure p-2 rounded-2xl shadow-premium-ocean">
        <button onClick={undo} className="p-2 rounded-xl text-ocean-foam hover:text-treasure hover:bg-ocean-royal transition-all shadow-sm" title="Undo (Ctrl+Z)"><Undo2 className="w-5 h-5" /></button>
        <button onClick={redo} className="p-2 rounded-xl text-ocean-foam hover:text-treasure hover:bg-ocean-royal transition-all shadow-sm" title="Redo (Ctrl+Shift+Z)"><Redo2 className="w-5 h-5" /></button>
        <div className="h-6 w-[1px] bg-treasure/40" />
        {/* Zoom */}
        <button onClick={() => setEditorParam({ zoom: Math.max(0.3, zoom - 0.1) })} className="p-2 rounded-xl text-ocean-foam hover:text-treasure hover:bg-ocean-royal transition-all shadow-sm" title="Zoom Out"><ZoomOut className="w-5 h-5" /></button>
        <span className="font-mono text-xs font-bold text-treasure w-12 text-center">{Math.round(zoom * 100)}%</span>
        <button onClick={() => setEditorParam({ zoom: Math.min(2, zoom + 0.1) })} className="p-2 rounded-xl text-ocean-foam hover:text-treasure hover:bg-ocean-royal transition-all shadow-sm" title="Zoom In"><ZoomIn className="w-5 h-5" /></button>
        <div className="h-6 w-[1px] bg-treasure/40" />
        {/* Alignment Actions */}
        <button onClick={() => activeLayer && updateLayer(activeLayer.id, { x: 50 })} className="p-2 rounded-xl text-ocean-foam hover:text-treasure hover:bg-ocean-royal transition-all shadow-sm" title="Align Left"><AlignLeft className="w-5 h-5" /></button>
        <button onClick={() => activeLayer && updateLayer(activeLayer.id, { x: 400 - activeLayer.width / 2 })} className="p-2 rounded-xl text-ocean-foam hover:text-treasure hover:bg-ocean-royal transition-all shadow-sm" title="Align Center"><AlignCenter className="w-5 h-5" /></button>
        <button onClick={() => activeLayer && updateLayer(activeLayer.id, { x: 750 - activeLayer.width })} className="p-2 rounded-xl text-ocean-foam hover:text-treasure hover:bg-ocean-royal transition-all shadow-sm" title="Align Right"><AlignRight className="w-5 h-5" /></button>
        <div className="h-6 w-[1px] bg-treasure/40" />
        {/* Grid & Guides Switches */}
        <button onClick={() => setEditorParam({ snapToGrid: !snapToGrid })} className={cn("px-3 py-1.5 rounded-xl font-cinematic text-xs font-bold tracking-wider uppercase transition-all", snapToGrid ? "bg-treasure text-ocean-deep shadow-premium-gilded" : "text-ocean-foam hover:text-treasure")} title="Snap to Grid">Grid</button>
        <button onClick={() => setEditorParam({ showSmartGuides: !showSmartGuides })} className={cn("px-3 py-1.5 rounded-xl font-cinematic text-xs font-bold tracking-wider uppercase transition-all", showSmartGuides ? "bg-treasure text-ocean-deep shadow-premium-gilded" : "text-ocean-foam hover:text-treasure")} title="Smart Guides">Guides</button>
        <button onClick={() => setEditorParam({ showRulers: !showRulers })} className={cn("px-3 py-1.5 rounded-xl font-cinematic text-xs font-bold tracking-wider uppercase transition-all", showRulers ? "bg-treasure text-ocean-deep shadow-premium-gilded" : "text-ocean-foam hover:text-treasure")} title="Show Rulers">Rulers</button>
      </div>

      {/* ============================================================================ */}
      {/* TOOLBAR RIGHT: SAVE, HELP & EXPORT */}
      {/* ============================================================================ */}
      <div className="flex items-center space-x-3">
        <button onClick={() => setIsHelpModalOpen(true)} className="p-3 rounded-xl bg-ocean-deep text-ocean-foam hover:text-treasure border border-treasure shadow-sm transition-all" title="Keyboard Shortcuts"><HelpCircle className="w-5 h-5" /></button>
        <button onClick={() => { setProjectMetadata({ lastSaved: new Date().toLocaleTimeString(), isDirty: false }); setToastMessage("Project manually saved to Drizzle cloud storage!"); }} className="p-3 rounded-xl bg-ocean-deep text-ocean-foam hover:text-treasure border border-treasure shadow-sm transition-all hidden sm:block" title="Manual Save"><Save className="w-5 h-5" /></button>
        <Button variant="gilded" size="default" onClick={() => setIsExportModalOpen(true)} leftIcon={<Download className="w-4 h-4 text-ocean-deep" />}>
          COMPILE EXPORT
        </Button>
      </div>
    </header>
  );
}
