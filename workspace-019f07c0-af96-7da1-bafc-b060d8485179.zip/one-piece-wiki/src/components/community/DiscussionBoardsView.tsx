"use client";

import React, { useState, useEffect, useTransition } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, SearchInput, Select, Input } from "@/components/ui/buttons";
import { Dialog, Tabs } from "@/components/ui/navigation-ui";
import { SkeletonLoader, EmptyState } from "@/components/ui/feedback";
import { RopeBorder, TreasureMapContainer, WoodenPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs } from "@/components/navigation/navigation-system";
import { MessageSquare, Pin, Lock, Unlock, Image as ImageIcon, CheckCircle2, Edit3, Filter, MessageCircle, AlertTriangle } from "lucide-react";

// ============================================================================
// DISCUSSION BOARDS EXPLORER CLIENT COMPONENT
// ============================================================================

export default function DiscussionBoardsView() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [threadsList, setThreadsList] = useState<any[]>([]);
  const [isPending, startTransition] = useTransition();
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // New Thread Form States
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newCategory, setNewCategory] = useState("General Discussion");
  const [newContent, setNewContent] = useState("");
  const [isDraftSaved, setIsDraftSaved] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // 18 Categories exactly matching prompt requirements
  const categories = [
    { label: "All Chatrooms", value: "all" },
    { label: "General Discussion", value: "General Discussion" },
    { label: "Anime Discussion", value: "Anime Discussion" },
    { label: "Manga Discussion", value: "Manga Discussion" },
    { label: "Theories & Speculation", value: "Theories" },
    { label: "Characters", value: "Characters" },
    { label: "Devil Fruits", value: "Devil Fruits" },
    { label: "Powerscaling Matrices", value: "Powerscaling" },
    { label: "World Government", value: "World Government" },
    { label: "Marines", value: "Marines" },
    { label: "Yonko", value: "Yonko" },
    { label: "Straw Hats", value: "Straw Hats" },
    { label: "Arc Discussions", value: "Arc Discussions" },
    { label: "Episode Discussions", value: "Episode Discussions" },
    { label: "Chapter Discussions", value: "Chapter Discussions" },
    { label: "Movies & Live Action", value: "Movies" },
    { label: "Fan Art Showcase", value: "Fan Art Showcase" },
    { label: "Questions & Answers", value: "Questions & Answers" },
    { label: "Off Topic", value: "Off Topic" },
  ];

  useEffect(() => {
    startTransition(async () => {
      try {
        const res = await fetch(`/api/community?q=${encodeURIComponent(query)}&category=${encodeURIComponent(category)}`);
        const data = await res.json();
        if (data.success) {
          setThreadsList(data.data);
        }
      } catch (err) {
        console.error("Board fetch error:", err);
      }
    });

    // Auto load draft from localStorage
    const savedDraft = localStorage.getItem("one_piece_thread_draft");
    if (savedDraft) {
      const parsed = JSON.parse(savedDraft);
      setNewTitle(parsed.title || "");
      setNewCategory(parsed.category || "General Discussion");
      setNewContent(parsed.content || "");
      setIsDraftSaved(true);
    }
  }, [query, category]);

  // Auto save draft logic
  const handleContentChange = (val: string) => {
    setNewContent(val);
    const draft = { title: newTitle, category: newCategory, content: val };
    localStorage.setItem("one_piece_thread_draft", JSON.stringify(draft));
    setIsDraftSaved(true);
  };

  const handleCreateThread = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const res = await fetch("/api/community", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          slug: newTitle.toLowerCase().replace(/[^a-z0-9]/g, "-"),
          title: newTitle,
          category: newCategory,
          content: newContent,
        }),
      });
      const data = await res.json();
      setIsSubmitting(false);

      if (data.success) {
        setToastMessage("Discussion thread successfully broadcasted to the Grand Line forums!");
        localStorage.removeItem("one_piece_thread_draft");
        setIsDraftSaved(false);
        setIsEditorOpen(false);
        setNewTitle("");
        setNewContent("");
        // Refresh list simulation
        setThreadsList((prev) => [
          {
            id: Date.now(),
            slug: newTitle.toLowerCase().replace(/[^a-z0-9]/g, "-"),
            title: newTitle,
            category: newCategory,
            content: newContent,
            author: { name: "Super Fan Admiral", image: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=400&auto=format&fit=crop", level: 90, title: "Rookie Admiral" },
            upvotes: 1,
            repliesCount: 0,
            tags: ["New"],
            createdAt: new Date().toISOString(),
          },
          ...prev,
        ]);
      } else {
        setErrorMessage(data.error || "Failed to broadcast thread.");
      }
    } catch (err) {
      setIsSubmitting(false);
      setErrorMessage("Network error during broadcast.");
    }
  };

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* Toast Notification Popup */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 bg-ocean-royal text-ocean-foam border-2 border-treasure p-6 rounded-2xl shadow-premium-ocean flex items-center space-x-4 max-w-sm"
          >
            <CheckCircle2 className="w-6 h-6 text-treasure flex-shrink-0" />
            <span className="font-sans text-sm font-medium">{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="text-xs text-treasure hover:underline">Close</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Rich Text Editor Modal */}
      <Dialog isOpen={isEditorOpen} onClose={() => setIsEditorOpen(false)} title="BROADCAST DEN DEN MUSHI TRANSMISSION" className="max-w-4xl">
        <form onSubmit={handleCreateThread} className="space-y-6">
          {errorMessage && (
            <div className="p-4 rounded-xl bg-sunset-crimson/10 border-2 border-sunset-crimson text-sunset-crimson font-sans text-sm flex items-center space-x-3">
              <AlertTriangle className="w-5 h-5 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">THREAD TITLE</span>
              <Input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="e.g., The True Purpose of the Mother Flame" />
            </div>
            <div>
              <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">FORUM CATEGORY</span>
              <Select options={categories.slice(1)} value={newCategory} onChange={(e) => setNewCategory(e.target.value)} className="font-cinematic font-bold text-lg h-12" />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block">TRANSMISSION BODY (MARKDOWN & SPOILER TAGS SUPPORTED)</span>
              {isDraftSaved && <span className="font-mono text-xs text-emerald-dark font-bold">Draft Auto-Saved</span>}
            </div>
            <textarea
              value={newContent}
              onChange={(e) => handleContentChange(e.target.value)}
              rows={10}
              placeholder="Write your theory, powerscaling breakdown, or question here... Use >!spoiler!< for hidden text or ```code``` for logs."
              className="w-full rounded-2xl bg-input border border-border p-4 text-foreground focus:outline-none focus:ring-2 focus:ring-treasure font-sans text-base shadow-sm"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-border">
            <div className="flex items-center space-x-3">
              <button type="button" onClick={() => setToastMessage("Image upload simulation active. Added image tag to editor.")} className="p-3 rounded-xl bg-card border border-border hover:border-treasure text-foreground flex items-center space-x-2 text-xs font-cinematic font-bold shadow-sm">
                <ImageIcon className="w-4 h-4 text-treasure" /> <span>UPLOAD EVIDENCE IMAGE / GIF</span>
              </button>
              <button type="button" onClick={() => handleContentChange(newContent + " >!SPOILER TEXT HERE!< ")} className="p-3 rounded-xl bg-card border border-border hover:border-treasure text-foreground flex items-center space-x-2 text-xs font-cinematic font-bold shadow-sm">
                <span>ADD SPOILER TAG</span>
              </button>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="default" type="button" onClick={() => setIsEditorOpen(false)}>SAVE DRAFT & CLOSE</Button>
              <Button variant="gilded" size="default" type="submit" isLoading={isSubmitting}>BROADCAST TRANSMISSION</Button>
            </div>
          </div>
        </form>
      </Dialog>

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[45vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-treasure/20 via-ocean-deep to-ocean-royal pointer-events-none" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs items={[{ label: "Grand Line Wiki", href: "/" }, { label: "Community Hub", href: "/community/boards" }, { label: "Discussion Boards" }]} />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <span className="inline-block bg-wood text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-sm mb-3">
                UNIVERSAL CHATROOMS
              </span>
              <h1 className="text-5xl sm:text-6xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
                THE 18 DISCUSSION BOARDS
              </h1>
              <p className="text-lg font-sans text-ocean-foam/80 italic mt-1">Explore theories, powerscaling matrices, arc reviews, and fan art showcases.</p>
            </div>
            <div>
              <Button variant="gilded" size="lg" onClick={() => setIsEditorOpen(true)} leftIcon={<Edit3 className="w-5 h-5 text-ocean-deep" />}>
                BROADCAST NEW THREAD
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* SEARCH & FILTERS CONTAINER */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <TreasureMapContainer className="mb-12">
          <div className="space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <h3 className="text-3xl font-cinematic font-bold text-foreground tracking-wide">FORUM INDEX EXPLORER</h3>
                <p className="text-base font-sans text-muted-foreground mt-1">Instantly scan across 15,420+ active den den mushi chatrooms.</p>
              </div>
            </div>

            <div className="relative w-full">
              <SearchInput
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onClear={() => setQuery("")}
                placeholder="Search threads by title, theory keywords, or author... (e.g. 'Vegapunk', 'Katakuri', 'Mother Flame')"
                className="max-w-full text-xl h-16 bg-ocean-deep text-ocean-foam border-2 border-treasure shadow-premium-ocean"
                isSearching={isPending}
              />
            </div>

            {/* 18 Category Filter Buttons */}
            <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
              <Filter className="w-5 h-5 text-treasure flex-shrink-0 mr-2" />
              {categories.map((cat) => (
                <button
                  key={cat.value}
                  onClick={() => setCategory(cat.value)}
                  className={cn(
                    "px-4 py-2.5 rounded-xl font-cinematic text-sm font-bold tracking-wider whitespace-nowrap transition-all shadow-sm border flex-shrink-0",
                    category === cat.value
                      ? "bg-treasure text-ocean-deep border-treasure shadow-premium-gilded"
                      : "bg-card text-foreground border-border hover:border-treasure"
                  )}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>
        </TreasureMapContainer>

        {/* ============================================================================ */}
        {/* THREADS LISTING */}
        {/* ============================================================================ */}
        <div className="space-y-6 mt-12">
          {isPending && threadsList.length === 0 ? (
            <SkeletonLoader count={4} />
          ) : threadsList.length === 0 ? (
            <EmptyState title="NO THREADS FOUND IN THIS CATEGORY" message="No active den den mushi chatrooms match your current filter parameters." />
          ) : (
            threadsList.map((thread) => (
              <div
                key={thread.id}
                onClick={() => (window.location.href = `/community/boards/${thread.slug}`)}
                className="bg-card border-2 border-border rounded-3xl p-8 shadow-paper-lift cursor-pointer hover:border-treasure transition-all duration-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 group"
              >
                <div className="space-y-3 flex-grow">
                  <div className="flex items-center space-x-3">
                    {thread.pinned && <span className="bg-sunset-crimson text-white px-3 py-1 rounded-full text-xs font-cinematic font-bold border border-treasure shadow-sm flex items-center"><Pin className="w-3.5 h-3.5 mr-1" /> PINNED</span>}
                    {thread.locked && <span className="bg-muted text-muted-foreground px-3 py-1 rounded-full text-xs font-cinematic font-bold border border-border flex items-center"><Lock className="w-3.5 h-3.5 mr-1" /> LOCKED</span>}
                    <span className="bg-wood text-treasure px-3 py-1 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase border border-treasure shadow-sm">
                      {thread.category}
                    </span>
                    <span className="font-mono text-xs text-muted-foreground">{new Date(thread.createdAt).toLocaleDateString()}</span>
                  </div>
                  <h4 className="text-2xl font-cinematic font-bold text-foreground group-hover:text-treasure-dark transition-colors tracking-wide">
                    {thread.title}
                  </h4>
                  <p className="font-sans text-base text-muted-foreground leading-relaxed line-clamp-2 font-medium">
                    {thread.content}
                  </p>
                  <div className="flex flex-wrap gap-2 pt-2">
                    {thread.tags?.map((tag: string, idx: number) => (
                      <span key={idx} className="text-[10px] font-mono bg-muted text-muted-foreground px-2 py-0.5 rounded-md border border-border">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex flex-row md:flex-col items-center md:items-end justify-between w-full md:w-auto border-t md:border-t-0 md:border-l border-border pt-4 md:pt-0 md:pl-6 gap-4">
                  <div className="flex items-center space-x-3 md:space-x-0 md:flex-col md:items-end">
                    <img src={thread.author.image} alt={thread.author.name} className="w-10 h-10 rounded-full object-cover border border-treasure shadow-sm md:mb-1" />
                    <span className="font-cinematic text-sm font-bold text-foreground block md:text-right">{thread.author.name}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="flex items-center font-cinematic text-xs font-bold text-ocean-foam bg-ocean-deep px-3 py-1.5 rounded-xl border border-treasure shadow-sm">
                      👍 {thread.upvotes}
                    </span>
                    <span className="flex items-center font-cinematic text-xs font-bold text-treasure bg-ocean-deep px-3 py-1.5 rounded-xl border border-treasure shadow-sm">
                      <MessageCircle className="w-3.5 h-3.5 mr-1 text-treasure" /> {thread.repliesCount}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
