"use client";

import React, { useState, useEffect, useTransition } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, Input, Select } from "@/components/ui/buttons";
import { Tabs, Table, Dialog } from "@/components/ui/navigation-ui";
import { SkeletonLoader } from "@/components/ui/feedback";
import { RopeBorder, TreasureMapContainer, WoodenPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { Shield, Flag, Trash2, Ban, VolumeX, CheckCircle2, AlertTriangle, RefreshCw, Pin, Settings } from "lucide-react";

// ============================================================================
// GOROSEI MODERATOR DASHBOARD CLIENT COMPONENT
// ============================================================================

export default function ModeratorDashboard() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  // Moderation Store States
  const [reportedItems, setReportedItems] = useState<any[]>([]);
  const [bannedUsers, setBannedUsers] = useState<string[]>([]);
  const [mutedUsers, setMutedUsers] = useState<string[]>([]);
  const [warningLogs, setWarningLogs] = useState<Record<string, number>>({});
  const [systemHealth, setSystemHealth] = useState("100% Secure");

  // Manual Action Form States
  const [targetUser, setTargetUser] = useState("");
  const [manualAction, setManualAction] = useState("ban"); // ban, mute, warn

  useEffect(() => {
    startTransition(async () => {
      try {
        const res = await fetch("/api/moderation");
        const data = await res.json();
        if (data.success) {
          setReportedItems(data.data.reportedItems);
          setBannedUsers(data.data.bannedUsers);
          setMutedUsers(data.data.mutedUsers);
          setWarningLogs(data.data.warningLogs);
          setSystemHealth(data.data.systemHealth);
        }
      } catch (err) {
        console.error("Moderation fetch error:", err);
      }
    });
  }, []);

  const executeAction = async (actionBody: any) => {
    try {
      const res = await fetch("/api/moderation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(actionBody),
      });
      const data = await res.json();
      if (data.success) {
        setToastMessage(data.message);
        // Local state updates for UI feedback
        if (actionBody.action === "resolveReport") {
          setReportedItems((prev) => prev.filter((item) => item.id !== actionBody.reportId));
        } else if (actionBody.action === "ban" && actionBody.username) {
          setBannedUsers((prev) => [...prev, actionBody.username]);
        } else if (actionBody.action === "mute" && actionBody.username) {
          setMutedUsers((prev) => [...prev, actionBody.username]);
        }
      } else {
        setToastMessage(`Error: ${data.error}`);
      }
    } catch (err) {
      setToastMessage("Network error during moderation broadcast.");
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetUser.trim()) {
      setToastMessage("Target pirate alias is required.");
      return;
    }
    executeAction({ action: manualAction, username: targetUser.trim() });
    setTargetUser("");
  };

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* Toast Notification Popup */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 bg-ocean-royal text-ocean-foam border-2 border-treasure p-6 rounded-2xl shadow-premium-ocean flex items-center space-x-4 max-w-sm"
          >
            <CheckCircle2 className="w-6 h-6 text-treasure flex-shrink-0" />
            <span className="font-sans text-sm font-medium">{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="text-xs text-treasure hover:underline">Close</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[40vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-sunset-crimson/20 via-ocean-deep to-ocean-royal pointer-events-none" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs items={[{ label: "Grand Line Wiki", href: "/" }, { label: "Gorosei Administration" }, { label: "Moderator Dashboard" }]} />
          <div>
            <span className="inline-block bg-sunset-crimson text-white font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-widest uppercase border border-treasure shadow-glowing-bounty mb-3">
              AUTHORITY OF THE FIVE ELDERS
            </span>
            <h1 className="text-5xl sm:text-6xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
              GOROSEI MODERATION ENGINE
            </h1>
            <p className="text-lg font-sans text-ocean-foam/80 italic mt-1">Review reported transponder snail broadcasts, manage active Buster Call bans, and pin global announcements.</p>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MODERATION TABS */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <Tabs
          items={[
            {
              id: "reports",
              label: "REPORTED TRANSMISSIONS",
              content: (
                <div className="space-y-16">
                  <SectionHeader title="FLAGGED DEN DEN MUSHI LOGS" subtitle="Active Spam & Harassment Traps" />
                  <Table
                    columns={[
                      { header: "Flag Type", accessor: (row) => <span className="font-cinematic text-sm font-bold text-sunset-crimson bg-card px-3 py-1 rounded-full border border-sunset-crimson uppercase">{row.type}</span>, className: "w-32" },
                      { header: "Infringing Author", accessor: (row) => <span className="font-cinematic text-lg font-bold text-foreground">{row.author}</span>, className: "w-40" },
                      { header: "Violation Reason", accessor: "reason", className: "font-sans text-base text-muted-foreground" },
                      { header: "Time Flagged", accessor: (row) => <span className="font-mono text-xs text-muted-foreground">{new Date(row.reportedAt).toLocaleString()}</span>, className: "w-40" },
                      { header: "Gorosei Action", accessor: (row) => (
                        <div className="flex items-center justify-end space-x-2">
                          <Button variant="crimson" size="sm" onClick={() => executeAction({ action: "ban", username: row.author })}>BAN ALIAS</Button>
                          <Button variant="gilded" size="sm" onClick={() => executeAction({ action: "resolveReport", reportId: row.id })}>RESOLVE</Button>
                        </div>
                      ), className: "text-right w-64" },
                    ]}
                    data={reportedItems}
                  />
                </div>
              ),
            },
            {
              id: "manual_actions",
              label: "EXECUTE BUSTER CALL (BANS & MUTES)",
              content: (
                <form onSubmit={handleManualSubmit} className="space-y-12">
                  <TreasureMapContainer className="space-y-8">
                    <h3 className="text-3xl font-cinematic font-bold text-foreground flex items-center border-b border-border pb-4">
                      <Ban className="w-8 h-8 mr-3 text-sunset-crimson animate-pulse" /> EXECUTE MANUAL SUPPRESSION ORDER
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div>
                        <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">TARGET PIRATE ALIAS</span>
                        <Input value={targetUser} onChange={(e) => setTargetUser(e.target.value)} placeholder="e.g., SpamPirate99" />
                      </div>
                      <div>
                        <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">SELECT SUPPRESSION TYPE</span>
                        <Select
                          options={[
                            { label: "Permanent Account Ban (Buster Call)", value: "ban" },
                            { label: "Mute Transponder Snail (Den Den Mushi Jam)", value: "mute" },
                            { label: "Issue Official Government Warning", value: "warn" },
                          ]}
                          value={manualAction}
                          onChange={(e) => setManualAction(e.target.value)}
                          className="font-cinematic font-bold text-lg h-12"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end border-t border-border pt-6">
                      <Button variant="crimson" size="lg" type="submit">
                        BROADCAST SUPPRESSION ORDER
                      </Button>
                    </div>
                  </TreasureMapContainer>

                  {/* Active Lists */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-8">
                    <div className="bg-card border-2 border-border rounded-3xl p-8 shadow-paper-lift space-y-4">
                      <h4 className="font-cinematic text-xl font-bold text-sunset-crimson flex items-center border-b border-border pb-2">
                        <Ban className="w-5 h-5 mr-2" /> BANNED FLEET ALIASES
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {bannedUsers.map((u, i) => (<span key={i} className="px-4 py-2 bg-sunset-crimson text-white rounded-xl font-cinematic font-bold">{u}</span>))}
                      </div>
                    </div>
                    <div className="bg-card border-2 border-border rounded-3xl p-8 shadow-paper-lift space-y-4">
                      <h4 className="font-cinematic text-xl font-bold text-foreground flex items-center border-b border-border pb-2">
                        <VolumeX className="w-5 h-5 mr-2 text-muted-foreground" /> MUTED FLEET ALIASES
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {mutedUsers.map((u, i) => (<span key={i} className="px-4 py-2 bg-muted text-muted-foreground rounded-xl font-cinematic font-bold">{u}</span>))}
                      </div>
                    </div>
                  </div>
                </form>
              ),
            },
            {
              id: "pin_banner",
              label: "GLOBAL PINNED BANNERS",
              content: (
                <TreasureMapContainer className="space-y-8">
                  <h3 className="text-3xl font-cinematic font-bold text-foreground flex items-center border-b border-border pb-4">
                    <Pin className="w-8 h-8 mr-3 text-treasure" /> GLOBAL BANNER ARCHITECT
                  </h3>
                  <p className="font-sans text-base text-foreground leading-relaxed">
                    Instantly attach an existing discussion thread or official news dispatch to the primary global banner of the Community Hub.
                  </p>
                  <div className="flex justify-end border-t border-border pt-6">
                    <Button variant="gilded" size="lg" onClick={() => executeAction({ action: "pin" })}>
                      PIN THREAD TO WORLD GOVERNMENT BANNER
                    </Button>
                  </div>
                </TreasureMapContainer>
              ),
            },
          ]}
        />
      </div>

      <Footer />
    </div>
  );
}
