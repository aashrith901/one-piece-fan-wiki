"use client";

import React, { useState, useEffect, useTransition } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, SearchInput, Select, Input } from "@/components/ui/buttons";
import { Dialog, Tabs } from "@/components/ui/navigation-ui";
import { SkeletonLoader, EmptyState } from "@/components/ui/feedback";
import { RopeBorder, TreasureMapContainer, WoodenPanel, CoinParticles } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { BarChart2, Calendar, CheckCircle2, RefreshCw, Share2, AlertTriangle, HelpCircle, User, Flame, TrendingUp } from "lucide-react";

// ============================================================================
// UNIVERSAL POLLS STUDIO CLIENT COMPONENT
// ============================================================================

export default function PollsStudioView() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [pollsList, setPollsList] = useState<any[]>([]);
  const [isPending, startTransition] = useTransition();
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [votedPolls, setVotedPolls] = useState<Record<number, number>>({}); // pollId -> optionId

  // New Poll Form States
  const [isCreatorOpen, setIsCreatorOpen] = useState(false);
  const [newQuestion, setNewQuestion] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [option1, setOption1] = useState("");
  const [option2, setOption2] = useState("");
  const [option3, setOption3] = useState("");
  const [option4, setOption4] = useState("");
  const [isMultipleChoice, setIsMultipleChoice] = useState(false);
  const [isAnonymous, setIsAnonymous] = useState(true);
  const [expiresInDays, setExpiresInDays] = useState("7");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    startTransition(async () => {
      try {
        const res = await fetch(`/api/community?type=polls&q=${encodeURIComponent(query)}`);
        const data = await res.json();
        if (data.success) {
          setPollsList(data.data);
        }
      } catch (err) {
        console.error("Polls fetch error:", err);
      }
    });

    const vp = localStorage.getItem("one_piece_voted_polls");
    if (vp) setVotedPolls(JSON.parse(vp));
  }, [query]);

  const handleVote = (pollId: number, optionId: number) => {
    if (votedPolls[pollId]) {
      setToastMessage("You have already broadcasted your transponder snail vote for this poll!");
      return;
    }
    const nextVp = { ...votedPolls, [pollId]: optionId };
    setVotedPolls(nextVp);
    localStorage.setItem("one_piece_voted_polls", JSON.stringify(nextVp));

    // Update poll counts
    setPollsList((prev) =>
      prev.map((p) => {
        if (p.id === pollId) {
          const nextOpts = p.options.map((opt: any) =>
            opt.id === optionId ? { ...opt, votes: opt.votes + 1 } : opt
          );
          const total = nextOpts.reduce((acc: number, cur: any) => acc + cur.votes, 0);
          const recalcOpts = nextOpts.map((opt: any) => ({ ...opt, percent: Math.round((opt.votes / total) * 100) }));
          return { ...p, options: recalcOpts, totalVotes: total };
        }
        return p;
      })
    );
    setToastMessage("Vote successfully recorded on the Grand Line blockchain!");
  };

  const handleCreatePoll = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMessage(null);

    if (!newQuestion.trim() || !option1.trim() || !option2.trim()) {
      setIsSubmitting(false);
      setErrorMessage("Question and at least two voting options are required to establish a community poll.");
      return;
    }

    try {
      const res = await fetch("/api/community", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "poll",
          slug: newQuestion.toLowerCase().replace(/[^a-z0-9]/g, "-"),
          question: newQuestion,
          description: newDescription,
          options: [
            { optionText: option1 },
            { optionText: option2 },
            ...(option3.trim() ? [{ optionText: option3 }] : []),
            ...(option4.trim() ? [{ optionText: option4 }] : []),
          ],
          expiresInDays: parseInt(expiresInDays, 10),
          isMultipleChoice,
          isAnonymous,
        }),
      });
      const data = await res.json();
      setIsSubmitting(false);

      if (data.success) {
        setToastMessage("Community Poll successfully broadcasted to the Grand Line!");
        setIsCreatorOpen(false);
        // Refresh simulation
        setPollsList((prev) => [
          {
            id: Date.now(),
            slug: newQuestion.toLowerCase().replace(/[^a-z0-9]/g, "-"),
            question: newQuestion,
            description: newDescription,
            author: { name: "Super Fan Admiral", image: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=400&auto=format&fit=crop" },
            isActive: true,
            expiresAt: new Date(Date.now() + parseInt(expiresInDays, 10) * 86400000).toISOString(),
            options: [
              { id: Date.now() + 1, text: option1, votes: 1, percent: option3 ? 34 : 50 },
              { id: Date.now() + 2, text: option2, votes: 1, percent: option3 ? 33 : 50 },
              ...(option3.trim() ? [{ id: Date.now() + 3, text: option3, votes: 1, percent: 33 }] : []),
              ...(option4.trim() ? [{ id: Date.now() + 4, text: option4, votes: 0, percent: 0 }] : []),
            ],
            totalVotes: option3 ? 3 : 2,
          },
          ...prev,
        ]);
        setNewQuestion("");
        setNewDescription("");
        setOption1("");
        setOption2("");
        setOption3("");
        setOption4("");
      } else {
        setErrorMessage(data.error || "Failed to broadcast poll.");
      }
    } catch (err) {
      setIsSubmitting(false);
      setErrorMessage("Network error during broadcast.");
    }
  };

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* Toast Notification Popup */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 bg-ocean-royal text-ocean-foam border-2 border-treasure p-6 rounded-2xl shadow-premium-ocean flex items-center space-x-4 max-w-sm"
          >
            <CheckCircle2 className="w-6 h-6 text-treasure flex-shrink-0" />
            <span className="font-sans text-sm font-medium">{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="text-xs text-treasure hover:underline">Close</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Create Poll Modal */}
      <Dialog isOpen={isCreatorOpen} onClose={() => setIsCreatorOpen(false)} title="ESTABLISH UNIVERSAL COMMUNITY POLL" className="max-w-3xl">
        <form onSubmit={handleCreatePoll} className="space-y-6">
          {errorMessage && (
            <div className="p-4 rounded-xl bg-sunset-crimson/10 border-2 border-sunset-crimson text-sunset-crimson font-sans text-sm flex items-center space-x-3">
              <AlertTriangle className="w-5 h-5 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <div>
            <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">POLL QUESTION</span>
            <Input value={newQuestion} onChange={(e) => setNewQuestion(e.target.value)} placeholder="e.g., Which ancient weapon is the most destructive?" />
          </div>

          <div>
            <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">OPTIONAL LORE DESCRIPTION / CONTEXT</span>
            <textarea value={newDescription} onChange={(e) => setNewDescription(e.target.value)} rows={3} placeholder="Explain the context or rules of this voting ballot..." className="w-full rounded-xl bg-input border border-border p-4 text-foreground focus:outline-none focus:ring-2 focus:ring-treasure font-sans text-sm shadow-sm" />
          </div>

          <div className="space-y-4 pt-4 border-t border-border">
            <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block">BALLOT OPTIONS (MINIMUM 2 REQUIRED)</span>
            <Input value={option1} onChange={(e) => setOption1(e.target.value)} placeholder="Option 1 (e.g., Uranus Mother Flame)" />
            <Input value={option2} onChange={(e) => setOption2(e.target.value)} placeholder="Option 2 (e.g., Pluton Underworld Battleship)" />
            <Input value={option3} onChange={(e) => setOption3(e.target.value)} placeholder="Option 3 (Optional)" />
            <Input value={option4} onChange={(e) => setOption4(e.target.value)} placeholder="Option 4 (Optional)" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-4 border-t border-border">
            <div className="flex items-center justify-between p-4 bg-card border border-border rounded-xl">
              <span className="font-cinematic text-xs font-bold text-foreground uppercase">MULTIPLE CHOICE</span>
              <input type="checkbox" checked={isMultipleChoice} onChange={(e) => setIsMultipleChoice(e.target.checked)} className="rounded border-border text-treasure focus:ring-treasure w-4 h-4" />
            </div>
            <div className="flex items-center justify-between p-4 bg-card border border-border rounded-xl">
              <span className="font-cinematic text-xs font-bold text-foreground uppercase">ANONYMOUS VOTING</span>
              <input type="checkbox" checked={isAnonymous} onChange={(e) => setIsAnonymous(e.target.checked)} className="rounded border-border text-treasure focus:ring-treasure w-4 h-4" />
            </div>
            <div>
              <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">EXPIRATION TIMER</span>
              <Select options={[{ label: "7 Days", value: "7" }, { label: "14 Days", value: "14" }, { label: "30 Days", value: "30" }]} value={expiresInDays} onChange={(e) => setExpiresInDays(e.target.value)} className="font-cinematic font-bold text-sm h-11" />
            </div>
          </div>

          <div className="flex justify-end pt-6 border-t border-border">
            <Button variant="gilded" size="default" type="submit" isLoading={isSubmitting}>BROADCAST VOTING BALLOT</Button>
          </div>
        </form>
      </Dialog>

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[45vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-treasure/20 via-ocean-deep to-ocean-royal pointer-events-none" />
        <CoinParticles count={15} />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs items={[{ label: "Grand Line Wiki", href: "/" }, { label: "Community Hub", href: "/community/boards" }, { label: "Universal Polls" }]} />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <span className="inline-block bg-wood text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-sm mb-3">
                UNIVERSAL BALLOTS
              </span>
              <h1 className="text-5xl sm:text-6xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
                GRAND LINE COMMUNITY POLLS
              </h1>
              <p className="text-lg font-sans text-ocean-foam/80 italic mt-1">Participate in live universal ballots, powerscaling votes, and theory validation matrices.</p>
            </div>
            <div>
              <Button variant="gilded" size="lg" onClick={() => setIsCreatorOpen(true)} leftIcon={<BarChart2 className="w-5 h-5 text-ocean-deep" />}>
                ESTABLISH COMMUNITY POLL
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* SEARCH & POLLS LISTING */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <TreasureMapContainer className="mb-12">
          <div className="space-y-8">
            <h3 className="text-3xl font-cinematic font-bold text-foreground tracking-wide">SEARCH ACTIVE BALLOTS</h3>
            <SearchInput value={query} onChange={(e) => setQuery(e.target.value)} onClear={() => setQuery("")} placeholder="Search polls by question, character, or topic..." className="max-w-full text-xl h-16 bg-ocean-deep text-ocean-foam border-2 border-treasure shadow-premium-ocean" isSearching={isPending} />
          </div>
        </TreasureMapContainer>

        {/* Polls Listing */}
        <div className="space-y-12 mt-12">
          {isPending && pollsList.length === 0 ? (
            <SkeletonLoader count={3} />
          ) : pollsList.length === 0 ? (
            <EmptyState title="NO ACTIVE POLLS MATCH YOUR ENQUIRY" message="No community polls match your active search phrasing." />
          ) : (
            pollsList.map((poll) => {
              const hasVoted = votedPolls[poll.id] !== undefined;
              return (
                <div key={poll.id} className="bg-ocean-deep text-ocean-foam border-4 border-treasure rounded-3xl p-8 sm:p-12 shadow-premium-ocean space-y-8">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-ocean-royal pb-4">
                    <div className="flex items-center space-x-3">
                      <img src={poll.author.image} alt={poll.author.name} className="w-12 h-12 rounded-full object-cover border border-treasure" />
                      <div><span className="font-cinematic text-base font-bold text-treasure block">{poll.author.name}</span><span className="font-sans text-xs text-ocean-foam/70 italic block">Poll Architect</span></div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <span className="bg-wood text-treasure px-4 py-1.5 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase border border-treasure shadow-sm flex items-center">
                        <TrendingUp className="w-4 h-4 mr-1.5 text-treasure animate-pulse" /> {poll.totalVotes?.toLocaleString()} VOTES
                      </span>
                      <button onClick={() => { navigator.clipboard.writeText(window.location.origin + `/community/polls?slug=${poll.slug}`); setToastMessage("Poll link copied to clipboard!"); }} className="p-3 rounded-full bg-ocean-royal text-ocean-foam hover:text-treasure border border-transparent transition-all shadow-sm" title="Share Poll">
                        <Share2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-3xl font-cinematic font-bold text-treasure-light tracking-wide mb-3">{poll.question}</h3>
                    {poll.description && <p className="font-sans text-base text-ocean-foam/80 leading-relaxed font-medium">{poll.description}</p>}
                  </div>

                  {/* Options & Progress Bars */}
                  <div className="space-y-4 pt-4 border-t border-ocean-royal">
                    {poll.options.map((opt: any) => {
                      const isOptionVoted = votedPolls[poll.id] === opt.id;
                      return (
                        <div key={opt.id} onClick={() => handleVote(poll.id, opt.id)} className={cn("relative overflow-hidden rounded-2xl border-2 p-6 cursor-pointer transition-all duration-300 group", isOptionVoted ? "border-treasure bg-ocean-royal shadow-premium-gilded" : "border-ocean-royal bg-ocean-deep/80 hover:border-treasure-light")}>
                          {/* Percent Fill Background */}
                          <div className="absolute top-0 left-0 bottom-0 bg-ocean-royal/50 pointer-events-none transition-all duration-1000" style={{ width: `${hasVoted ? opt.percent : 0}%` }} />
                          <div className="relative z-10 flex items-center justify-between gap-4">
                            <span className={cn("font-cinematic text-xl font-bold tracking-wide flex items-center", isOptionVoted ? "text-treasure" : "text-ocean-foam group-hover:text-treasure")}>
                              {isOptionVoted && <CheckCircle2 className="w-5 h-5 mr-2 text-treasure flex-shrink-0" />} {opt.text}
                            </span>
                            {hasVoted && <span className="font-mono text-xl font-bold text-treasure bg-ocean-deep px-4 py-1.5 rounded-xl border border-treasure shadow-sm flex-shrink-0">{opt.percent}% ({opt.votes})</span>}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="flex items-center justify-between font-mono text-xs text-ocean-foam/60 pt-4 border-t border-ocean-royal">
                    <span>ANONYMOUS VOTING ARCHIVE</span>
                    <span>EXPIRATION TIMER: {new Date(poll.expiresAt).toLocaleDateString()}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
