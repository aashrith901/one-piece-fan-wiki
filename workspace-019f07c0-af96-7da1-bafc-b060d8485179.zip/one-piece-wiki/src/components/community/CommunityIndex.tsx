"use client";

import React, { useState, useEffect, useTransition } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, SearchInput, Select, Badge } from "@/components/ui/buttons";
import { SkeletonLoader, EmptyState } from "@/components/ui/feedback";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { Users, Flame, Calendar, Clock, Bookmark, Share2, MessageCircle, RefreshCw, Shield, Award, CheckCircle2, Lock, Unlock, MessageSquare, Pin, BarChart2, Star, Sparkles, ArrowRight } from "lucide-react";

// ============================================================================
// COMMUNITY HUB DASHBOARD CLIENT COMPONENT
// ============================================================================

export default function CommunityIndex() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [threadsList, setThreadsList] = useState<any[]>([]);
  const [pinnedThreads, setPinnedThreads] = useState<any[]>([]);
  const [stats, setStats] = useState<any>({ totalMembers: 48920, activeToday: 1420, totalThreads: 15420, totalComments: 189420 });
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    startTransition(async () => {
      try {
        const res = await fetch(`/api/community?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        if (data.success) {
          setThreadsList(data.data);
          if (data.pinned) setPinnedThreads(data.pinned);
          if (data.stats) setStats(data.stats);
        }
      } catch (err) {
        console.error("Community fetch error:", err);
      }
    });
  }, [query]);

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[50vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-treasure/20 via-ocean-deep to-ocean-royal pointer-events-none" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs items={[{ label: "Grand Line Wiki", href: "/" }, { label: "Community Hub" }]} />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <span className="inline-block bg-wood text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-sm mb-3">
                THE GRAND LINE FORUMS
              </span>
              <h1 className="text-5xl sm:text-6xl md:text-7xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
                PIRATE COMMUNITY FLEET
              </h1>
              <p className="text-xl font-sans text-ocean-foam/80 italic mt-1">
                Share theories, debate powerscaling matrices, and vote in live universal polls.
              </p>
            </div>
            <div className="flex flex-wrap gap-4 items-center">
              <Button variant="gilded" size="lg" onClick={() => (window.location.href = "/community/boards")} leftIcon={<MessageSquare className="w-5 h-5 text-ocean-deep" />}>
                OPEN DISCUSSION BOARDS
              </Button>
              <Button variant="royal" size="lg" onClick={() => (window.location.href = "/community/polls")} leftIcon={<BarChart2 className="w-5 h-5 text-treasure" />}>
                UNIVERSAL POLLS
              </Button>
              <Button variant="wooden" size="lg" onClick={() => (window.location.href = "/community/leaderboards")} leftIcon={<Award className="w-5 h-5 text-treasure" />}>
                LEADERBOARDS
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* COMMUNITY STATISTICS BANNER */}
      {/* ============================================================================ */}
      <div className="w-full bg-wooden-plank border-y-4 border-treasure py-8 select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
          <div><span className="text-xs font-cinematic font-bold text-treasure block uppercase tracking-widest mb-1">TOTAL FLEET ADMIRALS</span><span className="text-3xl sm:text-4xl font-mono font-bold text-paper">{stats.totalMembers.toLocaleString()}</span></div>
          <div><span className="text-xs font-cinematic font-bold text-treasure block uppercase tracking-widest mb-1">ACTIVE TODAY</span><span className="text-3xl sm:text-4xl font-mono font-bold text-emerald">{stats.activeToday.toLocaleString()}</span></div>
          <div><span className="text-xs font-cinematic font-bold text-treasure block uppercase tracking-widest mb-1">DISCUSSIONS & THEORIES</span><span className="text-3xl sm:text-4xl font-mono font-bold text-paper">{stats.totalThreads.toLocaleString()}</span></div>
          <div><span className="text-xs font-cinematic font-bold text-treasure block uppercase tracking-widest mb-1">DEN DEN MUSHI TRANSMISSIONS</span><span className="text-3xl sm:text-4xl font-mono font-bold text-paper">{stats.totalComments.toLocaleString()}</span></div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* 1. COMMUNITY ANNOUNCEMENTS (PINNED THREADS) */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none space-y-16">
        {pinnedThreads.length > 0 && (
          <div className="space-y-8">
            <div className="flex items-center space-x-3 border-b-2 border-border pb-3">
              <Pin className="w-6 h-6 text-sunset-crimson animate-bounce" />
              <h3 className="text-3xl font-cinematic font-bold text-foreground tracking-wide">PINNED GOVERNMENT ANNOUNCEMENTS</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {pinnedThreads.map((thread) => (
                <div
                  key={thread.id}
                  onClick={() => (window.location.href = `/community/boards/${thread.slug}`)}
                  className="bg-card border-4 border-treasure rounded-3xl p-8 shadow-premium-gilded cursor-pointer hover:border-treasure-light transition-all duration-300 flex flex-col justify-between group"
                >
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <span className="bg-ocean-deep text-treasure px-4 py-1.5 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase border border-treasure shadow-sm">
                        {thread.category}
                      </span>
                      <span className="font-mono text-xs text-muted-foreground">{new Date(thread.createdAt).toLocaleDateString()}</span>
                    </div>
                    <h4 className="text-2xl font-cinematic font-bold text-foreground group-hover:text-treasure-dark transition-colors tracking-wide mb-3">
                      {thread.title}
                    </h4>
                    <p className="font-sans text-base text-muted-foreground leading-relaxed line-clamp-3 font-medium">
                      {thread.content}
                    </p>
                  </div>
                  <div className="mt-8 pt-6 border-t border-border flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <img src={thread.author.image} alt={thread.author.name} className="w-10 h-10 rounded-full object-cover border border-treasure shadow-sm" />
                      <div>
                        <span className="font-cinematic text-sm font-bold text-foreground block">{thread.author.name}</span>
                        <span className="font-sans text-xs text-muted-foreground block">{thread.author.title} • Lv.{thread.author.level}</span>
                      </div>
                    </div>
                    <span className="flex items-center font-cinematic text-xs font-bold text-treasure bg-ocean-deep px-4 py-2 rounded-2xl border border-treasure shadow-sm">
                      <MessageCircle className="w-4 h-4 mr-1.5 text-treasure" /> {thread.repliesCount} REPLIES
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ============================================================================ */}
        {/* 2. TRENDING DISCUSSIONS & LATEST THEORIES */}
        {/* ============================================================================ */}
        <div className="space-y-8">
          <div className="flex items-center justify-between border-b-2 border-border pb-3">
            <div className="flex items-center space-x-3">
              <Flame className="w-6 h-6 text-sunset animate-bounce" />
              <h3 className="text-3xl font-cinematic font-bold text-foreground tracking-wide">TRENDING DEN DEN MUSHI CHATROOMS</h3>
            </div>
            <Button variant="ghost" size="sm" onClick={() => (window.location.href = "/community/boards")}>
              VIEW ALL 18 CATEGORIES →
            </Button>
          </div>

          {isPending && threadsList.length === 0 ? (
            <SkeletonLoader count={3} />
          ) : threadsList.length === 0 ? (
            <EmptyState title="NO DISCUSSIONS FOUND" message="No active chatrooms match your current parameters." />
          ) : (
            <div className="space-y-6">
              {threadsList.map((thread) => (
                <div
                  key={thread.id}
                  onClick={() => (window.location.href = `/community/boards/${thread.slug}`)}
                  className="bg-card border-2 border-border rounded-3xl p-8 shadow-paper-lift cursor-pointer hover:border-treasure transition-all duration-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 group"
                >
                  <div className="space-y-3 flex-grow">
                    <div className="flex items-center space-x-3">
                      <span className="bg-wood text-treasure px-3 py-1 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase border border-treasure shadow-sm">
                        {thread.category}
                      </span>
                      <span className="font-mono text-xs text-muted-foreground">{new Date(thread.createdAt).toLocaleDateString()}</span>
                    </div>
                    <h4 className="text-2xl font-cinematic font-bold text-foreground group-hover:text-treasure-dark transition-colors tracking-wide">
                      {thread.title}
                    </h4>
                    <p className="font-sans text-base text-muted-foreground leading-relaxed line-clamp-2 font-medium">
                      {thread.content}
                    </p>
                    <div className="flex flex-wrap gap-2 pt-2">
                      {thread.tags.map((tag: string, idx: number) => (
                        <span key={idx} className="text-[10px] font-mono bg-muted text-muted-foreground px-2 py-0.5 rounded-md border border-border">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-row md:flex-col items-center md:items-end justify-between w-full md:w-auto border-t md:border-t-0 md:border-l border-border pt-4 md:pt-0 md:pl-6 gap-4">
                    <div className="flex items-center space-x-3 md:space-x-0 md:flex-col md:items-end">
                      <img src={thread.author.image} alt={thread.author.name} className="w-10 h-10 rounded-full object-cover border border-treasure shadow-sm md:mb-1" />
                      <span className="font-cinematic text-sm font-bold text-foreground block md:text-right">{thread.author.name}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="flex items-center font-cinematic text-xs font-bold text-ocean-foam bg-ocean-deep px-3 py-1.5 rounded-xl border border-treasure shadow-sm">
                        👍 {thread.upvotes}
                      </span>
                      <span className="flex items-center font-cinematic text-xs font-bold text-treasure bg-ocean-deep px-3 py-1.5 rounded-xl border border-treasure shadow-sm">
                        <MessageCircle className="w-3.5 h-3.5 mr-1 text-treasure" /> {thread.repliesCount}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
