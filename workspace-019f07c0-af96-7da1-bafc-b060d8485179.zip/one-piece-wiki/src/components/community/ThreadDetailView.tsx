"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, Select } from "@/components/ui/buttons";
import { SkeletonLoader } from "@/components/ui/feedback";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { Calendar, Clock, Bookmark, Share2, MessageCircle, RefreshCw, ThumbsUp, ThumbsDown, MessageSquare, Flag, Trash2, Edit2, Sparkles, Smile } from "lucide-react";

// ============================================================================
// THREAD & FAN THEORY DETAIL VIEW CLIENT COMPONENT
// ============================================================================

export interface ThreadDetailViewProps {
  threadSlug?: string;
}

export default function ThreadDetailView({ threadSlug = "the-true-nature-of-the-one-piece-revealed" }: ThreadDetailViewProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [thread, setThread] = useState<any | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState("most_liked"); // newest, oldest, most_liked, most_relevant

  // Nested Comments Tree State
  const [commentsList, setCommentsList] = useState([
    {
      id: 1,
      author: "Monkey D. Luffy",
      avatar: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=400&auto=format&fit=crop",
      content: "SO COOL! So if the world gets pulled back up, does that mean we can explore the sunken ancient kingdom?! Set sail!",
      upvotes: 345,
      downvotes: 12,
      time: "2 hours ago",
      reactions: { "🔥": 45, "👑": 32, "⚓": 18 },
      replies: [
        {
          id: 101,
          author: "Nami",
          avatar: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=400&auto=format&fit=crop",
          content: "Luffy, think about the treasure! If an entire advanced kingdom rises up from the deep, there must be mountains of gold left behind!",
          upvotes: 189,
          downvotes: 2,
          time: "1 hour ago",
          reactions: { "💰": 52, "💎": 40 },
          replies: [],
        },
      ],
    },
    {
      id: 2,
      author: "Nico Robin",
      avatar: "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?q=80&w=400&auto=format&fit=crop",
      content: "This completely aligns with the Poneglyph inscriptions on Fish-Man Island regarding Joy Boy's apology. He couldn't operate the Noah because the energy levels weren't sufficient.",
      upvotes: 512,
      downvotes: 4,
      time: "3 hours ago",
      reactions: { "📖": 88, "🧠": 64 },
      replies: [],
    },
    {
      id: 3,
      author: "Sir Crocodile",
      avatar: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=400&auto=format&fit=crop",
      content: "If the continents rise, the entire real estate topography of the Grand Line changes. The Cross Guild will need to stake territorial claims immediately.",
      upvotes: 212,
      downvotes: 15,
      time: "5 hours ago",
      reactions: { "⚔️": 24 },
      replies: [],
    },
  ]);

  const [newCommentText, setNewCommentText] = useState("");
  const [replyingToId, setReplyingToId] = useState<number | null>(null);
  const [replyText, setReplyText] = useState("");

  useEffect(() => {
    fetch(`/api/community?slug=${encodeURIComponent(threadSlug)}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.success) setThread(data.data);
      })
      .catch((err) => console.error("Thread fetch error:", err));
  }, [threadSlug]);

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;
    const nextCom = {
      id: Date.now(),
      author: "Super Fan Admiral",
      avatar: "https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=400&auto=format&fit=crop",
      content: newCommentText.trim(),
      upvotes: 1,
      downvotes: 0,
      time: "Just now",
      reactions: { "🔥": 1 },
      replies: [],
    };
    setCommentsList([nextCom, ...commentsList]);
    setNewCommentText("");
    setToastMessage("Broadcasted your transponder snail comment to the community!");
  };

  const handleAddReply = (parentId: number, e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim()) return;
    const nextRep = {
      id: Date.now(),
      author: "Super Fan Admiral",
      avatar: "https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=400&auto=format&fit=crop",
      content: replyText.trim(),
      upvotes: 1,
      downvotes: 0,
      time: "Just now",
      reactions: { "👑": 1 },
      replies: [],
    };
    setCommentsList((prev) =>
      prev.map((c) => (c.id === parentId ? { ...c, replies: [...c.replies, nextRep] } : c))
    );
    setReplyText("");
    setReplyingToId(null);
    setToastMessage("Encrypted reply added to the transponder tree!");
  };

  const addReaction = (commentId: number, emoji: string) => {
    setCommentsList((prev) =>
      prev.map((c) => {
        if (c.id === commentId) {
          const rx = { ...c.reactions };
          rx[emoji] = (rx[emoji] || 0) + 1;
          return { ...c, reactions: rx };
        }
        return c;
      })
    );
    setToastMessage(`Reacted with ${emoji}!`);
  };

  if (!thread) {
    return <SkeletonLoader count={3} className="min-h-screen p-12 max-w-4xl mx-auto" />;
  }

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* Toast Notification Popup */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 bg-ocean-royal text-ocean-foam border-2 border-treasure p-6 rounded-2xl shadow-premium-ocean flex items-center space-x-4 max-w-sm"
          >
            <span className="font-sans text-sm font-medium">{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="text-xs text-treasure hover:underline">Close</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[50vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-treasure/20 via-ocean-deep to-ocean-royal pointer-events-none" />
        <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs
            items={[
              { label: "Grand Line Wiki", href: "/" },
              { label: "Community Hub", href: "/community/boards" },
              { label: thread.category },
            ]}
          />
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <span className="bg-wood text-treasure border border-treasure px-4 py-1.5 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase shadow-sm">
                {thread.category}
              </span>
              <span className="flex items-center text-xs font-mono text-ocean-foam/80">
                <Calendar className="w-3.5 h-3.5 mr-1.5 text-treasure" /> {new Date(thread.createdAt).toLocaleDateString()}
              </span>
              <span className="flex items-center text-xs font-mono text-ocean-foam/80">
                👁️ {thread.viewCount?.toLocaleString()} VIEWS
              </span>
            </div>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
              {thread.title}
            </h1>
            <div className="flex items-center justify-between border-t border-ocean-royal pt-6">
              <div className="flex items-center space-x-4">
                <img src={thread.author.image} alt={thread.author.name} className="w-12 h-12 rounded-full object-cover border-2 border-treasure shadow-sm" />
                <div>
                  <span className="font-cinematic text-base font-bold text-treasure block">{thread.author.name}</span>
                  <span className="font-sans text-xs text-ocean-foam/70 italic block">{thread.author.title} • Lv.{thread.author.level}</span>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => { thread.upvotes += 1; setToastMessage("Upvoted thread!"); }}
                  className="flex items-center space-x-2 p-3 rounded-full bg-ocean-royal text-ocean-foam hover:border-treasure border border-transparent transition-all shadow-sm font-cinematic font-bold text-xs"
                >
                  <ThumbsUp className="w-4 h-4 text-treasure" />
                  <span>{thread.upvotes}</span>
                </button>
                <button
                  onClick={() => { navigator.clipboard.writeText(window.location.href); setToastMessage("Thread link copied to clipboard!"); }}
                  className="p-3 rounded-full bg-ocean-royal text-ocean-foam hover:border-treasure border border-transparent transition-all shadow-sm"
                  title="Share Thread"
                >
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MAIN THREAD & THEORY BODY */}
      {/* ============================================================================ */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none space-y-16">
        <TreasureMapContainer className="space-y-8">
          <div className="font-sans text-lg text-foreground leading-relaxed space-y-6">
            <p>{thread.content}</p>
          </div>

          {/* Supporting Evidence Images for Fan Theories */}
          {thread.evidenceImages && thread.evidenceImages.length > 0 && (
            <div className="space-y-4 pt-6 border-t border-border">
              <h4 className="font-cinematic text-xl font-bold text-foreground">THEORY EVIDENCE IMAGES</h4>
              <div className="grid grid-cols-1 gap-6">
                {thread.evidenceImages.map((img: string, idx: number) => (
                  <div key={idx} className="relative w-full h-80 rounded-2xl overflow-hidden border-2 border-treasure bg-wood shadow-sm">
                    <img src={img} alt="Theory Evidence" className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex flex-wrap gap-2 pt-6 border-t border-border">
            {thread.tags?.map((tag: string, idx: number) => (
              <span key={idx} className="flex items-center text-xs font-mono bg-card text-foreground px-3 py-1.5 rounded-xl border border-border shadow-sm">
                #{tag}
              </span>
            ))}
          </div>
        </TreasureMapContainer>

        {/* ============================================================================ */}
        {/* COMMUNITY NESTED COMMENTS SECTION */}
        {/* ============================================================================ */}
        <div className="space-y-12">
          <div className="bg-wooden-plank border-4 border-treasure rounded-3xl p-8 sm:p-12 shadow-premium-ocean text-paper space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-treasure/30 pb-4 gap-4">
              <h4 className="text-3xl font-cinematic font-bold text-treasure flex items-center">
                <MessageSquare className="w-8 h-8 mr-3 text-treasure" /> DEN DEN MUSHI REPLIES ({commentsList.length})
              </h4>
              <div className="flex items-center space-x-2">
                <span className="font-cinematic text-xs font-bold text-paper/80 uppercase">SORT BY:</span>
                <Select
                  options={[
                    { label: "Most Liked", value: "most_liked" },
                    { label: "Newest First", value: "newest" },
                    { label: "Oldest First", value: "oldest" },
                    { label: "Most Relevant", value: "most_relevant" },
                  ]}
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-40 font-cinematic font-bold text-sm h-11"
                />
              </div>
            </div>

            {/* Submit Root Comment Form */}
            <form onSubmit={handleAddComment} className="space-y-4">
              <textarea
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                placeholder="Broadcast your reaction, counter-theory, or questions to the community..."
                rows={4}
                className="w-full rounded-2xl bg-ocean-deep border-2 border-treasure p-4 text-ocean-foam placeholder:text-ocean-foam/60 focus:outline-none focus:ring-2 focus:ring-treasure-light font-sans text-base shadow-inner"
              />
              <div className="flex justify-end">
                <Button variant="gilded" size="default" type="submit">
                  BROADCAST TRANSMISSION
                </Button>
              </div>
            </form>

            {/* Nested Comments Tree Listing */}
            <div className="space-y-8 pt-6 border-t border-treasure/20">
              {commentsList.map((com) => (
                <div key={com.id} className="bg-ocean-deep border-2 border-ocean-royal rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <img src={com.avatar} alt={com.author} className="w-12 h-12 rounded-full object-cover border-2 border-treasure shadow-sm" />
                      <div>
                        <span className="font-cinematic text-lg font-bold text-treasure block">{com.author}</span>
                        <span className="font-mono text-xs text-ocean-foam/60 block">{com.time}</span>
                      </div>
                    </div>
                    {/* Action Bar */}
                    <div className="flex items-center space-x-2">
                      <button onClick={() => { com.upvotes += 1; setToastMessage("Upvoted comment!"); }} className="flex items-center space-x-1 p-2 rounded-xl bg-ocean-royal text-ocean-foam hover:border-treasure border border-transparent transition-all shadow-sm font-mono text-xs">
                        <ThumbsUp className="w-4 h-4 text-treasure" /> <span>{com.upvotes}</span>
                      </button>
                      <button onClick={() => { com.downvotes += 1; setToastMessage("Downvoted comment."); }} className="flex items-center space-x-1 p-2 rounded-xl bg-ocean-royal text-ocean-foam hover:border-treasure border border-transparent transition-all shadow-sm font-mono text-xs">
                        <ThumbsDown className="w-4 h-4 text-destructive" /> <span>{com.downvotes}</span>
                      </button>
                      <button onClick={() => setToastMessage("Reported transponder snail transmission to Gorosei moderators.")} className="p-2 rounded-xl bg-ocean-royal text-ocean-foam hover:bg-sunset-crimson transition-colors" title="Report Comment">
                        <Flag className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <p className="font-sans text-base text-ocean-foam/90 leading-relaxed font-medium">{com.content}</p>

                  {/* Emoji Reactions Row */}
                  <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-ocean-royal">
                    <div className="flex flex-wrap gap-2">
                      {Object.entries(com.reactions).map(([em, cnt]) => (
                        <button key={em} onClick={() => addReaction(com.id, em)} className="px-3 py-1 rounded-xl bg-ocean-royal text-ocean-foam border border-ocean-light hover:border-treasure transition-all font-mono text-xs flex items-center space-x-1 shadow-sm">
                          <span>{em}</span> <span>{cnt}</span>
                        </button>
                      ))}
                      <button onClick={() => addReaction(com.id, "💎")} className="p-2 rounded-xl bg-ocean-royal text-ocean-foam border border-ocean-light hover:border-treasure transition-all text-xs flex items-center shadow-sm" title="Add Reaction">
                        <Smile className="w-4 h-4 text-treasure" />
                      </button>
                    </div>

                    <Button variant="ghost" size="sm" onClick={() => setReplyingToId(replyingToId === com.id ? null : com.id)} className="text-xs text-treasure hover:text-treasure-light">
                      {replyingToId === com.id ? "CANCEL REPLY" : "QUOTE REPLY ↩"}
                    </Button>
                  </div>

                  {/* Reply Form Container */}
                  <AnimatePresence>
                    {replyingToId === com.id && (
                      <motion.form initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} onSubmit={(e) => handleAddReply(com.id, e)} className="space-y-4 pt-4 border-t border-ocean-royal">
                        <textarea value={replyText} onChange={(e) => setReplyText(e.target.value)} placeholder={`Reply to Admiral ${com.author}...`} rows={3} className="w-full rounded-2xl bg-ocean-deep border-2 border-treasure p-4 text-ocean-foam placeholder:text-ocean-foam/60 focus:outline-none focus:ring-2 focus:ring-treasure font-sans text-sm shadow-inner" />
                        <div className="flex justify-end"><Button variant="gilded" size="sm" type="submit">BROADCAST ENCRYPTED REPLY</Button></div>
                      </motion.form>
                    )}
                  </AnimatePresence>

                  {/* Nested Replies Rendering */}
                  {com.replies.length > 0 && (
                    <div className="space-y-6 pt-6 border-t border-ocean-royal pl-6 sm:pl-12 border-l-4 border-treasure">
                      {com.replies.map((rep) => (
                        <div key={rep.id} className="bg-ocean-royal border border-ocean-light rounded-2xl p-6 shadow-sm space-y-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                              <img src={rep.avatar} alt={rep.author} className="w-10 h-10 rounded-full object-cover border border-treasure shadow-sm" />
                              <div><span className="font-cinematic text-base font-bold text-treasure block">{rep.author}</span><span className="font-mono text-xs text-ocean-foam/60 block">{rep.time}</span></div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <button onClick={() => { rep.upvotes += 1; setToastMessage("Upvoted reply!"); }} className="flex items-center space-x-1 p-2 rounded-xl bg-ocean-deep text-ocean-foam hover:border-treasure border border-transparent transition-all shadow-sm font-mono text-xs">
                                <ThumbsUp className="w-3.5 h-3.5 text-treasure" /> <span>{rep.upvotes}</span>
                              </button>
                            </div>
                          </div>
                          <p className="font-sans text-sm text-ocean-foam/90 leading-relaxed font-medium">{rep.content}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
