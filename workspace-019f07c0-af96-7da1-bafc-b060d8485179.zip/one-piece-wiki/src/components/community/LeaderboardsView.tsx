"use client";

import React, { useState, useEffect, useTransition } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/buttons";
import { Tabs, Table } from "@/components/ui/navigation-ui";
import { StatCard } from "@/components/ui/cards";
import { SkeletonLoader } from "@/components/ui/feedback";
import { RopeBorder, TreasureMapContainer, WoodenPanel, CoinParticles } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { Award, Flame, Shield, TrendingUp, Users, Trophy, Star, Crown } from "lucide-react";

// ============================================================================
// COMMUNITY LEADERBOARDS CLIENT COMPONENT
// ============================================================================

export default function LeaderboardsView() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [leaderboards, setLeaderboards] = useState<any>({ topContributors: [], mostHelpful: [], theoryMasters: [] });
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    startTransition(async () => {
      try {
        const res = await fetch("/api/community?type=leaderboards");
        const data = await res.json();
        if (data.success) {
          setLeaderboards(data.data);
        }
      } catch (err) {
        console.error("Leaderboards fetch error:", err);
      }
    });
  }, []);

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[45vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-treasure/20 via-ocean-deep to-ocean-royal pointer-events-none" />
        <CoinParticles count={25} />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs items={[{ label: "Grand Line Wiki", href: "/" }, { label: "Community Hub", href: "/community/boards" }, { label: "Leaderboards" }]} />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <span className="inline-block bg-wood text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-sm mb-3">
                HALL OF SUPREME KINGS
              </span>
              <h1 className="text-5xl sm:text-6xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
                COMMUNITY FLEET LEADERBOARDS
              </h1>
              <p className="text-lg font-sans text-ocean-foam/80 italic mt-1">Track XP progression, daily streaks, and supreme reputation levels across the Four Seas.</p>
            </div>
            <div>
              <Button variant="gilded" size="lg" onClick={() => (window.location.href = "/profile/luffy_emperor")} leftIcon={<Trophy className="w-5 h-5 text-ocean-deep" />}>
                VIEW MY STATS & RANK
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* LEADERBOARD TABS */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <Tabs
          items={[
            {
              id: "top_contributors",
              label: "TOP CONTRIBUTORS",
              content: (
                <div className="space-y-16">
                  <SectionHeader title="THE EMPERORS OF LORE" subtitle="Highest All-Time Contribution Score" />
                  <Table
                    columns={[
                      { header: "Rank", accessor: (row) => <span className="font-mono text-2xl font-bold text-treasure bg-ocean-deep px-4 py-2 rounded-2xl border border-treasure flex items-center w-fit"><Crown className="w-5 h-5 mr-1.5 text-treasure animate-pulse" /> #{row.rank}</span>, className: "w-32" },
                      { header: "Admiral Alias", accessor: (row) => (
                        <div className="flex items-center space-x-4">
                          <img src={row.image} alt={row.name} className="w-12 h-12 rounded-full object-cover border-2 border-treasure shadow-sm" />
                          <div><span className="font-cinematic text-xl font-bold text-foreground block">{row.name}</span><span className="font-sans text-xs text-muted-foreground block">Trophy Badge: {row.badge}</span></div>
                        </div>
                      ) },
                      { header: "Daily Streak", accessor: (row) => <span className="font-mono text-base font-bold text-sunset bg-card px-4 py-1.5 rounded-xl border border-border shadow-sm">{row.streak}</span>, className: "w-40" },
                      { header: "Reputation Level", accessor: (row) => <span className="font-cinematic text-lg font-bold text-treasure bg-ocean-deep px-4 py-1.5 rounded-xl border border-treasure shadow-sm">Lv.{row.level} ({row.reputation} Rep)</span>, className: "text-right w-48" },
                    ]}
                    data={leaderboards.topContributors}
                  />
                </div>
              ),
            },
            {
              id: "theory_masters",
              label: "THEORY MASTERS",
              content: (
                <div className="space-y-16">
                  <SectionHeader title="SCHOLARS OF OHARA" subtitle="Most Upvoted Fan Theory Engineers" />
                  <Table
                    columns={[
                      { header: "Rank", accessor: (row) => <span className="font-mono text-2xl font-bold text-treasure bg-ocean-deep px-4 py-2 rounded-2xl border border-treasure flex items-center w-fit"><Crown className="w-5 h-5 mr-1.5 text-treasure animate-pulse" /> #{row.rank}</span>, className: "w-32" },
                      { header: "Scholar Alias", accessor: (row) => (
                        <div className="flex items-center space-x-4">
                          <img src={row.image} alt={row.name} className="w-12 h-12 rounded-full object-cover border-2 border-treasure shadow-sm" />
                          <div><span className="font-cinematic text-xl font-bold text-foreground block">{row.name}</span><span className="font-sans text-xs text-muted-foreground block">Trophy Badge: {row.badge}</span></div>
                        </div>
                      ) },
                      { header: "Daily Streak", accessor: (row) => <span className="font-mono text-base font-bold text-sunset bg-card px-4 py-1.5 rounded-xl border border-border shadow-sm">{row.streak}</span>, className: "w-40" },
                      { header: "Reputation Level", accessor: (row) => <span className="font-cinematic text-lg font-bold text-treasure bg-ocean-deep px-4 py-1.5 rounded-xl border border-treasure shadow-sm">Lv.{row.level} ({row.reputation} Rep)</span>, className: "text-right w-48" },
                    ]}
                    data={leaderboards.theoryMasters}
                  />
                </div>
              ),
            },
            {
              id: "most_helpful",
              label: "MOST HELPFUL ADMIRALS",
              content: (
                <div className="space-y-16">
                  <SectionHeader title="THE MIRACLE DOCTORS" subtitle="Top Reviewers & Commenters" />
                  <Table
                    columns={[
                      { header: "Rank", accessor: (row) => <span className="font-mono text-2xl font-bold text-treasure bg-ocean-deep px-4 py-2 rounded-2xl border border-treasure flex items-center w-fit"><Crown className="w-5 h-5 mr-1.5 text-treasure animate-pulse" /> #{row.rank}</span>, className: "w-32" },
                      { header: "Doctor Alias", accessor: (row) => (
                        <div className="flex items-center space-x-4">
                          <img src={row.image} alt={row.name} className="w-12 h-12 rounded-full object-cover border-2 border-treasure shadow-sm" />
                          <div><span className="font-cinematic text-xl font-bold text-foreground block">{row.name}</span><span className="font-sans text-xs text-muted-foreground block">Trophy Badge: {row.badge}</span></div>
                        </div>
                      ) },
                      { header: "Daily Streak", accessor: (row) => <span className="font-mono text-base font-bold text-sunset bg-card px-4 py-1.5 rounded-xl border border-border shadow-sm">{row.streak}</span>, className: "w-40" },
                      { header: "Reputation Level", accessor: (row) => <span className="font-cinematic text-lg font-bold text-treasure bg-ocean-deep px-4 py-1.5 rounded-xl border border-treasure shadow-sm">Lv.{row.level} ({row.reputation} Rep)</span>, className: "text-right w-48" },
                    ]}
                    data={leaderboards.mostHelpful}
                  />
                </div>
              ),
            },
          ]}
        />
      </div>

      <Footer />
    </div>
  );
}
