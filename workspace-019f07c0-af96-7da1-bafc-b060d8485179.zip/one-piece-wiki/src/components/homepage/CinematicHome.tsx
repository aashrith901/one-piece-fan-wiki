"use client";

import React, { useState } from "react";
import dynamic from "next/dynamic";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

// Module 2 UI and Design System Imports
import { Button } from "@/components/ui/buttons";
import { CharacterCard, IslandCard, DevilFruitCard, NewsCard, QuoteCard, FactCard, StatCard } from "@/components/ui/cards";
import { Carousel } from "@/components/ui/navigation-ui";
import { LoadingScreen } from "@/components/ui/feedback";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel, CoinParticles } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, SectionHeader, AnimatedCompass } from "@/components/navigation/navigation-system";
import { FadeReveal, SlideReveal, ScaleReveal, ParallaxScroll } from "@/components/animations/motion";

// Lucide Icons
import { Flame, Compass, BookOpen, Film, Award, Shield, Sparkles, AlertCircle, Anchor } from "lucide-react";

// Dynamically import the Three.js Ocean Hero canvas with no SSR for perfect client rendering
const OceanHero = dynamic(() => import("@/components/three/OceanHero"), {
  ssr: false,
  loading: () => <LoadingScreen text="Initializing 3D Grand Line Simulation..." className="min-h-[70vh]" />,
});

export default function CinematicHome() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      {/* Premium Global Navigation */}
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* ============================================================================ */}
      {/* 1. STUNNING HERO SECTION WITH THREE.JS ANIMATED OCEAN & SHIP */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[90vh] flex items-center justify-center bg-ocean-deep overflow-hidden">
        {/* 3D Canvas Background */}
        <OceanHero />

        {/* Hero Overlay Content */}
        <div className="relative z-10 max-w-6xl mx-auto px-6 py-24 text-center space-y-8 pointer-events-auto select-none mt-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="flex justify-center"
          >
            <AnimatedCompass size="lg" />
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl sm:text-6xl md:text-8xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight drop-shadow-2xl"
          >
            THE ULTIMATE FAN ENCYCLOPEDIA
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg sm:text-2xl font-sans text-ocean-foam/90 max-w-3xl mx-auto leading-relaxed drop-shadow-md font-medium"
          >
            Set sail across 1,100+ manga chapters, explore legendary pirate fleets, analyze awakened devil fruits, and craft custom high-fidelity bounty posters.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-6"
          >
            <Button variant="gilded" size="lg" onClick={() => (window.location.href = "/characters")} className="w-full sm:w-auto text-lg font-bold">
              EXPLORE THE ENCYCLOPEDIA
            </Button>
            <Button variant="royal" size="lg" onClick={() => (window.location.href = "/bounties/generator")} leftIcon={<Flame className="w-6 h-6 text-sunset animate-bounce" />} className="w-full sm:w-auto text-lg font-bold">
              CANVA BOUNTY STUDIO
            </Button>
          </motion.div>
        </div>
        <div className="absolute bottom-0 inset-x-0 h-32 bg-gradient-to-t from-background via-background/50 to-transparent pointer-events-none z-10" />
      </div>

      {/* ============================================================================ */}
      {/* 2. DAILY LORE & INSPIRATION (QUOTE & FACT) */}
      {/* ============================================================================ */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10 -mt-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <SlideReveal direction="left">
            <QuoteCard
              quote="Inherited Will, The Destiny of Age, and The Dreams of People. As long as people continue to pursue the meaning of Freedom, these things will never cease to be!"
              author="Gol D. Roger"
              context="The Pirate King's Last Words before the Great Pirate Era"
            />
          </SlideReveal>
          <SlideReveal direction="right">
            <TreasureMapContainer className="h-full flex flex-col justify-center">
              <FactCard
                title="DAILY ONE PIECE FACT: THE TRUE SCALE OF THE RED LINE"
                fact="The Red Line is a massive ring of continent stretching all the way around the world, extending 10,000 meters below the sea to Fish-Man Island and reaching thousands of meters high into the clouds, making it completely impassable except by Reverse Mountain or Mary Geoise."
              />
            </TreasureMapContainer>
          </SlideReveal>
        </div>
      </section>

      {/* Wave Break */}
      <WaveSeparator />

      {/* ============================================================================ */}
      {/* 3. FEATURED LEGENDARY CHARACTER */}
      {/* ============================================================================ */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 select-none">
        <SectionHeader title="FEATURED LEGEND OF THE SEAS" subtitle="Emperor of the New World" />
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mt-12">
          <div className="lg:col-span-5 flex justify-center">
            <ScaleReveal>
              <CharacterCard
                name="Monkey D. Luffy"
                epithet="Straw Hat / Sun God Nika"
                image="https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=800&auto=format&fit=crop"
                bounty="3,000,000,000"
                faction="yonko"
                stats={{ power: 98, speed: 95, haki: 96 }}
                onClick={() => (window.location.href = "/characters/monkey-d-luffy")}
                className="max-w-md w-full"
              />
            </ScaleReveal>
          </div>
          <div className="lg:col-span-7 space-y-8">
            <FadeReveal>
              <div className="space-y-4">
                <span className="inline-block bg-sunset-crimson text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-glowing-bounty">
                  GEAR 5 AWAKENED
                </span>
                <h3 className="text-4xl sm:text-5xl font-cinematic font-bold text-foreground tracking-wide">
                  MONKEY D. LUFFY
                </h3>
                <p className="text-lg font-sans text-muted-foreground leading-relaxed font-medium">
                  The captain of the increasingly infamous Straw Hat Pirates and one of the Four Emperors of the New World. Having awakened the legendary Hito Hito no Mi, Model: Nika, Luffy brings the liberating drums of liberation across the Grand Line, fighting for absolute freedom and the ultimate treasure, the One Piece.
                </p>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-6 pt-6 border-t border-border mt-8">
                <div>
                  <h5 className="font-cinematic text-xs text-muted-foreground uppercase font-bold">DEVIL FRUIT</h5>
                  <p className="font-cinematic text-xl font-bold text-treasure mt-1">Hito Hito no Mi: Nika</p>
                </div>
                <div>
                  <h5 className="font-cinematic text-xs text-muted-foreground uppercase font-bold">HAKI MASTERY</h5>
                  <p className="font-cinematic text-xl font-bold text-sunset mt-1">Advanced Supreme King</p>
                </div>
                <div>
                  <h5 className="font-cinematic text-xs text-muted-foreground uppercase font-bold">ORIGIN</h5>
                  <p className="font-cinematic text-xl font-bold text-foreground mt-1">Foosha Village</p>
                </div>
              </div>
              <div className="pt-8">
                <Button variant="wooden" size="lg" onClick={() => (window.location.href = "/characters/monkey-d-luffy")} leftIcon={<Shield className="w-5 h-5 text-treasure" />}>
                  VIEW FULL LORE BIOME
                </Button>
              </div>
            </FadeReveal>
          </div>
        </div>
      </section>

      {/* Anchor Divider */}
      <AnchorDecoration />

      {/* ============================================================================ */}
      {/* 4. LATEST RELEASES: MANGA CHAPTER & ANIME EPISODE */}
      {/* ============================================================================ */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 select-none">
        <SectionHeader title="CHRONICLE OF THE NEW WORLD" subtitle="Latest Chapters & Episodes" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mt-12">
          {/* Latest Manga Chapter */}
          <SlideReveal direction="left">
            <div className="relative overflow-hidden rounded-3xl border-4 border-border bg-parchment p-8 sm:p-12 shadow-paper-lift group hover:border-treasure transition-all duration-500 flex flex-col justify-between h-full">
              <div>
                <div className="flex items-center justify-between mb-8">
                  <span className="flex items-center text-xs font-cinematic font-bold text-treasure bg-ocean-deep px-4 py-2 rounded-full border border-treasure shadow-sm">
                    <BookOpen className="w-4 h-4 mr-2 text-treasure" /> LATEST MANGA CHAPTER
                  </span>
                  <span className="text-sm font-mono font-bold text-muted-foreground">JUNE 2026</span>
                </div>
                <h3 className="text-4xl font-cinematic font-bold text-foreground group-hover:text-treasure-dark transition-colors mb-4">
                  CHAPTER 1120: "THE INHERITED DESTINY"
                </h3>
                <p className="text-base font-sans text-muted-foreground leading-relaxed mb-8 font-medium">
                  As the Buster Call encompasses the shores of Egghead Island, the Iron Giant rises to full stature, resonating with the Liberation Drums of Gear 5. The Five Elders make their ultimate move to suppress the worldwide broadcast of Dr. Vegapunk.
                </p>
              </div>
              <div className="border-t-2 border-border pt-6 flex items-center justify-between">
                <Button variant="gilded" size="default" onClick={() => (window.location.href = "/chapters/1120")}>
                  READ DISCUSSIONS
                </Button>
                <span className="font-cinematic text-sm font-bold text-treasure-dark">948+ COMMENTS</span>
              </div>
            </div>
          </SlideReveal>

          {/* Latest Anime Episode */}
          <SlideReveal direction="right">
            <div className="relative overflow-hidden rounded-3xl border-4 border-treasure bg-ocean-deep p-8 sm:p-12 shadow-premium-ocean group hover:border-treasure-light transition-all duration-500 flex flex-col justify-between h-full text-ocean-foam">
              <div>
                <div className="flex items-center justify-between mb-8">
                  <span className="flex items-center text-xs font-cinematic font-bold text-ocean-foam bg-ocean-royal px-4 py-2 rounded-full border border-ocean-foam shadow-sm">
                    <Film className="w-4 h-4 mr-2 text-sunset" /> LATEST ANIME EPISODE
                  </span>
                  <span className="text-sm font-mono font-bold text-ocean-foam/60">JUNE 2026</span>
                </div>
                <h3 className="text-4xl font-cinematic font-bold text-treasure group-hover:text-treasure-light transition-colors mb-4">
                  EPISODE 1112: "CLASH OF EMPERORS! SHANKS VS. KID"
                </h3>
                <p className="text-base font-sans text-ocean-foam/80 leading-relaxed mb-8 font-medium">
                  Off the coast of Elbaf, the Red Hair Pirates confront the Kid Pirates. Witnessing a catastrophic future through advanced observation haki, Shanks unleashes the legendary Divine Departure (Kamusari) to obliterate the enemy fleet!
                </p>
              </div>
              <div className="border-t-2 border-ocean-royal pt-6 flex items-center justify-between">
                <Button variant="royal" size="default" onClick={() => (window.location.href = "/episodes/1112")}>
                  RATE EPISODE
                </Button>
                <span className="font-cinematic text-sm font-bold text-treasure">RATING: 9.9/10</span>
              </div>
            </div>
          </SlideReveal>
        </div>
      </section>

      {/* ============================================================================ */}
      {/* 5. TRENDING ARCS CAROUSEL */}
      {/* ============================================================================ */}
      <section className="w-full bg-wooden-plank border-y-4 border-treasure py-24 select-none my-12 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader title="TRENDING GRAND LINE ARCS" subtitle="Relive the Greatest Adventures" className="text-paper" />
          <div className="mt-12">
            <Carousel className="h-[500px]">
              {[
                { title: "EGGHEAD ISLAND ARC", subtitle: "The Future Island & The Buster Call", img: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=1200&auto=format&fit=crop" },
                { title: "WANO COUNTRY ARC", subtitle: "Land of Samurai & The Raid on Onigashima", img: "https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=1200&auto=format&fit=crop" },
                { title: "MARINEFORD ARC", subtitle: "The Summit War of the Paramount Age", img: "https://images.unsplash.com/photo-1505118380757-91f5f563b031?q=80&w=1200&auto=format&fit=crop" },
                { title: "ENIES LOBBY ARC", subtitle: "Declaration of War against the World Government", img: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?q=80&w=1200&auto=format&fit=crop" },
              ].map((arc, idx) => (
                <div key={idx} className="relative w-full h-[500px] rounded-3xl overflow-hidden border-2 border-treasure bg-ocean-deep group cursor-pointer">
                  <img src={arc.img} alt={arc.title} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-gradient-to-t from-ocean-deep via-ocean-deep/60 to-transparent opacity-90" />
                  <div className="absolute inset-0 p-12 flex flex-col justify-end max-w-3xl">
                    <span className="font-cinematic text-sm font-bold text-sunset mb-2 tracking-widest uppercase">{arc.subtitle}</span>
                    <h3 className="text-4xl sm:text-5xl font-cinematic font-bold text-treasure mb-6 tracking-wide">{arc.title}</h3>
                    <Button variant="gilded" size="default" onClick={() => (window.location.href = "/episodes")} className="w-fit">
                      EXPLORE ARC ARCHIVE
                    </Button>
                  </div>
                </div>
              ))}
            </Carousel>
          </div>
        </div>
      </section>

      {/* ============================================================================ */}
      {/* 6. POPULAR DEVIL FRUITS GRID */}
      {/* ============================================================================ */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 select-none">
        <SectionHeader title="LEGENDARY CURSED FRUITS" subtitle="Most Investigated Devil Fruits" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
          <ScaleReveal delay={0.1}>
            <DevilFruitCard
              name="Ope Ope no Mi"
              meaning="Surgery / Ultimate Operation"
              type="Paramecia"
              isAwakened={true}
              onClick={() => (window.location.href = "/devil-fruits/ope-ope-no-mi")}
            />
          </ScaleReveal>
          <ScaleReveal delay={0.2}>
            <DevilFruitCard
              name="Goro Goro no Mi"
              meaning="Thunder / Lightning"
              type="Logia"
              isAwakened={false}
              onClick={() => (window.location.href = "/devil-fruits/goro-goro-no-mi")}
            />
          </ScaleReveal>
          <ScaleReveal delay={0.3}>
            <DevilFruitCard
              name="Uwo Uwo no Mi: Seiryu"
              meaning="Azure Dragon"
              type="Mythical Zoan"
              isAwakened={true}
              onClick={() => (window.location.href = "/devil-fruits/uwo-uwo-no-mi-seiryu")}
            />
          </ScaleReveal>
        </div>
      </section>

      {/* Rope Divider */}
      <RopeBorder />

      {/* ============================================================================ */}
      {/* 7. BREAKING NEWS & EDITORIALS */}
      {/* ============================================================================ */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 select-none">
        <SectionHeader title="NEWS COO EXPRESS" subtitle="Hot Off the Grand Line Presses" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
          <FadeReveal delay={0.1}>
            <NewsCard
              title="VEGAPUNK'S WORLDWIDE BROADCAST ENTERS CLIMAX"
              excerpt="The shocking truth regarding the Void Century and the rising sea levels threatens to plunge the World Government into absolute chaos as citizens across the globe tune in."
              category="Manga Lore"
              date="JUNE 25, 2026"
              image="https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=600&auto=format&fit=crop"
              onClick={() => (window.location.href = "/news/vegapunk-broadcast-climax")}
            />
          </FadeReveal>
          <FadeReveal delay={0.2}>
            <NewsCard
              title="CROSS GUILD ISSUES 4 BILLION BELI BOUNTY ON MARINE ADMIRAL"
              excerpt="Sir Crocodile and Dracule Mihawk intensify operations under Buggy the Genius Jester, turning the tables on Marine Admirals with unprecedented public bounty ledgers."
              category="Platform Bounty"
              date="JUNE 22, 2026"
              image="https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?q=80&w=600&auto=format&fit=crop"
              onClick={() => (window.location.href = "/news/cross-guild-admiral-bounty")}
            />
          </FadeReveal>
          <FadeReveal delay={0.3}>
            <NewsCard
              title="THE ONE PIECE FAN WIKI INTEGRATES CANVA BOUNTY STUDIO"
              excerpt="Fans can now craft ultra-high-fidelity bounty posters with layer drag-and-drop, custom rotation, ancient paper textures, and full SVG/PDF export support."
              category="Platform Update"
              date="JUNE 18, 2026"
              image="https://images.unsplash.com/photo-1579783902614-a3fb3927b675?q=80&w=600&auto=format&fit=crop"
              onClick={() => (window.location.href = "/bounties/generator")}
            />
          </FadeReveal>
        </div>
      </section>

      {/* ============================================================================ */}
      {/* 8. INTERACTIVE STATISTICS LEDGER */}
      {/* ============================================================================ */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 select-none">
        <div className="relative w-full rounded-3xl border-4 border-treasure bg-ocean-deep p-12 shadow-premium-ocean overflow-hidden">
          <CoinParticles count={20} />
          <div className="relative z-10">
            <h3 className="text-4xl font-cinematic font-bold text-treasure text-center tracking-wider mb-12">
              THE PLATFORM IN NUMBERS
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              <StatCard label="Tracked Characters" value={1348} suffix="+" icon={<Shield className="w-6 h-6" />} progress={95} />
              <StatCard label="Pirate Fleets & Crews" value={142} icon={<Anchor className="w-6 h-6" />} progress={88} />
              <StatCard label="Active Community Admirals" value={48920} suffix="+" icon={<Award className="w-6 h-6" />} progress={92} />
              <StatCard label="Highest Active Bounty" value={5564800000} prefix="฿ " icon={<Flame className="w-6 h-6 text-sunset" />} progress={100} />
            </div>
          </div>
        </div>
      </section>

      {/* Premium Epic Footer */}
      <Footer />
    </div>
  );
}
