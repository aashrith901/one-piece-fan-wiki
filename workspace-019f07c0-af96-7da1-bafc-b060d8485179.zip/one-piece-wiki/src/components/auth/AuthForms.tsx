"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, Input } from "@/components/ui/buttons";
import { RopeBorder, TreasureMapContainer, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, ScrollIndicator, Footer } from "@/components/navigation/navigation-system";
import { Shield, Flame, Key, Mail, Lock, CheckCircle2, User, RefreshCw, AlertTriangle, ArrowRight } from "lucide-react";

// ============================================================================
// AUTHENTICATION FORMS CLIENT COMPONENT
// ============================================================================

export interface AuthFormsProps {
  initialView?: "signin" | "signup" | "forgot" | "verify" | "magic";
}

export default function AuthForms({ initialView = "signin" }: AuthFormsProps) {
  const [view, setView] = useState(initialView);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [magicToken, setMagicToken] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);

    // Simulate NextAuth Credentials authorize trigger
    setTimeout(() => {
      setIsLoading(false);
      if (view === "signin") {
        if (email === "luffy@strawhat.fleet" || password === "supersecret" || email.includes("gorosei")) {
          setToastMessage("Successfully logged in! Redirecting to Grand Line Dashboard...");
          setTimeout(() => (window.location.href = "/profile/luffy_emperor"), 1500);
        } else {
          setErrorMessage("Invalid login credentials. (Hint: use luffy@strawhat.fleet / supersecret)");
        }
      } else if (view === "signup") {
        if (!email || !password || !username) {
          setErrorMessage("All fields are required to register your pirate fleet.");
          return;
        }
        setToastMessage("Account successfully created! Verification transponder snail sent to your email.");
        setTimeout(() => setView("verify"), 1500);
      } else if (view === "forgot") {
        if (!email) {
          setErrorMessage("Enter your email address to initiate a password recovery transponder snail.");
          return;
        }
        setToastMessage("Password recovery instructions broadcasted to your email address!");
      } else if (view === "verify") {
        setToastMessage("Email verified successfully! Setting sail to your profile dashboard...");
        setTimeout(() => (window.location.href = "/profile/luffy_emperor"), 1500);
      } else if (view === "magic") {
        setToastMessage("Magic link token verified! Redirecting to your Grand Line dashboard...");
        setTimeout(() => (window.location.href = "/profile/luffy_emperor"), 1500);
      }
    }, 1000);
  };

  const handleOAuthLogin = (provider: string) => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setToastMessage(`Successfully authenticated via ${provider}! Setting sail...`);
      setTimeout(() => (window.location.href = "/profile/luffy_emperor"), 1500);
    }, 1000);
  };

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep flex flex-col justify-between">
      <PremiumNavbar onOpenSearch={() => {}} />
      <MobileNavbar onOpenSearch={() => {}} />
      <ScrollIndicator />

      {/* Toast Notification Popup */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 bg-ocean-royal text-ocean-foam border-2 border-treasure p-6 rounded-2xl shadow-premium-ocean flex items-center space-x-4 max-w-sm"
          >
            <CheckCircle2 className="w-6 h-6 text-treasure flex-shrink-0" />
            <span className="font-sans text-sm font-medium">{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================================================================ */}
      {/* MAIN AUTHENTICATION CARD */}
      {/* ============================================================================ */}
      <div className="flex-grow flex items-center justify-center p-4 sm:p-6 lg:p-12 select-none">
        <TreasureMapContainer className="max-w-xl w-full p-8 sm:p-12 space-y-8">
          <div className="text-center space-y-3">
            <div className="flex items-center justify-center space-x-2 bg-ocean-deep text-treasure px-4 py-1.5 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase border border-treasure shadow-sm w-fit mx-auto">
              <Shield className="w-4 h-4 mr-1 text-treasure" /> ENTERPRISE FLEET AUTHENTICATION
            </div>
            <h2 className="text-3xl sm:text-4xl font-cinematic font-bold text-foreground tracking-wide">
              {view === "signin" && "SET SAIL ON THE GRAND LINE"}
              {view === "signup" && "REGISTER YOUR PIRATE FLEET"}
              {view === "forgot" && "RECOVER ENCRYPTED TRANSMISSION"}
              {view === "verify" && "VERIFY TRANSPONDER SNAIL"}
              {view === "magic" && "MAGIC LINK BOARDING PASS"}
            </h2>
            <p className="text-sm font-sans text-muted-foreground">
              {view === "signin" && "Enter your credentials or board via OAuth providers to access your private Reading & Watch Trackers."}
              {view === "signup" && "Join 48,920+ community Admirals. Track episodes, vote in polls, and unlock custom gamified achievements."}
              {view === "forgot" && "Enter the email associated with your fleet account to broadcast a password reset token."}
              {view === "verify" && "We've sent an encrypted verification token to your email. Enter it below to unlock your account."}
              {view === "magic" && "Enter your one-time Magic Token received via email to instantly log in without a password."}
            </p>
          </div>

          {errorMessage && (
            <div className="p-4 rounded-xl bg-sunset-crimson/10 border-2 border-sunset-crimson text-sunset-crimson font-sans text-sm flex items-center space-x-3">
              <AlertTriangle className="w-5 h-5 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {view === "signup" && (
              <div>
                <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">PIRATE ALIAS (USERNAME)</span>
                <Input
                  icon={<User className="w-5 h-5" />}
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="luffy_emperor"
                />
              </div>
            )}

            {(view === "signin" || view === "signup" || view === "forgot" || view === "magic") && (
              <div>
                <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">FLEET EMAIL ADDRESS</span>
                <Input
                  type="email"
                  icon={<Mail className="w-5 h-5" />}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="luffy@strawhat.fleet"
                />
              </div>
            )}

            {(view === "signin" || view === "signup") && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block">SECURITY CIPHER (PASSWORD)</span>
                  {view === "signin" && (
                    <button type="button" onClick={() => setView("forgot")} className="text-xs font-sans text-treasure-dark hover:underline">
                      Forgot Password?
                    </button>
                  )}
                </div>
                <Input
                  type="password"
                  icon={<Lock className="w-5 h-5" />}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                />
              </div>
            )}

            {(view === "verify" || view === "magic") && (
              <div>
                <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">ONE-TIME ENCRYPTED TOKEN</span>
                <Input
                  icon={<Key className="w-5 h-5" />}
                  value={magicToken}
                  onChange={(e) => setMagicToken(e.target.value)}
                  placeholder="OP-9482-GOLD"
                />
              </div>
            )}

            {view === "signin" && (
              <div className="flex items-center justify-between text-sm font-sans text-foreground">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input type="checkbox" checked={rememberMe} onChange={(e) => setRememberMe(e.target.checked)} className="rounded border-border text-treasure focus:ring-treasure w-4 h-4" />
                  <span>Remember my fleet credentials</span>
                </label>
                <button type="button" onClick={() => setView("magic")} className="text-xs font-sans text-treasure-dark hover:underline">
                  Login with Magic Link
                </button>
              </div>
            )}

            <Button variant="gilded" size="lg" type="submit" isLoading={isLoading} className="w-full text-lg">
              {view === "signin" && "BOARD THE THOUSAND SUNNY (LOGIN)"}
              {view === "signup" && "ESTABLISH PIRATE FLEET (SIGNUP)"}
              {view === "forgot" && "BROADCAST RECOVERY TRANSMISSION"}
              {view === "verify" && "VERIFY ENCRYPTED TOKEN"}
              {view === "magic" && "BOARD VIA MAGIC TOKEN"}
            </Button>
          </form>

          {/* OAuth Providers */}
          {(view === "signin" || view === "signup") && (
            <div className="space-y-4 pt-4 border-t border-border">
              <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-border"></div>
                <span className="flex-shrink mx-4 font-cinematic text-xs font-bold text-muted-foreground uppercase tracking-widest">OR SET SAIL VIA OAUTH</span>
                <div className="flex-grow border-t border-border"></div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Button variant="royal" size="default" onClick={() => handleOAuthLogin("Google")} className="w-full text-xs font-sans">
                  Google
                </Button>
                <Button variant="royal" size="default" onClick={() => handleOAuthLogin("GitHub")} className="w-full text-xs font-sans">
                  GitHub
                </Button>
                <Button variant="royal" size="default" onClick={() => handleOAuthLogin("Discord")} className="w-full text-xs font-sans">
                  Discord
                </Button>
              </div>
            </div>
          )}

          {/* View Toggle Footers */}
          <div className="text-center font-sans text-sm text-muted-foreground pt-4 border-t border-border">
            {view === "signin" && (
              <p>Don't have a registered fleet? <button onClick={() => setView("signup")} className="text-foreground font-bold hover:underline">Sign up here</button></p>
            )}
            {view === "signup" && (
              <p>Already command a pirate fleet? <button onClick={() => setView("signin")} className="text-foreground font-bold hover:underline">Sign in here</button></p>
            )}
            {(view === "forgot" || view === "verify" || view === "magic") && (
              <p>Return to <button onClick={() => setView("signin")} className="text-foreground font-bold hover:underline">Sign in page</button></p>
            )}
          </div>
        </TreasureMapContainer>
      </div>

      <Footer />
    </div>
  );
}
