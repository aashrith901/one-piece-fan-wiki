"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, Input, Select } from "@/components/ui/buttons";
import { Tabs, Dialog } from "@/components/ui/navigation-ui";
import { SkeletonLoader } from "@/components/ui/feedback";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { User, Lock, Bell, Eye, Palette, Accessibility, Trash2, CheckCircle2, Shield, AlertTriangle, RefreshCw, Key } from "lucide-react";

// ============================================================================
// USER SETTINGS DASHBOARD CLIENT COMPONENT
// ============================================================================

export interface UserSettingsViewProps {
  username?: string;
}

export default function UserSettingsView({ username = "luffy_emperor" }: UserSettingsViewProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  // Form States
  const [bio, setBio] = useState("The future Pirate King! I love eating meat and taking down corrupt World Government officials. Set sail on the Thousand Sunny!");
  const [avatarUrl, setAvatarUrl] = useState("https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=400&auto=format&fit=crop");
  const [bannerUrl, setBannerUrl] = useState("https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=1200&auto=format&fit=crop");
  const [factionAllegiance, setFactionAllegiance] = useState("Pirates");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");

  // Toggles
  const [twoFactorAuth, setTwoFactorAuth] = useState(true);
  const [notifEpisodes, setNotifEpisodes] = useState(true);
  const [notifManga, setNotifManga] = useState(true);
  const [notifAchievements, setNotifAchievements] = useState(true);
  const [isPublicProfile, setIsPublicProfile] = useState(true);
  const [theme, setTheme] = useState("dark");
  const [language, setLanguage] = useState("en-US");
  const [highContrast, setHighContrast] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const res = await fetch("/api/user/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, bio, avatarUrl, bannerUrl, factionAllegiance }),
      });
      const data = await res.json();
      setIsLoading(false);
      if (data.success) {
        setToastMessage("Profile settings successfully synchronized with Drizzle ORM store!");
      } else {
        setToastMessage(`Error updating profile: ${data.error}`);
      }
    } catch (err) {
      setIsLoading(false);
      setToastMessage("Network error during profile synchronization.");
    }
  };

  const handleSaveSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setToastMessage("Security credentials and session configurations successfully encrypted!");
      setCurrentPassword("");
      setNewPassword("");
    }, 1000);
  };

  const handleDeleteAccount = () => {
    setToastMessage("Account deletion initiated. Buster Call flag triggered on your user data.");
    setIsDeleteModalOpen(false);
    setTimeout(() => (window.location.href = "/auth/signin"), 2000);
  };

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* Toast Notification Popup */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 bg-ocean-royal text-ocean-foam border-2 border-treasure p-6 rounded-2xl shadow-premium-ocean flex items-center space-x-4 max-w-sm"
          >
            <CheckCircle2 className="w-6 h-6 text-treasure flex-shrink-0" />
            <span className="font-sans text-sm font-medium">{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="text-xs text-treasure hover:underline">Close</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delete Account Modal */}
      <Dialog isOpen={isDeleteModalOpen} onClose={() => setIsDeleteModalOpen(false)} title="BUSTER CALL ON YOUR ACCOUNT?">
        <div className="space-y-6">
          <div className="p-4 rounded-xl bg-sunset-crimson/10 border-2 border-sunset-crimson text-sunset-crimson flex items-center space-x-4">
            <AlertTriangle className="w-8 h-8 flex-shrink-0" />
            <span className="font-sans text-sm font-bold">This action is irreversible. All bookmarks, reading history, watch trackers, and gamified achievements will be permanently obliterated.</span>
          </div>
          <p className="font-sans text-base text-foreground">Are you absolutely sure you wish to dissolve your pirate fleet and abandon the Grand Line?</p>
          <div className="flex items-center justify-end space-x-4 pt-4 border-t border-border">
            <Button variant="ghost" size="default" onClick={() => setIsDeleteModalOpen(false)}>CANCEL</Button>
            <Button variant="crimson" size="default" onClick={handleDeleteAccount}>CONFIRM OBLITERATION</Button>
          </div>
        </div>
      </Dialog>

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[40vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-treasure/20 via-ocean-deep to-ocean-royal pointer-events-none" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs items={[{ label: "Grand Line Wiki", href: "/" }, { label: "Profiles", href: `/profile/${username}` }, { label: "Settings" }]} />
          <div>
            <span className="inline-block bg-wood text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-sm mb-3">
              ACCOUNT MANAGER
            </span>
            <h1 className="text-5xl sm:text-6xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
              ADMIRAL FLEET CONFIGURATION
            </h1>
            <p className="text-lg font-sans text-ocean-foam/80 italic mt-1">Configure security ciphers, connected OAuth providers, and global notification flags.</p>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MAIN SETTINGS TABS */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <Tabs
          items={[
            {
              id: "profile",
              label: "PROFILE SETTINGS",
              content: (
                <form onSubmit={handleSaveProfile} className="space-y-12">
                  <TreasureMapContainer className="space-y-8">
                    <h3 className="text-3xl font-cinematic font-bold text-foreground flex items-center border-b border-border pb-4">
                      <User className="w-8 h-8 mr-3 text-treasure" /> EDIT DOSSIER & ASSETS
                    </h3>
                    <div>
                      <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">PIRATE ALIAS (CANNOT BE EDITED)</span>
                      <Input value={username} disabled className="bg-muted text-muted-foreground" />
                    </div>
                    <div>
                      <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">ADMIRAL BIO & MANIFEST</span>
                      <textarea
                        value={bio}
                        onChange={(e) => setBio(e.target.value)}
                        rows={4}
                        className="w-full rounded-xl bg-input border border-border p-4 text-foreground focus:outline-none focus:ring-2 focus:ring-treasure font-sans text-base shadow-sm"
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div>
                        <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">AVATAR URL</span>
                        <Input value={avatarUrl} onChange={(e) => setAvatarUrl(e.target.value)} />
                      </div>
                      <div>
                        <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">BANNER IMAGE URL</span>
                        <Input value={bannerUrl} onChange={(e) => setBannerUrl(e.target.value)} />
                      </div>
                    </div>
                    <div>
                      <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">FACTION ALLEGIANCE</span>
                      <Select
                        options={[
                          { label: "Pirate Crews", value: "Pirates" },
                          { label: "Marine Headquarters", value: "Marines" },
                          { label: "Revolutionary Army", value: "Revolutionaries" },
                          { label: "Cross Guild", value: "Cross Guild" },
                          { label: "Independent / Bounty Hunter", value: "Independent" },
                        ]}
                        value={factionAllegiance}
                        onChange={(e) => setFactionAllegiance(e.target.value)}
                        className="font-cinematic font-bold text-lg h-14"
                      />
                    </div>
                    <div className="flex justify-end border-t border-border pt-6">
                      <Button variant="gilded" size="lg" type="submit" isLoading={isLoading}>
                        SAVE DOSSIER CONFIGURATION
                      </Button>
                    </div>
                  </TreasureMapContainer>
                </form>
              ),
            },
            {
              id: "security",
              label: "SECURITY & SESSIONS",
              content: (
                <form onSubmit={handleSaveSecurity} className="space-y-12">
                  <TreasureMapContainer className="space-y-8">
                    <h3 className="text-3xl font-cinematic font-bold text-foreground flex items-center border-b border-border pb-4">
                      <Lock className="w-8 h-8 mr-3 text-treasure" /> SECURITY CIPHERS & AUTHENTICATION
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div>
                        <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">CURRENT CIPHER (PASSWORD)</span>
                        <Input type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} placeholder="••••••••••••" />
                      </div>
                      <div>
                        <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">NEW SECURITY CIPHER</span>
                        <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="••••••••••••" />
                      </div>
                    </div>
                    <div className="flex items-center justify-between p-6 bg-card border border-border rounded-2xl">
                      <div>
                        <h5 className="font-cinematic text-xl font-bold text-foreground flex items-center">
                          <Shield className="w-5 h-5 mr-2 text-treasure" /> TWO-FACTOR AUTHENTICATION (2FA)
                        </h5>
                        <p className="font-sans text-xs text-muted-foreground mt-1">Require an encrypted magic token transponder snail on every new login attempt.</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" checked={twoFactorAuth} onChange={(e) => setTwoFactorAuth(e.target.checked)} className="sr-only peer" />
                        <div className="w-11 h-6 bg-muted peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-paper after:border-border after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-treasure"></div>
                      </label>
                    </div>

                    {/* Connected OAuth Accounts */}
                    <div className="space-y-4 pt-6 border-t border-border">
                      <h4 className="font-cinematic text-xl font-bold text-foreground">CONNECTED OAUTH PROVIDERS</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                        <div className="p-6 bg-ocean-deep text-ocean-foam border border-treasure rounded-2xl flex items-center justify-between shadow-sm">
                          <div><span className="font-cinematic font-bold block">Google</span><span className="font-sans text-xs text-emerald block">Connected</span></div>
                          <Button variant="ghost" size="sm" onClick={() => setToastMessage("Google OAuth Disconnected.")} className="text-xs text-ocean-foam">DISCONNECT</Button>
                        </div>
                        <div className="p-6 bg-ocean-deep text-ocean-foam border border-treasure rounded-2xl flex items-center justify-between shadow-sm">
                          <div><span className="font-cinematic font-bold block">GitHub</span><span className="font-sans text-xs text-emerald block">Connected</span></div>
                          <Button variant="ghost" size="sm" onClick={() => setToastMessage("GitHub OAuth Disconnected.")} className="text-xs text-ocean-foam">DISCONNECT</Button>
                        </div>
                        <div className="p-6 bg-ocean-deep text-ocean-foam border border-ocean-royal rounded-2xl flex items-center justify-between shadow-sm">
                          <div><span className="font-cinematic font-bold block">Discord</span><span className="font-sans text-xs text-muted-foreground block">Not Connected</span></div>
                          <Button variant="gilded" size="sm" onClick={() => setToastMessage("Connected Discord OAuth!")} className="text-xs">CONNECT</Button>
                        </div>
                      </div>
                    </div>

                    {/* Active Sessions Manager */}
                    <div className="space-y-4 pt-6 border-t border-border">
                      <h4 className="font-cinematic text-xl font-bold text-foreground">ACTIVE SESSION MANAGER</h4>
                      <div className="p-6 bg-card border border-border rounded-2xl flex items-center justify-between">
                        <div>
                          <span className="font-cinematic text-lg font-bold text-foreground block">Mac OS • Chrome browser</span>
                          <span className="font-mono text-xs text-muted-foreground block">IP: 192.168.1.1 • Active Now</span>
                        </div>
                        <Button variant="crimson" size="sm" onClick={() => setToastMessage("Revoked active session token.")}>REVOKE SESSION</Button>
                      </div>
                    </div>

                    <div className="flex justify-end border-t border-border pt-6">
                      <Button variant="gilded" size="lg" type="submit" isLoading={isLoading}>
                        ENCRYPT SECURITY CREDENTIALS
                      </Button>
                    </div>
                  </TreasureMapContainer>
                </form>
              ),
            },
            {
              id: "notifications",
              label: "NOTIFICATION FLAGS",
              content: (
                <TreasureMapContainer className="space-y-8">
                  <h3 className="text-3xl font-cinematic font-bold text-foreground flex items-center border-b border-border pb-4">
                    <Bell className="w-8 h-8 mr-3 text-treasure" /> TRANSPONDER SNAIL BROADCAST FLAGS
                  </h3>
                  <div className="space-y-6">
                    {[
                      { title: "New Anime Episode Releases", desc: "Instantly broadcast a notification when a new episode drops on Toei feeds.", state: notifEpisodes, setter: setNotifEpisodes },
                      { title: "Manga Chapter Drops", desc: "Receive alerts when a new chapter summary or full scan releases.", state: notifManga, setter: setNotifManga },
                      { title: "Gamified Achievement Unlocks", desc: "Celebrate when your reading or watch milestones unlock a new trophy badge.", state: notifAchievements, setter: setNotifAchievements },
                    ].map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between p-6 bg-card border border-border rounded-2xl">
                        <div>
                          <h5 className="font-cinematic text-xl font-bold text-foreground">{item.title}</h5>
                          <p className="font-sans text-xs text-muted-foreground mt-1">{item.desc}</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" checked={item.state} onChange={(e) => item.setter(e.target.checked)} className="sr-only peer" />
                          <div className="w-11 h-6 bg-muted peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-paper after:border-border after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-treasure"></div>
                        </label>
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-end border-t border-border pt-6">
                    <Button variant="gilded" size="lg" onClick={() => setToastMessage("Notification flags successfully saved!")}>
                      SAVE NOTIFICATION FLAGS
                    </Button>
                  </div>
                </TreasureMapContainer>
              ),
            },
            {
              id: "privacy",
              label: "PRIVACY & THEME",
              content: (
                <TreasureMapContainer className="space-y-8">
                  <h3 className="text-3xl font-cinematic font-bold text-foreground flex items-center border-b border-border pb-4">
                    <Eye className="w-8 h-8 mr-3 text-treasure" /> PRIVACY & ASSET SETTINGS
                  </h3>
                  <div className="flex items-center justify-between p-6 bg-card border border-border rounded-2xl">
                    <div>
                      <h5 className="font-cinematic text-xl font-bold text-foreground">PUBLIC LORE ARCHIVE</h5>
                      <p className="font-sans text-xs text-muted-foreground mt-1">Allow other community Admirals to view your achievements, favorites, and activity log.</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" checked={isPublicProfile} onChange={(e) => setIsPublicProfile(e.target.checked)} className="sr-only peer" />
                      <div className="w-11 h-6 bg-muted peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-paper after:border-border after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-treasure"></div>
                    </label>
                  </div>

                  {/* Theme & Language Selectors */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6 border-t border-border">
                    <div>
                      <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">INTERFACE LIGHTING (THEME)</span>
                      <Select
                        options={[
                          { label: "Pirate Gold Dark Mode", value: "dark" },
                          { label: "Ancient Parchment Light Mode", value: "light" },
                        ]}
                        value={theme}
                        onChange={(e) => { setTheme(e.target.value); document.documentElement.classList.toggle("dark", e.target.value === "dark"); }}
                        className="font-cinematic font-bold text-lg h-14"
                      />
                    </div>
                    <div>
                      <span className="font-cinematic text-xs font-bold text-foreground uppercase tracking-wider block mb-1">PLATFORM LANGUAGE</span>
                      <Select
                        options={[
                          { label: "English (US)", value: "en-US" },
                          { label: "Japanese (日本語)", value: "ja-JP" },
                        ]}
                        value={language}
                        onChange={(e) => setLanguage(e.target.value)}
                        className="font-cinematic font-bold text-lg h-14"
                      />
                    </div>
                  </div>

                  {/* Accessibility Selectors */}
                  <div className="space-y-6 pt-6 border-t border-border">
                    <h4 className="font-cinematic text-xl font-bold text-foreground flex items-center">
                      <Accessibility className="w-6 h-6 mr-2 text-treasure" /> ACCESSIBILITY COMPLIANCE
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="flex items-center justify-between p-6 bg-card border border-border rounded-2xl">
                        <div><h5 className="font-cinematic text-base font-bold text-foreground">High Contrast Mode</h5><p className="font-sans text-xs text-muted-foreground mt-1">Enhance border readability.</p></div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" checked={highContrast} onChange={(e) => setHighContrast(e.target.checked)} className="sr-only peer" />
                          <div className="w-11 h-6 bg-muted peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-paper after:border-border after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-treasure"></div>
                        </label>
                      </div>
                      <div className="flex items-center justify-between p-6 bg-card border border-border rounded-2xl">
                        <div><h5 className="font-cinematic text-base font-bold text-foreground">Reduced Motion</h5><p className="font-sans text-xs text-muted-foreground mt-1">Downgrade heavy 3D animations.</p></div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" checked={reducedMotion} onChange={(e) => setReducedMotion(e.target.checked)} className="sr-only peer" />
                          <div className="w-11 h-6 bg-muted peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-paper after:border-border after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-treasure"></div>
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end border-t border-border pt-6">
                    <Button variant="gilded" size="lg" onClick={() => setToastMessage("Privacy and accessibility settings saved!")}>
                      SAVE PRIVACY CONFIGURATION
                    </Button>
                  </div>
                </TreasureMapContainer>
              ),
            },
            {
              id: "delete",
              label: "DELETE ACCOUNT",
              content: (
                <TreasureMapContainer className="space-y-8 border-destructive">
                  <h3 className="text-3xl font-cinematic font-bold text-destructive flex items-center border-b border-border pb-4">
                    <Trash2 className="w-8 h-8 mr-3 text-destructive" /> ACCOUNT DISSOLUTION (BUSTER CALL)
                  </h3>
                  <p className="font-sans text-base text-foreground leading-relaxed">
                    Permanently obliterate your user profile, active sessions, private bookmarks, and gamified achievements from the Grand Line servers. This action cannot be undone.
                  </p>
                  <div className="flex justify-end border-t border-border pt-6">
                    <Button variant="crimson" size="lg" onClick={() => setIsDeleteModalOpen(true)}>
                      INITIATE BUSTER CALL (DELETE ACCOUNT)
                    </Button>
                  </div>
                </TreasureMapContainer>
              ),
            },
          ]}
        />
      </div>

      <Footer />
    </div>
  );
}
