"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, Badge } from "@/components/ui/buttons";
import { Tabs, Table, Timeline } from "@/components/ui/navigation-ui";
import { SkeletonLoader } from "@/components/ui/feedback";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { User, Flame, Calendar, Clock, Bookmark, Share2, MessageCircle, RefreshCw, Shield, Award, CheckCircle2, Lock, Unlock, Users, BookOpen, Film } from "lucide-react";

// ============================================================================
// USER PROFILE DASHBOARD CLIENT COMPONENT
// ============================================================================

export interface UserProfileViewProps {
  username?: string;
}

export default function UserProfileView({ username = "luffy_emperor" }: UserProfileViewProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [profile, setProfile] = useState<any | null>(null);
  const [isFollowing, setIsFollowing] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    fetch(`/api/user/profile?username=${encodeURIComponent(username)}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.success) setProfile(data.data);
      })
      .catch((err) => console.error("Profile fetch error:", err));
  }, [username]);

  if (!profile) {
    return <SkeletonLoader count={3} className="min-h-screen p-12 max-w-5xl mx-auto" />;
  }

  const toggleFollow = () => {
    setIsFollowing(!isFollowing);
    if (!isFollowing) {
      profile.followersCount += 1;
      setToastMessage(`You are now following Admiral ${profile.username}!`);
    } else {
      profile.followersCount -= 1;
      setToastMessage(`Unfollowed Admiral ${profile.username}.`);
    }
  };

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* Toast Notification Popup */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 bg-ocean-royal text-ocean-foam border-2 border-treasure p-6 rounded-2xl shadow-premium-ocean flex items-center space-x-4 max-w-sm"
          >
            <CheckCircle2 className="w-6 h-6 text-treasure flex-shrink-0" />
            <span className="font-sans text-sm font-medium">{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="text-xs text-treasure hover:underline">Close</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION (BANNER & AVATAR) */}
      {/* ============================================================================ */}
      <div className="relative w-full h-[50vh] bg-ocean-deep overflow-hidden select-none">
        <img src={profile.bannerUrl} alt="Profile Banner" className="absolute inset-0 w-full h-full object-cover opacity-60 object-center" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
        <div className="absolute top-24 left-4 sm:left-8 z-10">
          <Breadcrumbs items={[{ label: "Grand Line Wiki", href: "/" }, { label: "Community Admirals" }, { label: profile.username }]} className="bg-ocean-deep/80 px-4 py-2 rounded-2xl border border-treasure shadow-sm" />
        </div>
      </div>

      {/* Profile Info Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 -mt-28 select-none mb-16">
        <div className="bg-card border-4 border-border rounded-3xl p-8 shadow-paper-lift flex flex-col md:flex-row items-center md:items-end justify-between gap-8 text-center md:text-left">
          <div className="flex flex-col md:flex-row items-center md:items-end space-y-4 md:space-y-0 md:space-x-8">
            {/* Avatar */}
            <div className="w-40 h-40 rounded-full overflow-hidden border-4 border-treasure bg-ocean-deep flex-shrink-0 shadow-premium-ocean -mt-24 md:-mt-32 relative z-20">
              <img src={profile.avatarUrl} alt={profile.username} className="w-full h-full object-cover" />
            </div>
            <div>
              <div className="flex items-center justify-center md:justify-start space-x-3 mb-2">
                <Badge variant="pirate">{profile.factionAllegiance} Faction</Badge>
                <span className="bg-ocean-deep text-treasure px-3 py-1 rounded-full text-xs font-cinematic font-bold border border-treasure shadow-sm">
                  Reputation: {profile.reputationScore}
                </span>
                <span className="flex items-center text-xs font-mono text-muted-foreground">
                  {profile.isPublic ? <Unlock className="w-3.5 h-3.5 mr-1 text-emerald-dark" /> : <Lock className="w-3.5 h-3.5 mr-1 text-destructive" />}
                  {profile.isPublic ? "PUBLIC ARCHIVE" : "PRIVATE ARCHIVE"}
                </span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-cinematic font-bold text-foreground tracking-wide">
                {profile.username}
              </h1>
              <p className="text-lg font-cinematic text-treasure-dark italic mt-1">~ {profile.title} ~</p>
            </div>
          </div>

          {/* Follow, Share & Settings Buttons */}
          <div className="flex flex-wrap gap-4 justify-center">
            <Button variant={isFollowing ? "wooden" : "gilded"} size="default" onClick={toggleFollow}>
              {isFollowing ? "FLEET FOLLOWED" : "FOLLOW ADMIRAL"}
            </Button>
            <Button variant="royal" size="default" onClick={() => (window.location.href = `/profile/${profile.username}/tracker`)} leftIcon={<BookOpen className="w-4 h-4 text-treasure" />}>
              OPEN TRACKER
            </Button>
            <Button variant="ghost" size="default" onClick={() => (window.location.href = `/profile/${profile.username}/settings`)}>
              SETTINGS
            </Button>
            <button
              onClick={() => { navigator.clipboard.writeText(window.location.href); setToastMessage("Profile link copied to clipboard!"); }}
              className="p-3 rounded-xl bg-ocean-royal text-ocean-foam hover:border-treasure border border-transparent transition-all shadow-sm"
              title="Share Profile"
            >
              <Share2 className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Bio & Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
          <div className="md:col-span-2 bg-parchment border-2 border-border rounded-3xl p-8 shadow-paper-lift">
            <h4 className="font-cinematic text-xl font-bold text-foreground mb-3 flex items-center border-b border-border pb-2">
              <User className="w-5 h-5 mr-2 text-treasure" /> ADMIRAL BIO & MANIFEST
            </h4>
            <p className="font-sans text-base text-muted-foreground leading-relaxed font-medium">
              {profile.bio}
            </p>
            <div className="mt-6 pt-4 border-t border-border flex items-center space-x-6 font-mono text-xs text-muted-foreground">
              <span className="flex items-center"><Calendar className="w-4 h-4 mr-1.5 text-treasure" /> Set Sail: {new Date(profile.joinDate).toLocaleDateString("en-US", { month: "short", year: "numeric" })}</span>
              <span className="flex items-center"><Users className="w-4 h-4 mr-1.5 text-treasure" /> Followers: {profile.followersCount}</span>
              <span className="flex items-center"><Users className="w-4 h-4 mr-1.5 text-treasure" /> Following: {profile.followingCount}</span>
            </div>
          </div>

          {/* Trackers Quick Summary */}
          <div className="bg-ocean-deep text-ocean-foam border-4 border-treasure rounded-3xl p-8 shadow-premium-ocean space-y-6">
            <h4 className="font-cinematic text-xl font-bold text-treasure flex items-center border-b border-ocean-royal pb-2">
              <Film className="w-5 h-5 mr-2 text-sunset" /> TRACKER PROGRESSION
            </h4>
            <div className="space-y-4 font-sans text-sm">
              <div>
                <div className="flex justify-between mb-1 font-mono text-xs">
                  <span>ANIME WATCH PROGRESS</span>
                  <span className="text-treasure font-bold">{profile.trackers.watching.completionPercentage}% ({profile.trackers.watching.totalWatched} Eps)</span>
                </div>
                <div className="w-full h-2 bg-ocean-royal rounded-full overflow-hidden border border-treasure/30">
                  <div className="h-full bg-sunset transition-all duration-500" style={{ width: `${profile.trackers.watching.completionPercentage}%` }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1 font-mono text-xs">
                  <span>MANGA READ PROGRESS</span>
                  <span className="text-treasure font-bold">{profile.trackers.reading.completionPercentage}% ({profile.trackers.reading.totalRead} Chs)</span>
                </div>
                <div className="w-full h-2 bg-ocean-royal rounded-full overflow-hidden border border-treasure/30">
                  <div className="h-full bg-treasure transition-all duration-500" style={{ width: `${profile.trackers.reading.completionPercentage}%` }} />
                </div>
              </div>
            </div>
            <Button variant="gilded" size="sm" onClick={() => (window.location.href = `/profile/${profile.username}/tracker`)} className="w-full text-xs">
              LAUNCH SYNCED TRACKER DASHBOARD
            </Button>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MAIN PROFILE TABS (FAVORITES, ACHIEVEMENTS, ACTIVITY FEED, BOOKMARKS) */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 select-none">
        <Tabs
          items={[
            {
              id: "favorites",
              label: "HALL OF FAVORITES",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="CURATED LORE VAULT" subtitle="The Admiral's Handpicked Treasures" />
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                    {Object.entries(profile.favorites).map(([key, fav]: [string, any]) => (
                      <div
                        key={key}
                        onClick={() => (window.location.href = `/${key === "devilFruit" ? "devil-fruits" : key + "s"}/${fav.slug}`)}
                        className="cursor-pointer overflow-hidden rounded-2xl border-2 border-ocean-royal bg-ocean-deep shadow-premium-ocean transition-all duration-300 hover:border-treasure hover:translate-y-[-4px] group flex flex-col justify-between"
                      >
                        <div className="relative h-56 w-full overflow-hidden bg-wood">
                          <img src={fav.image} alt={fav.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                          <div className="absolute inset-0 bg-gradient-to-t from-ocean-deep via-transparent to-transparent opacity-80" />
                          <span className="absolute top-4 left-4 bg-wood text-treasure border border-treasure px-3 py-1 rounded-full text-xs font-cinematic font-bold tracking-wider uppercase shadow-sm">
                            FAVORITE {key.toUpperCase()}
                          </span>
                        </div>
                        <div className="p-6 flex flex-col flex-grow justify-between">
                          <h4 className="text-2xl font-cinematic font-bold text-ocean-foam group-hover:text-treasure transition-colors tracking-wide">
                            {fav.name}
                          </h4>
                          <span className="mt-4 border-t border-ocean-royal pt-4 text-xs text-treasure font-cinematic font-bold tracking-wider uppercase block">
                            EXPLORE LORE BIOME →
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ),
            },
            {
              id: "achievements",
              label: "HALL OF ACHIEVEMENTS",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="GAMIFIED TROPHY ROOM" subtitle="Automatically Unlocked Platform Milestones" />
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {profile.achievements.map((ach: any) => (
                      <div key={ach.id} className="bg-wooden-plank border-2 border-treasure rounded-2xl p-6 shadow-premium-ocean text-paper flex flex-col justify-between hover:border-treasure-light transition-colors group">
                        <div>
                          <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">{ach.icon}</div>
                          <h4 className="text-xl font-cinematic font-bold text-treasure mb-2">{ach.title}</h4>
                          <p className="text-xs font-sans text-paper/80 leading-relaxed font-medium">{ach.desc}</p>
                        </div>
                        <div className="mt-6 border-t border-treasure/30 pt-4 flex items-center justify-between text-[10px] font-mono text-paper/60">
                          <span>UNLOCKED</span>
                          <span>{ach.unlockedAt}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ),
            },
            {
              id: "activity",
              label: "ACTIVITY FEED",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="RECENT TRANSMISSIONS" subtitle="Global Platform Engagement Log" />
                  <div className="max-w-4xl mx-auto space-y-6">
                    {profile.activityFeed.map((act: any) => (
                      <div key={act.id} className="bg-card border-2 border-border rounded-2xl p-6 shadow-paper-lift flex items-center justify-between gap-6 hover:border-treasure transition-colors">
                        <div className="flex items-center space-x-4">
                          <div className="text-2xl p-3 bg-ocean-deep rounded-2xl border border-treasure shadow-sm flex-shrink-0">{act.icon}</div>
                          <div>
                            <span className="font-cinematic text-lg font-bold text-foreground block">{act.action}</span>
                            <span className="font-sans text-sm text-muted-foreground block">{act.target}</span>
                          </div>
                        </div>
                        <span className="font-mono text-xs text-muted-foreground whitespace-nowrap">{act.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ),
            },
            {
              id: "bookmarks",
              label: "PRIVATE BOOKMARKS",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="PRIVATE READING VAULT" subtitle="Exclusively Encrypted Bookmarks" />
                  <Table
                    columns={[
                      { header: "Entity Title", accessor: "title", className: "font-cinematic text-xl font-bold text-foreground" },
                      { header: "Lore Classification", accessor: (row) => <span className="font-cinematic text-xs font-bold text-treasure bg-ocean-deep px-3 py-1 rounded-full border border-treasure uppercase">{row.type}</span>, className: "w-32" },
                      { header: "Time Saved", accessor: (row) => <span className="font-mono text-sm text-muted-foreground">{new Date(row.addedAt).toLocaleDateString()}</span>, className: "w-40" },
                      { header: "Navigation", accessor: (row) => <Button variant="gilded" size="sm" onClick={() => (window.location.href = `/${row.type === "manga" ? "chapters" : row.type === "news" ? "news" : "devil-fruits"}/${row.slug}`)}>BOARD ENTITY</Button>, className: "text-right w-36" },
                    ]}
                    data={profile.bookmarks}
                  />
                </div>
              ),
            },
          ]}
        />
      </div>

      <Footer />
    </div>
  );
}
