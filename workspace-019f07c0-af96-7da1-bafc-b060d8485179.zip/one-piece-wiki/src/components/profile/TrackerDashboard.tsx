"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, Select } from "@/components/ui/buttons";
import { Tabs, Table, Timeline } from "@/components/ui/navigation-ui";
import { StatCard, FactCard } from "@/components/ui/cards";
import { SkeletonLoader } from "@/components/ui/feedback";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel, CoinParticles } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { BookOpen, Film, Award, CheckCircle2, RefreshCw, Sparkles, TrendingUp, Calendar, ArrowRight } from "lucide-react";

// ============================================================================
// WATCH & READING TRACKER DASHBOARD CLIENT COMPONENT
// ============================================================================

export interface TrackerDashboardProps {
  username?: string;
}

export default function TrackerDashboard({ username = "luffy_emperor" }: TrackerDashboardProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Tracker Progress States
  const [watchedEpisodes, setWatchedEpisodes] = useState([
    { id: 1112, title: "Clash of Emperors! Shanks vs. Kid", arc: "Egghead Arc", watchedDate: "June 21, 2026", rating: 10, status: "Completed" },
    { id: 1111, title: "The Second Pillar! The Prime Ambition!", arc: "Egghead Arc", watchedDate: "June 14, 2026", rating: 9, status: "Completed" },
    { id: 1110, title: "Surviving the Buster Call!", arc: "Egghead Arc", watchedDate: "June 07, 2026", rating: 10, status: "Completed" },
  ]);

  const [readChapters, setReadChapters] = useState([
    { id: 1120, title: "The Inherited Destiny", volume: 110, readDate: "June 25, 2026", rating: 10, status: "Completed" },
    { id: 1119, title: "The Iron Giant Awakes", volume: 110, readDate: "June 18, 2026", rating: 10, status: "Completed" },
    { id: 1118, title: "Drums of Liberation Echo", volume: 110, readDate: "June 11, 2026", rating: 9, status: "Completed" },
  ]);

  const [achievementsList, setAchievementsList] = useState([
    { id: 1, title: "First Login", desc: "Successfully set sail on the platform.", icon: "⚓", unlocked: true, date: "Jan 15, 2024" },
    { id: 2, title: "Explorer", desc: "Navigated 50 distinct lore entity pages.", icon: "🧭", unlocked: true, date: "Feb 10, 2024" },
    { id: 3, title: "Grand Line Navigator", desc: "Explored the 3D Interactive World Map.", icon: "🗺️", unlocked: true, date: "Mar 22, 2024" },
    { id: 4, title: "Devil Fruit Expert", desc: "Utilized the side-by-side fruit comparison tool.", icon: "🔥", unlocked: true, date: "May 14, 2024" },
    { id: 5, title: "Completed East Blue", desc: "Tracked every single East Blue Saga episode.", icon: "⛵", unlocked: true, date: "Jun 01, 2024" },
    { id: 6, title: "Completed Wano", desc: "Tracked every single Wano Country episode & chapter.", icon: "⚔️", unlocked: true, date: "Oct 15, 2025" },
    { id: 7, title: "Read 100 Chapters", desc: "Logged 100+ manga chapters in your reading tracker.", icon: "📖", unlocked: true, date: "Dec 01, 2025" },
    { id: 8, title: "Watch 500 Episodes", desc: "Logged 500+ anime episodes in your watch tracker.", icon: "📺", unlocked: true, date: "Mar 10, 2026" },
    { id: 9, title: "Marine Hunter", desc: "Track 20+ Marine Admiral and Vice Admiral dossiers.", icon: "🚨", unlocked: false, date: "Locked" },
    { id: 10, title: "Community Hero", desc: "Receive 500+ upvotes on your den den mushi comments.", icon: "👑", unlocked: false, date: "Locked" },
  ]);

  const handleMarkNextEpisode = () => {
    const nextEp = { id: 1113, title: "Run, Koby! Desperate Rescue Operation!", arc: "Egghead Arc", watchedDate: "Today", rating: 10, status: "Completed" };
    setWatchedEpisodes([nextEp, ...watchedEpisodes]);
    setToastMessage("Marked Episode 1113 as Completed! Watch completion bumped to 95%.");
  };

  const handleMarkNextChapter = () => {
    const nextCh = { id: 1121, title: "The Shifting World", volume: 110, readDate: "Today", rating: 10, status: "Completed" };
    setReadChapters([nextCh, ...readChapters]);
    setToastMessage("Marked Chapter 1121 as Completed! Manga reading completion bumped to 100%!");

    // Simulate auto unlocking an achievement
    setTimeout(() => {
      setAchievementsList((prev) => prev.map((a) => a.id === 9 ? { ...a, unlocked: true, date: "Just now" } : a));
      setToastMessage("🏆 ACHIEVEMENT UNLOCKED: Marine Hunter! Added to your public profile trophy room.");
    }, 2000);
  };

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* Toast Notification Popup */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 bg-ocean-royal text-ocean-foam border-2 border-treasure p-6 rounded-2xl shadow-premium-ocean flex items-center space-x-4 max-w-sm"
          >
            <CheckCircle2 className="w-6 h-6 text-treasure flex-shrink-0" />
            <span className="font-sans text-sm font-medium">{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="text-xs text-treasure hover:underline">Close</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[45vh] bg-ocean-deep overflow-hidden flex items-end pb-12 select-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-treasure/20 via-ocean-deep to-ocean-royal pointer-events-none" />
        <CoinParticles count={20} />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs items={[{ label: "Grand Line Wiki", href: "/" }, { label: "Profiles", href: `/profile/${username}` }, { label: "Tracker Hub" }]} />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <span className="inline-block bg-wood text-treasure font-cinematic font-bold px-4 py-1.5 rounded-full text-sm tracking-wider uppercase border border-treasure shadow-sm mb-3">
                SYNCED LOGS
              </span>
              <h1 className="text-5xl sm:text-6xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
                ANIME & MANGA TRACKER HUB
              </h1>
              <p className="text-lg font-sans text-ocean-foam/80 italic mt-1">Track your progress, mark completed releases, and unlock gamified milestones.</p>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MAIN TRACKER TABS */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <Tabs
          items={[
            {
              id: "watch",
              label: "ANIME WATCH TRACKER",
              content: (
                <div className="space-y-16">
                  {/* Overview Stats */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                    <StatCard label="Total Episodes Watched" value={1048} suffix=" Eps" icon={<Film className="w-6 h-6" />} progress={94} />
                    <StatCard label="Completion Percentage" value={94} suffix="%" icon={<TrendingUp className="w-6 h-6 text-emerald" />} />
                    <div className="sm:col-span-2 bg-ocean-deep text-ocean-foam border-4 border-treasure rounded-3xl p-8 shadow-premium-ocean flex flex-col justify-between">
                      <div>
                        <span className="font-cinematic text-xs text-treasure font-bold block uppercase mb-1">UPCOMING SIMULCAST EPISODE</span>
                        <h4 className="text-2xl font-cinematic font-bold text-treasure-light">EPISODE 1113: "RUN, KOBY! DESPERATE RESCUE OPERATION!"</h4>
                        <p className="text-sm font-sans text-ocean-foam/80 mt-2">Toei Animation release scheduled for June 30, 2026. Transponder snail alert flag active.</p>
                      </div>
                      <div className="mt-6 pt-4 border-t border-ocean-royal flex justify-end">
                        <Button variant="gilded" size="sm" onClick={handleMarkNextEpisode} className="text-xs">
                          MARK EPISODE 1113 COMPLETED
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Watch History Table */}
                  <div className="space-y-6">
                    <SectionHeader title="ANIME WATCH HISTORY" subtitle="Recently Tracked Broadcasts" />
                    <Table
                      columns={[
                        { header: "Episode Number", accessor: (row) => <span className="font-cinematic text-xl font-bold text-foreground">Episode {row.id}</span>, className: "w-48" },
                        { header: "Episode Title", accessor: "title", className: "font-cinematic text-xl font-bold text-foreground" },
                        { header: "Story Arc", accessor: "arc", className: "font-sans text-base text-muted-foreground" },
                        { header: "Watched Date", accessor: "watchedDate", className: "font-mono text-sm text-muted-foreground" },
                        { header: "Status", accessor: (row) => <span className="font-cinematic text-xs font-bold text-treasure bg-ocean-deep px-4 py-1.5 rounded-full border border-treasure uppercase">{row.status}</span>, className: "text-right w-36" },
                      ]}
                      data={watchedEpisodes}
                    />
                  </div>
                </div>
              ),
            },
            {
              id: "read",
              label: "MANGA READING TRACKER",
              content: (
                <div className="space-y-16">
                  {/* Overview Stats */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                    <StatCard label="Total Chapters Read" value={1120} suffix=" Chs" icon={<BookOpen className="w-6 h-6" />} progress={100} />
                    <StatCard label="Completion Percentage" value={100} suffix="%" icon={<Sparkles className="w-6 h-6 text-treasure" />} />
                    <div className="sm:col-span-2 bg-wooden-plank border-4 border-treasure rounded-3xl p-8 shadow-premium-ocean text-paper flex flex-col justify-between">
                      <div>
                        <span className="font-cinematic text-xs text-treasure font-bold block uppercase mb-1">UPCOMING JUMP DROP</span>
                        <h4 className="text-2xl font-cinematic font-bold text-treasure">CHAPTER 1121: "THE SHIFTING WORLD"</h4>
                        <p className="text-sm font-sans text-paper/80 mt-2">Release scheduled for July 02, 2026. Auto-sync background hook active.</p>
                      </div>
                      <div className="mt-6 pt-4 border-t border-treasure/30 flex justify-end">
                        <Button variant="gilded" size="sm" onClick={handleMarkNextChapter} className="text-xs">
                          MARK CHAPTER 1121 COMPLETED
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Reading History Table */}
                  <div className="space-y-6">
                    <SectionHeader title="MANGA READING HISTORY" subtitle="Recently Tracked Scans" />
                    <Table
                      columns={[
                        { header: "Chapter Number", accessor: (row) => <span className="font-cinematic text-xl font-bold text-foreground">Chapter {row.id}</span>, className: "w-48" },
                        { header: "Chapter Title", accessor: "title", className: "font-cinematic text-xl font-bold text-foreground" },
                        { header: "Volume Number", accessor: (row) => <span className="font-sans text-base text-muted-foreground">Volume {row.volume}</span>, className: "w-32" },
                        { header: "Read Date", accessor: "readDate", className: "font-mono text-sm text-muted-foreground" },
                        { header: "Status", accessor: (row) => <span className="font-cinematic text-xs font-bold text-treasure bg-ocean-deep px-4 py-1.5 rounded-full border border-treasure uppercase">{row.status}</span>, className: "text-right w-36" },
                      ]}
                      data={readChapters}
                    />
                  </div>
                </div>
              ),
            },
            {
              id: "achievements",
              label: "GAMIFIED ACHIEVEMENTS",
              content: (
                <div className="space-y-12">
                  <SectionHeader title="TROPHY BADGE ROOM" subtitle="Gamified Progress Across the Four Seas" />
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {achievementsList.map((ach) => (
                      <div
                        key={ach.id}
                        className={cn(
                          "border-2 rounded-2xl p-6 shadow-sm flex flex-col justify-between transition-colors group",
                          ach.unlocked ? "bg-wooden-plank border-treasure text-paper shadow-premium-ocean hover:border-treasure-light" : "bg-card/40 border-border/40 text-muted-foreground"
                        )}
                      >
                        <div>
                          <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">{ach.icon}</div>
                          <h4 className={cn("text-xl font-cinematic font-bold mb-2", ach.unlocked ? "text-treasure" : "text-foreground")}>{ach.title}</h4>
                          <p className="text-xs font-sans leading-relaxed font-medium opacity-90">{ach.desc}</p>
                        </div>
                        <div className={cn("mt-6 border-t pt-4 flex items-center justify-between text-[10px] font-mono", ach.unlocked ? "border-treasure/30 text-paper/60" : "border-border/40 text-muted-foreground")}>
                          <span>STATUS</span>
                          <span className={cn("font-bold", ach.unlocked ? "text-treasure" : "")}>{ach.date}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ),
            },
          ]}
        />
      </div>

      <Footer />
    </div>
  );
}
