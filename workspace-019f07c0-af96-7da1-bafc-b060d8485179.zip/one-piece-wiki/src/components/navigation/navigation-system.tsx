"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence, useScroll, useSpring } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, SearchInput } from "@/components/ui/buttons";
import { RopeBorder, CloudEffects, BirdAnimations } from "@/components/decorations/maritime";
import { Compass, Search, Menu, X, Anchor, ChevronRight, Moon, Sun, Flame, Award, BookOpen, Film, Shield, ArrowUp } from "lucide-react";

// ============================================================================
// 1. ANIMATED COMPASS WIDGET
// ============================================================================

export interface AnimatedCompassProps {
  size?: "sm" | "md" | "lg";
  className?: string;
}

export const AnimatedCompass: React.FC<AnimatedCompassProps> = ({ size = "md", className }) => {
  const sizeClasses = {
    sm: "w-12 h-12",
    md: "w-20 h-20",
    lg: "w-32 h-32",
  };

  return (
    <div className={cn("relative flex items-center justify-center select-none", sizeClasses[size], className)}>
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ repeat: Infinity, duration: 30, ease: "linear" }}
        className="absolute inset-0 rounded-full border-4 border-dashed border-treasure bg-ocean-deep shadow-premium-gilded"
      />
      <motion.div
        animate={{ rotate: [-20, 20, -20] }}
        transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
        className="relative flex items-center justify-center"
      >
        <Compass className="w-3/4 h-3/4 text-treasure animate-pulse" />
      </motion.div>
    </div>
  );
};

// ============================================================================
// 2. SCROLL INDICATOR
// ============================================================================

export interface ScrollIndicatorProps {
  className?: string;
}

export const ScrollIndicator: React.FC<ScrollIndicatorProps> = ({ className }) => {
  const { scrollYProgress } = useScroll();
  const scaleY = useSpring(scrollYProgress, { stiffness: 100, damping: 20 });
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsVisible(window.scrollY > 300);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  return (
    <div className={cn("fixed right-6 bottom-24 z-50 flex flex-col items-center space-y-4 select-none pointer-events-none", className)}>
      {/* Vertical Track */}
      <div className="relative w-2 h-32 bg-ocean-deep/80 rounded-full border border-treasure/50 overflow-hidden shadow-premium-ocean pointer-events-auto">
        <motion.div style={{ scaleY, originY: 0 }} className="w-full h-full bg-treasure" />
      </div>
      {/* Transponder Snail Scroll To Top */}
      <AnimatePresence>
        {isVisible && (
          <motion.button
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0 }}
            onClick={scrollToTop}
            className="w-12 h-12 rounded-full bg-wooden-plank border-2 border-treasure shadow-premium-gilded flex items-center justify-center text-treasure hover:bg-wood-light transition-colors pointer-events-auto"
          >
            <ArrowUp className="w-6 h-6" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
};

// ============================================================================
// 3. BREADCRUMBS (NAVIGATING THE GRAND LINE)
// ============================================================================

export interface BreadcrumbItem {
  label: string;
  href?: string;
}

export interface BreadcrumbsProps {
  items: BreadcrumbItem[];
  className?: string;
}

export const Breadcrumbs: React.FC<BreadcrumbsProps> = ({ items, className }) => {
  return (
    <nav className={cn("flex items-center space-x-2 font-cinematic text-sm text-muted-foreground select-none overflow-x-auto py-2 scrollbar-none", className)}>
      <Anchor className="w-4 h-4 text-treasure flex-shrink-0" />
      {items.map((item, index) => (
        <React.Fragment key={index}>
          {index > 0 && <ChevronRight className="w-4 h-4 text-border flex-shrink-0" />}
          {item.href && index !== items.length - 1 ? (
            <a href={item.href} className="hover:text-foreground transition-colors whitespace-nowrap">
              {item.label}
            </a>
          ) : (
            <span className="text-foreground font-bold whitespace-nowrap">{item.label}</span>
          )}
        </React.Fragment>
      ))}
    </nav>
  );
};

// ============================================================================
// 4. SEARCH OVERLAY
// ============================================================================

export interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  className?: string;
}

export const SearchOverlay: React.FC<SearchOverlayProps> = ({ isOpen, onClose, className }) => {
  const [query, setQuery] = useState("");

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex flex-col p-6 sm:p-12 bg-ocean-deep/95 backdrop-blur-lg overflow-y-auto">
          <div className="flex items-center justify-between max-w-4xl mx-auto w-full mb-8">
            <h3 className="text-3xl font-cinematic font-bold text-treasure tracking-wider">SEARCH THE GRAND LINE</h3>
            <button onClick={onClose} className="p-2 rounded-full bg-ocean-royal text-ocean-foam hover:bg-sunset-crimson transition-colors">
              <X className="w-6 h-6" />
            </button>
          </div>
          <div className="max-w-4xl mx-auto w-full space-y-8">
            <SearchInput
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onClear={() => setQuery("")}
              placeholder="Search characters, crews, devil fruits, islands..."
              className="max-w-full text-xl h-16"
            />
            {/* Quick Suggestions */}
            <div>
              <h4 className="font-cinematic text-lg font-bold text-ocean-foam mb-4 uppercase">Legendary Enquiries</h4>
              <div className="flex flex-wrap gap-3">
                {["Monkey D. Luffy", "Gol D. Roger", "Gear 5", "One Piece", "Shanks", "Yonko", "Wano Country", "Pluton"].map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setQuery(tag)}
                    className="px-4 py-2 rounded-xl bg-ocean-royal border border-ocean-light text-ocean-foam font-sans text-sm hover:border-treasure hover:text-treasure transition-colors"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
};

// ============================================================================
// 5. MEGA MENU
// ============================================================================

export interface MegaMenuProps {
  isOpen: boolean;
  onClose: () => void;
  className?: string;
}

export const MegaMenu: React.FC<MegaMenuProps> = ({ isOpen, onClose, className }) => {
  if (!isOpen) return null;

  const categories = [
    { title: "FACTIONS & ENTITIES", items: ["Pirate Crews", "Marines", "Yonko", "Revolutionaries", "Cross Guild", "World Government"] },
    { title: "LORE & ARSENAL", items: ["Devil Fruits", "Haki Types", "Meito Weapons", "Iconic Ships", "Islands & Realms", "World Map"] },
    { title: "PUBLICATIONS & MEDIA", items: ["Manga Chapters", "Anime Episodes", "Movies", "Grand Line News", "Bounty Ledger", "Bounty Generator"] },
    { title: "COMMUNITY FLEET", items: ["Discussion Boards", "Universe Polls", "Tracker Hub", "Achievements", "Admiral Hall", "Bounty Template Studio"] },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className={cn("absolute top-full left-0 right-0 z-50 bg-wooden-plank border-b-4 border-treasure shadow-premium-ocean p-8", className)}
        >
          <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {categories.map((cat, idx) => (
              <div key={idx} className="space-y-4">
                <h4 className="font-cinematic text-xl font-bold text-treasure border-b border-treasure/30 pb-2 flex items-center">
                  <Anchor className="w-5 h-5 mr-2 text-treasure" /> {cat.title}
                </h4>
                <ul className="space-y-2">
                  {cat.items.map((item) => (
                    <li key={item}>
                      <a href={`/${item.toLowerCase().replace(/ & /g, "-").replace(/ /g, "-")}`} className="text-paper hover:text-treasure transition-colors font-sans text-base block py-1">
                        {item}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

// ============================================================================
// 6. PREMIUM NAVBAR
// ============================================================================

export interface PremiumNavbarProps {
  onOpenSearch: () => void;
  className?: string;
}

export const PremiumNavbar: React.FC<PremiumNavbarProps> = ({ onOpenSearch, className }) => {
  const [isMegaMenuOpen, setIsMegaMenuOpen] = useState(false);
  const [isDark, setIsDark] = useState(true);

  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle("dark");
  };

  return (
    <header className={cn("sticky top-0 z-50 w-full bg-wooden-plank border-b-2 border-treasure shadow-premium-ocean select-none", className)}>
      <div className="max-w-7xl mx-auto h-20 px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Logo */}
        <a href="/" className="flex items-center space-x-3 group">
          <AnimatedCompass size="sm" />
          <div>
            <h1 className="text-2xl sm:text-3xl font-cinematic font-bold text-treasure tracking-wider group-hover:text-treasure-light transition-colors">
              ONE PIECE
            </h1>
            <p className="text-xs font-cinematic text-paper tracking-widest uppercase -mt-1">FAN WIKI OF THE GRAND LINE</p>
          </div>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-1 lg:space-x-4">
          <button
            onClick={() => setIsMegaMenuOpen(!isMegaMenuOpen)}
            className="px-4 py-2 font-cinematic text-lg font-bold text-paper hover:text-treasure transition-colors flex items-center"
          >
            ENCYCLOPEDIA
          </button>
          <a href="/world-map" className="px-4 py-2 font-cinematic text-lg font-bold text-paper hover:text-treasure transition-colors">
            WORLD MAP
          </a>
          <a href="/bounties/generator" className="px-4 py-2 font-cinematic text-lg font-bold text-treasure hover:text-treasure-light transition-colors flex items-center animate-pulse">
            <Flame className="w-5 h-5 mr-1.5 text-sunset" /> BOUNTY STUDIO
          </a>
          <a href="/community/boards" className="px-4 py-2 font-cinematic text-lg font-bold text-paper hover:text-treasure transition-colors">
            COMMUNITY
          </a>
        </nav>

        {/* Action Buttons */}
        <div className="flex items-center space-x-3">
          <button onClick={onOpenSearch} className="p-2.5 rounded-full bg-ocean-royal text-ocean-foam hover:border-treasure border border-transparent transition-all shadow-sm">
            <Search className="w-5 h-5" />
          </button>
          <button onClick={toggleTheme} className="p-2.5 rounded-full bg-ocean-royal text-ocean-foam hover:border-treasure border border-transparent transition-all shadow-sm">
            {isDark ? <Sun className="w-5 h-5 text-treasure" /> : <Moon className="w-5 h-5 text-treasure" />}
          </button>
          <div className="hidden sm:block">
            <Button variant="gilded" size="default" onClick={() => (window.location.href = "/auth/signin")}>
              SET SAIL (LOGIN)
            </Button>
          </div>
          <button className="md:hidden p-2.5 rounded-full bg-ocean-royal text-ocean-foam" onClick={() => setIsMegaMenuOpen(!isMegaMenuOpen)}>
            {isMegaMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mega Menu Overlay */}
      <MegaMenu isOpen={isMegaMenuOpen} onClose={() => setIsMegaMenuOpen(false)} />
    </header>
  );
};

// ============================================================================
// 7. MOBILE NAVBAR
// ============================================================================

export interface MobileNavbarProps {
  onOpenSearch: () => void;
  className?: string;
}

export const MobileNavbar: React.FC<MobileNavbarProps> = ({ onOpenSearch, className }) => {
  return (
    <div className={cn("fixed bottom-0 inset-x-0 z-40 md:hidden bg-wooden-plank border-t-2 border-treasure shadow-premium-ocean flex items-center justify-around h-16 px-4 select-none", className)}>
      <a href="/" className="flex flex-col items-center text-paper hover:text-treasure transition-colors">
        <Compass className="w-6 h-6 text-treasure animate-pulse" />
        <span className="text-[10px] font-cinematic font-bold mt-1">HOME</span>
      </a>
      <a href="/characters" className="flex flex-col items-center text-paper hover:text-treasure transition-colors">
        <Shield className="w-6 h-6 text-paper" />
        <span className="text-[10px] font-cinematic font-bold mt-1">FACTIONS</span>
      </a>
      <a href="/bounties/generator" className="flex flex-col items-center text-treasure hover:text-treasure-light transition-colors -mt-6 bg-ocean-deep p-3 rounded-full border-2 border-treasure shadow-premium-gilded">
        <Flame className="w-7 h-7 text-sunset animate-bounce" />
      </a>
      <a href="/chapters" className="flex flex-col items-center text-paper hover:text-treasure transition-colors">
        <BookOpen className="w-6 h-6 text-paper" />
        <span className="text-[10px] font-cinematic font-bold mt-1">MANGA</span>
      </a>
      <button onClick={onOpenSearch} className="flex flex-col items-center text-paper hover:text-treasure transition-colors">
        <Search className="w-6 h-6 text-paper" />
        <span className="text-[10px] font-cinematic font-bold mt-1">SEARCH</span>
      </button>
    </div>
  );
};

// ============================================================================
// 8. DESKTOP SIDEBAR
// ============================================================================

export interface SidebarProps {
  className?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ className }) => {
  const links = [
    { label: "Characters", href: "/characters", icon: <Shield className="w-5 h-5 mr-3 text-treasure" /> },
    { label: "Pirate Crews", href: "/crews", icon: <Anchor className="w-5 h-5 mr-3 text-treasure" /> },
    { label: "Devil Fruits", href: "/devil-fruits", icon: <Flame className="w-5 h-5 mr-3 text-sunset" /> },
    { label: "Bounty Studio", href: "/bounties/generator", icon: <Award className="w-5 h-5 mr-3 text-treasure" /> },
    { label: "Manga Chapters", href: "/chapters", icon: <BookOpen className="w-5 h-5 mr-3 text-treasure" /> },
    { label: "Anime Episodes", href: "/episodes", icon: <Film className="w-5 h-5 mr-3 text-treasure" /> },
  ];

  return (
    <aside className={cn("w-72 flex-shrink-0 p-6 rounded-3xl border-2 border-border bg-parchment shadow-paper-lift select-none h-fit sticky top-28 hidden lg:block", className)}>
      <h4 className="font-cinematic text-xl font-bold text-foreground mb-6 border-b-2 border-border pb-3 flex items-center">
        <Compass className="w-6 h-6 mr-2 text-treasure" /> WIKI LOG POSE
      </h4>
      <ul className="space-y-2">
        {links.map((link) => (
          <li key={link.label}>
            <a href={link.href} className="flex items-center px-4 py-3 rounded-xl font-cinematic text-lg text-foreground hover:bg-treasure/20 hover:text-wood-light transition-all">
              {link.icon} {link.label}
            </a>
          </li>
        ))}
      </ul>
      <RopeBorder className="my-6" />
      <div className="bg-ocean-deep text-paper p-6 rounded-2xl border border-treasure shadow-sm">
        <h5 className="font-cinematic text-lg font-bold text-treasure mb-2">CANVA BOUNTY ENGINE</h5>
        <p className="font-sans text-xs leading-relaxed mb-4 text-ocean-foam/80">
          Design your custom legendary bounty poster with complete layer drag, drop, rotation, and burn filters!
        </p>
        <Button variant="gilded" size="sm" onClick={() => (window.location.href = "/bounties/generator")} className="w-full text-xs">
          LAUNCH STUDIO
        </Button>
      </div>
    </aside>
  );
};

// ============================================================================
// 9. SECTION HEADER
// ============================================================================

export interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  className?: string;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({ title, subtitle, className }) => {
  return (
    <div className={cn("text-center my-12 select-none", className)}>
      {subtitle && <p className="font-cinematic text-lg text-treasure tracking-widest uppercase mb-2">~ {subtitle} ~</p>}
      <h2 className="text-4xl sm:text-5xl font-cinematic font-bold text-foreground tracking-wide">{title}</h2>
      <RopeBorder className="w-64 mx-auto my-4" />
    </div>
  );
};

// ============================================================================
// 10. EPIC HERO COMPONENT
// ============================================================================

export interface HeroComponentProps {
  title?: string;
  subtitle?: string;
  ctaText?: string;
  onCtaClick?: () => void;
  className?: string;
}

export const HeroComponent: React.FC<HeroComponentProps> = ({
  title = "THE ULTIMATE FAN ENCYCLOPEDIA OF THE GRAND LINE",
  subtitle = "Set sail across 1,100+ chapters, legendary pirate crews, awakened devil fruits, and design your custom high-fidelity bounty posters.",
  ctaText = "EXPLORE THE GRAND LINE",
  onCtaClick,
  className,
}) => {
  return (
    <div className={cn("relative w-full min-h-[80vh] flex items-center justify-center bg-gradient-to-b from-ocean via-ocean-deep to-ocean-royal overflow-hidden select-none px-6 py-24", className)}>
      {/* Moving Atmosphere */}
      <CloudEffects />
      <BirdAnimations />
      <div className="relative z-10 max-w-5xl mx-auto text-center space-y-8">
        <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.8 }} className="flex justify-center">
          <AnimatedCompass size="lg" />
        </motion.div>
        <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.2 }} className="text-5xl sm:text-6xl md:text-7xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
          {title}
        </motion.h1>
        <motion.p initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.4 }} className="text-lg sm:text-xl md:text-2xl font-sans text-ocean-foam/80 max-w-3xl mx-auto leading-relaxed">
          {subtitle}
        </motion.p>
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.6 }} className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <Button variant="gilded" size="lg" onClick={onCtaClick}>
            {ctaText}
          </Button>
          <Button variant="royal" size="lg" onClick={() => (window.location.href = "/bounties/generator")} leftIcon={<Flame className="w-5 h-5 text-sunset" />}>
            LAUNCH BOUNTY STUDIO
          </Button>
        </motion.div>
      </div>
    </div>
  );
};

// ============================================================================
// 11. FEATURE SECTION
// ============================================================================

export interface FeatureSectionProps {
  className?: string;
}

export const FeatureSection: React.FC<FeatureSectionProps> = ({ className }) => {
  const features = [
    { title: "Universal Lore Biome", desc: "Exhaustively tracked relationships, stat radars, and history for 1,000+ characters, crews, and marines.", icon: <Shield className="w-8 h-8 text-treasure" /> },
    { title: "3D Interactive World Map", desc: "Rotate and zoom across the Four Blues, Grand Line, and Red Line with real-time Log Pose weather data.", icon: <Compass className="w-8 h-8 text-treasure" /> },
    { title: "Canva Bounty Studio", desc: "Full vector layer manipulation, custom upload, burn/scratch filters, and multi-format high-res export.", icon: <Flame className="w-8 h-8 text-sunset" /> },
    { title: "Manga & Anime Trackers", desc: "Synchronize your reading and watch lists, unlock custom gamified achievement badges, and vote in live polls.", icon: <BookOpen className="w-8 h-8 text-treasure" /> },
  ];

  return (
    <section className={cn("max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 select-none", className)}>
      <SectionHeader title="LEGENDARY PLATFORM FEATURES" subtitle="Built for True Fans of the Grand Line" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
        {features.map((feat, idx) => (
          <div key={idx} className="bg-card border-2 border-border rounded-3xl p-8 shadow-paper-lift hover:border-treasure transition-all group flex space-x-6">
            <div className="w-16 h-16 rounded-2xl bg-ocean-deep border-2 border-treasure flex items-center justify-center shadow-premium-gilded flex-shrink-0 group-hover:scale-110 transition-transform">
              {feat.icon}
            </div>
            <div>
              <h4 className="text-2xl font-cinematic font-bold text-foreground group-hover:text-treasure-dark transition-colors mb-2">{feat.title}</h4>
              <p className="text-muted-foreground font-sans text-base leading-relaxed">{feat.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

// ============================================================================
// 12. EPIC FOOTER
// ============================================================================

export interface FooterProps {
  className?: string;
}

export const Footer: React.FC<FooterProps> = ({ className }) => {
  return (
    <footer className={cn("w-full bg-wooden-plank border-t-4 border-treasure text-paper pt-20 pb-12 shadow-premium-ocean select-none relative overflow-hidden", className)}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center space-x-3">
              <AnimatedCompass size="sm" />
              <h3 className="text-3xl font-cinematic font-bold text-treasure tracking-wider">ONE PIECE FAN WIKI</h3>
            </div>
            <p className="font-sans text-sm text-paper/80 leading-relaxed max-w-sm">
              The ultimate production-ready fan encyclopedia. Built with Next.js 15, Drizzle ORM, Three.js, and high-fidelity Canva-grade bounty rendering engines.
            </p>
            <div className="pt-4">
              <h5 className="font-cinematic text-sm font-bold text-treasure mb-3">SUBSCRIBE TO NEWS COO EXPRESS</h5>
              <div className="flex max-w-md space-x-2">
                <input type="email" placeholder="Enter your email..." className="flex-grow h-12 rounded-lg bg-ocean-deep border border-treasure px-4 text-ocean-foam placeholder:text-ocean-foam/50 focus:outline-none focus:ring-2 focus:ring-treasure-light" />
                <Button variant="gilded" size="default">JOIN</Button>
              </div>
            </div>
          </div>
          <div>
            <h5 className="font-cinematic text-lg font-bold text-treasure mb-6 border-b border-treasure/30 pb-2">ENCYCLOPEDIA</h5>
            <ul className="space-y-3 font-sans text-sm text-paper/80">
              {["Characters", "Pirate Crews", "Marines", "Yonko", "Revolutionaries", "Devil Fruits"].map((item) => (
                <li key={item}><a href={`/${item.toLowerCase().replace(/ /g, "-")}`} className="hover:text-treasure transition-colors">{item}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h5 className="font-cinematic text-lg font-bold text-treasure mb-6 border-b border-treasure/30 pb-2">UNIVERSE HUB</h5>
            <ul className="space-y-3 font-sans text-sm text-paper/80">
              {["Interactive World Map", "Bounty Studio", "Manga Chapters", "Anime Episodes", "Grand Line News", "Discussion Boards"].map((item) => (
                <li key={item}><a href={`/${item.toLowerCase().replace(/ /g, "-")}`} className="hover:text-treasure transition-colors">{item}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h5 className="font-cinematic text-lg font-bold text-treasure mb-6 border-b border-treasure/30 pb-2">COMMUNITY FLEET</h5>
            <ul className="space-y-3 font-sans text-sm text-paper/80">
              {["User Profiles", "Manga Reading Tracker", "Anime Watch Tracker", "Hall of Achievements", "Active Polls", "Gorosei Dashboard"].map((item) => (
                <li key={item}><a href={`/${item.toLowerCase().replace(/ /g, "-")}`} className="hover:text-treasure transition-colors">{item}</a></li>
              ))}
            </ul>
          </div>
        </div>
        <div className="border-t border-treasure/20 pt-8 flex flex-col sm:flex-row items-center justify-between font-sans text-xs text-paper/60 space-y-4 sm:space-y-0">
          <p>© 2026 One Piece Fan Wiki. All rights reserved. Built for fans, by fans.</p>
          <div className="flex space-x-6">
            <a href="/privacy" className="hover:text-treasure transition-colors">Privacy Charter</a>
            <a href="/terms" className="hover:text-treasure transition-colors">Terms of Navigation</a>
            <a href="/offline" className="hover:text-treasure transition-colors">PWA Support</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
