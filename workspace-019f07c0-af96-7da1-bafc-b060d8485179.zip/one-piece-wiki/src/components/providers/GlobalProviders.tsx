"use client";

import React, { useState } from "react";
import { SessionProvider } from "next-auth/react";
import { ThemeProvider } from "next-themes";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

// ============================================================================
// ENTERPRISE GLOBAL STATE & THEME PROVIDERS
// ============================================================================

export interface GlobalProvidersProps {
  children: React.ReactNode;
  session: any | null;
}

export default function GlobalProviders({ children, session }: GlobalProvidersProps) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 60 * 1000, // 1 minute stale time for fast navigation
            refetchOnWindowFocus: false,
            retry: 1, // Fall back to static simulation after 1 retry
          },
        },
      })
  );

  return (
    <SessionProvider session={session}>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false} storageKey="one_piece_theme">
          {children}
        </ThemeProvider>
      </QueryClientProvider>
    </SessionProvider>
  );
}
