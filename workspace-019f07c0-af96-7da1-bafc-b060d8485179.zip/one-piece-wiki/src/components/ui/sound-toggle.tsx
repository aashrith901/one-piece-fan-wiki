"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Volume2, VolumeX } from "lucide-react";

// ============================================================================
// SOUND & AMBIANCE TOGGLE MICROINTERACTION
// ============================================================================

export default function SoundToggle({ className }: { className?: string }) {
  const [isSoundEnabled, setIsSoundEnabled] = useState(false);

  const toggleSound = () => {
    setIsSoundEnabled(!isSoundEnabled);
    if (!isSoundEnabled) {
      // Simulation of ocean waves audio ambiance
      console.log("Audio Ambiance Enabled: Ocean waves and wooden creaks active.");
    } else {
      console.log("Audio Ambiance Disabled.");
    }
  };

  return (
    <button
      onClick={toggleSound}
      className={cn(
        "fixed bottom-6 left-6 z-50 p-3 rounded-full border-2 transition-all shadow-premium-ocean flex items-center justify-center h-12 w-12 select-none",
        isSoundEnabled ? "bg-treasure text-ocean-deep border-treasure-light shadow-premium-gilded" : "bg-ocean-deep text-ocean-foam border-ocean-royal hover:border-treasure"
      )}
      title={isSoundEnabled ? "Disable Grand Line Ambiance" : "Enable Grand Line Ambiance"}
    >
      {isSoundEnabled ? <Volume2 className="w-6 h-6 animate-pulse" /> : <VolumeX className="w-6 h-6 text-muted-foreground" />}
    </button>
  );
}
