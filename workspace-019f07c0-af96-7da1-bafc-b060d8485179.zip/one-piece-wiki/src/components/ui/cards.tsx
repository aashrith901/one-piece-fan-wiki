"use client";

import React from "react";
import { cn, formatBounty } from "@/lib/utils";
import { CardTilt, AnimatedCounter } from "@/components/animations/motion";
import { Badge } from "@/components/ui/buttons";
import { Compass, Anchor, Quote, Sparkles, AlertCircle } from "lucide-react";

// ============================================================================
// 1. CHARACTER CARD
// ============================================================================

export interface CharacterCardProps {
  name: string;
  epithet?: string;
  image: string;
  bounty?: string | number;
  faction?: "pirate" | "marine" | "yonko" | "revs" | "crossguild";
  stats?: { power: number; speed: number; haki: number };
  onClick?: () => void;
  className?: string;
}

export const CharacterCard: React.FC<CharacterCardProps> = ({
  name,
  epithet,
  image,
  bounty,
  faction = "pirate",
  stats,
  onClick,
  className,
}) => {
  return (
    <CardTilt className={cn("w-full max-w-sm cursor-pointer select-none", className)}>
      <div
        onClick={onClick}
        className="relative overflow-hidden rounded-2xl border-2 border-treasure bg-ocean-deep shadow-premium-ocean transition-all duration-500 hover:border-treasure-light hover:shadow-premium-gilded group"
      >
        {/* Main Cover Image */}
        <div className="relative h-80 w-full overflow-hidden bg-ocean-royal">
          <img
            src={image}
            alt={name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ocean-deep via-transparent to-transparent opacity-90" />
          
          {/* Faction Badge */}
          <div className="absolute top-4 left-4 z-10">
            <Badge variant={faction}>{faction}</Badge>
          </div>

          {/* Bounty Ribbon */}
          {bounty && (
            <div className="absolute top-4 right-4 z-10">
              <Badge variant="bounty">{formatBounty(bounty)}</Badge>
            </div>
          )}
        </div>

        {/* Character Details */}
        <div className="p-6 relative z-10 -mt-12">
          {epithet && <p className="text-sm font-cinematic text-treasure italic mb-1">"{epithet}"</p>}
          <h3 className="text-2xl font-cinematic font-bold text-ocean-foam tracking-wider group-hover:text-treasure transition-colors">
            {name}
          </h3>

          {/* Stat Bars */}
          {stats && (
            <div className="mt-4 space-y-2 border-t border-ocean-royal pt-4">
              <div className="flex items-center justify-between text-xs font-mono text-ocean-foam/80">
                <span>POWER</span>
                <div className="w-32 h-1.5 bg-ocean-royal rounded-full overflow-hidden">
                  <div className="h-full bg-sunset transition-all duration-500" style={{ width: `${stats.power}%` }} />
                </div>
              </div>
              <div className="flex items-center justify-between text-xs font-mono text-ocean-foam/80">
                <span>SPEED</span>
                <div className="w-32 h-1.5 bg-ocean-royal rounded-full overflow-hidden">
                  <div className="h-full bg-emerald transition-all duration-500" style={{ width: `${stats.speed}%` }} />
                </div>
              </div>
              <div className="flex items-center justify-between text-xs font-mono text-ocean-foam/80">
                <span>HAKI</span>
                <div className="w-32 h-1.5 bg-ocean-royal rounded-full overflow-hidden">
                  <div className="h-full bg-treasure transition-all duration-500" style={{ width: `${stats.haki}%` }} />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </CardTilt>
  );
};

// ============================================================================
// 2. ISLAND CARD
// ============================================================================

export interface IslandCardProps {
  name: string;
  region: string;
  climate?: string;
  logPoseTime?: string;
  image: string;
  onClick?: () => void;
  className?: string;
}

export const IslandCard: React.FC<IslandCardProps> = ({
  name,
  region,
  climate,
  logPoseTime,
  image,
  onClick,
  className,
}) => {
  return (
    <CardTilt className={cn("w-full max-w-sm cursor-pointer select-none", className)}>
      <div
        onClick={onClick}
        className="relative overflow-hidden rounded-2xl border-2 border-border bg-parchment shadow-paper-lift transition-all duration-500 hover:border-treasure group"
      >
        <div className="relative h-60 w-full overflow-hidden bg-wood">
          <img
            src={image}
            alt={name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-paper-charcoal via-transparent to-transparent opacity-80" />
          <div className="absolute bottom-4 left-4 flex items-center text-paper font-cinematic text-xs tracking-widest uppercase">
            <Compass className="w-4 h-4 mr-1 text-treasure animate-pulse" />
            {region}
          </div>
        </div>

        <div className="p-6">
          <h3 className="text-2xl font-cinematic font-bold text-foreground group-hover:text-wood-light transition-colors">
            {name}
          </h3>
          
          <div className="mt-4 flex items-center justify-between border-t border-border pt-4 text-sm text-muted-foreground font-sans">
            {climate && (
              <div>
                <span className="text-xs uppercase font-bold block text-foreground">Climate</span>
                {climate}
              </div>
            )}
            {logPoseTime && (
              <div className="text-right">
                <span className="text-xs uppercase font-bold block text-foreground">Log Pose Lock</span>
                {logPoseTime}
              </div>
            )}
          </div>
        </div>
      </div>
    </CardTilt>
  );
};

// ============================================================================
// 3. DEVIL FRUIT CARD
// ============================================================================

export interface DevilFruitCardProps {
  name: string;
  meaning: string;
  type: "Paramecia" | "Zoan" | "Logia" | "Ancient Zoan" | "Mythical Zoan";
  image?: string;
  isAwakened?: boolean;
  onClick?: () => void;
  className?: string;
}

export const DevilFruitCard: React.FC<DevilFruitCardProps> = ({
  name,
  meaning,
  type,
  image,
  isAwakened = false,
  onClick,
  className,
}) => {
  const typeBadgeColors = {
    Paramecia: "bg-sunset-crimson text-white",
    Zoan: "bg-wood text-treasure",
    Logia: "bg-ocean-royal text-ocean-foam",
    "Ancient Zoan": "bg-wood-weathered text-treasure-light",
    "Mythical Zoan": "bg-gradient-to-r from-treasure via-sunset to-sunset-crimson text-ocean-deep font-bold",
  };

  return (
    <CardTilt className={cn("w-full max-w-sm cursor-pointer select-none", className)}>
      <div
        onClick={onClick}
        className="relative overflow-hidden rounded-2xl border-2 border-treasure bg-wooden-plank shadow-premium-ocean transition-all duration-500 hover:border-treasure-light group p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <span className={cn("px-3 py-1 rounded-full text-xs font-cinematic tracking-wider uppercase shadow-sm", typeBadgeColors[type])}>
            {type}
          </span>
          {isAwakened && (
            <span className="flex items-center text-xs font-cinematic font-bold text-treasure bg-ocean-deep px-3 py-1 rounded-full border border-treasure shadow-glowing-bounty animate-pulse">
              <Sparkles className="w-3.5 h-3.5 mr-1 text-treasure" /> AWAKENED
            </span>
          )}
        </div>

        <div className="relative h-48 w-full flex items-center justify-center mb-6 bg-ocean-deep/50 rounded-xl border border-treasure/30 overflow-hidden group-hover:border-treasure transition-colors">
          {image ? (
            <img src={image} alt={name} className="w-40 h-40 object-contain transition-transform duration-700 group-hover:scale-110" />
          ) : (
            <AlertCircle className="w-16 h-16 text-treasure/40" />
          )}
        </div>

        <h3 className="text-2xl font-cinematic font-bold text-treasure tracking-wide group-hover:text-treasure-light transition-colors">
          {name}
        </h3>
        <p className="text-sm font-sans text-paper/80 mt-1 italic">Meaning: "{meaning}"</p>
      </div>
    </CardTilt>
  );
};

// ============================================================================
// 4. NEWS CARD
// ============================================================================

export interface NewsCardProps {
  title: string;
  excerpt: string;
  category: string;
  date: string;
  image: string;
  onClick?: () => void;
  className?: string;
}

export const NewsCard: React.FC<NewsCardProps> = ({ title, excerpt, category, date, image, onClick, className }) => {
  return (
    <div
      onClick={onClick}
      className={cn(
        "cursor-pointer overflow-hidden rounded-2xl border border-border bg-card shadow-paper-lift transition-all duration-300 hover:translate-y-[-4px] hover:border-treasure hover:shadow-premium-gilded group flex flex-col h-full",
        className
      )}
    >
      <div className="relative h-56 w-full overflow-hidden bg-wood">
        <img src={image} alt={title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
        <span className="absolute top-4 left-4 bg-ocean-deep text-treasure px-3 py-1 rounded-full text-xs font-cinematic tracking-wider uppercase border border-treasure/50">
          {category}
        </span>
      </div>
      <div className="p-6 flex flex-col flex-grow justify-between">
        <div>
          <h4 className="text-xl font-cinematic font-bold text-foreground group-hover:text-treasure-dark transition-colors line-clamp-2">
            {title}
          </h4>
          <p className="mt-2 text-sm text-muted-foreground line-clamp-3 font-sans">{excerpt}</p>
        </div>
        <div className="mt-6 border-t border-border pt-4 flex items-center justify-between text-xs text-muted-foreground font-mono">
          <span>NEWS COO EXPRESS</span>
          <span>{date}</span>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// 5. QUOTE CARD
// ============================================================================

export interface QuoteCardProps {
  quote: string;
  author: string;
  context?: string;
  className?: string;
}

export const QuoteCard: React.FC<QuoteCardProps> = ({ quote, author, context, className }) => {
  return (
    <div className={cn("relative overflow-hidden rounded-2xl border-2 border-treasure bg-ocean-deep p-8 shadow-premium-ocean", className)}>
      <Quote className="absolute top-4 left-4 w-20 h-20 text-treasure/10 pointer-events-none" />
      <div className="relative z-10">
        <p className="text-2xl sm:text-3xl font-cinematic text-ocean-foam italic leading-relaxed mb-6">
          "{quote}"
        </p>
        <div className="flex items-center justify-between border-t border-ocean-royal pt-4">
          <h5 className="text-lg font-cinematic font-bold text-treasure">{author}</h5>
          {context && <span className="text-xs font-sans text-ocean-foam/60">{context}</span>}
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// 6. FACT CARD
// ============================================================================

export interface FactCardProps {
  title: string;
  fact: string;
  className?: string;
}

export const FactCard: React.FC<FactCardProps> = ({ title, fact, className }) => {
  return (
    <div className={cn("relative overflow-hidden rounded-xl border border-border bg-parchment p-6 shadow-paper-lift", className)}>
      <div className="flex items-center mb-4">
        <Anchor className="w-5 h-5 mr-2 text-treasure" />
        <h5 className="text-lg font-cinematic font-bold text-foreground tracking-wide">{title}</h5>
      </div>
      <p className="text-sm font-sans text-muted-foreground leading-relaxed">{fact}</p>
    </div>
  );
};

// ============================================================================
// 7. STAT CARD
// ============================================================================

export interface StatCardProps {
  label: string;
  value: number;
  prefix?: string;
  suffix?: string;
  icon?: React.ReactNode;
  progress?: number; // 0 to 100
  className?: string;
}

export const StatCard: React.FC<StatCardProps> = ({ label, value, prefix, suffix, icon, progress, className }) => {
  return (
    <div className={cn("relative overflow-hidden rounded-2xl border border-border bg-card p-6 shadow-sm", className)}>
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm font-sans font-medium text-muted-foreground uppercase tracking-wider">{label}</span>
        {icon && <span className="text-treasure">{icon}</span>}
      </div>
      <div className="text-3xl sm:text-4xl font-mono font-bold text-foreground tracking-tight mb-2">
        <AnimatedCounter value={value} prefix={prefix} suffix={suffix} />
      </div>
      {progress !== undefined && (
        <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden mt-4">
          <div className="h-full bg-treasure transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
      )}
    </div>
  );
};
