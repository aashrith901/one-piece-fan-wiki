"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { ChevronDown, ChevronLeft, ChevronRight, X, Info, Check, AlertTriangle, Anchor } from "lucide-react";
import { Button } from "@/components/ui/buttons";

// ============================================================================
// 1. ANIMATED TABS
// ============================================================================

export interface TabItem {
  id: string;
  label: string;
  content: React.ReactNode;
}

export interface TabsProps {
  items: TabItem[];
  defaultTab?: string;
  className?: string;
}

export const Tabs: React.FC<TabsProps> = ({ items, defaultTab, className }) => {
  const [activeId, setActiveId] = useState(defaultTab || items[0]?.id || "");

  return (
    <div className={cn("w-full", className)}>
      {/* Tab Headers */}
      <div className="flex space-x-1 border-b-2 border-border mb-6 overflow-x-auto scrollbar-none">
        {items.map((item) => {
          const isActive = item.id === activeId;
          return (
            <button
              key={item.id}
              onClick={() => setActiveId(item.id)}
              className={cn(
                "relative px-6 py-3 font-cinematic text-lg tracking-wide font-bold transition-colors duration-200 whitespace-nowrap outline-none",
                isActive ? "text-treasure" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {item.label}
              {isActive && (
                <motion.div
                  layoutId="activeTabUnderline"
                  className="absolute bottom-[-2px] left-0 right-0 h-1 bg-treasure"
                  transition={{ duration: 0.3, ease: "easeOut" }}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeId}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3 }}
          className="w-full"
        >
          {items.find((item) => item.id === activeId)?.content}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

// ============================================================================
// 2. PREMIUM ACCORDION
// ============================================================================

export interface AccordionItem {
  id: string;
  title: string;
  content: React.ReactNode;
}

export interface AccordionProps {
  items: AccordionItem[];
  allowMultiple?: boolean;
  className?: string;
}

export const Accordion: React.FC<AccordionProps> = ({ items, allowMultiple = false, className }) => {
  const [openIds, setOpenIds] = useState<string[]>([]);

  const toggle = (id: string) => {
    if (allowMultiple) {
      setOpenIds((prev) => (prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]));
    } else {
      setOpenIds((prev) => (prev.includes(id) ? [] : [id]));
    }
  };

  return (
    <div className={cn("w-full space-y-4", className)}>
      {items.map((item) => {
        const isOpen = openIds.includes(item.id);
        return (
          <div key={item.id} className="border-2 border-border rounded-xl bg-card overflow-hidden transition-colors duration-200">
            <button
              onClick={() => toggle(item.id)}
              className="flex items-center justify-between w-full p-6 font-cinematic text-xl font-bold text-foreground text-left focus:outline-none"
            >
              <span>{item.title}</span>
              <ChevronDown className={cn("w-6 h-6 text-treasure transition-transform duration-300", isOpen && "rotate-180")} />
            </button>
            <AnimatePresence>
              {isOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="px-6 pb-6 pt-0 text-muted-foreground font-sans text-base leading-relaxed border-t border-border/50 pt-4"
                >
                  {item.content}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
};

// ============================================================================
// 3. RESPONSIVE TABLE
// ============================================================================

export interface TableColumn<T> {
  header: string;
  accessor: keyof T | ((row: T) => React.ReactNode);
  className?: string;
}

export interface TableProps<T> {
  columns: TableColumn<T>[];
  data: T[];
  className?: string;
}

export const Table = <T,>({ columns, data, className }: TableProps<T>) => {
  return (
    <div className={cn("w-full overflow-x-auto rounded-2xl border-2 border-border bg-card shadow-sm", className)}>
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="border-b-2 border-border bg-ocean-deep text-treasure font-cinematic text-lg tracking-wider">
            {columns.map((col, index) => (
              <th key={index} className={cn("p-6 font-bold", col.className)}>
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {data.map((row, rowIndex) => (
            <tr key={rowIndex} className="hover:bg-muted/50 transition-colors duration-150 font-sans text-base text-foreground">
              {columns.map((col, colIndex) => (
                <td key={colIndex} className={cn("p-6", col.className)}>
                  {typeof col.accessor === "function" ? col.accessor(row) : (row[col.accessor] as React.ReactNode)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

// ============================================================================
// 4. ELEGANT PAGINATION
// ============================================================================

export interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  className?: string;
}

export const Pagination: React.FC<PaginationProps> = ({ currentPage, totalPages, onPageChange, className }) => {
  const pages = Array.from({ length: totalPages }, (_, i) => i + 1);

  return (
    <div className={cn("flex items-center justify-center space-x-2 font-cinematic", className)}>
      <Button
        variant="ghost"
        size="icon"
        disabled={currentPage === 1}
        onClick={() => onPageChange(currentPage - 1)}
      >
        <ChevronLeft className="w-5 h-5" />
      </Button>
      {pages.map((page) => (
        <button
          key={page}
          onClick={() => onPageChange(page)}
          className={cn(
            "w-11 h-11 rounded-lg font-bold text-base flex items-center justify-center transition-all duration-200",
            currentPage === page
              ? "bg-treasure text-ocean-deep shadow-premium-gilded"
              : "text-foreground hover:bg-muted"
          )}
        >
          {page}
        </button>
      ))}
      <Button
        variant="ghost"
        size="icon"
        disabled={currentPage === totalPages}
        onClick={() => onPageChange(currentPage + 1)}
      >
        <ChevronRight className="w-5 h-5" />
      </Button>
    </div>
  );
};

// ============================================================================
// 5. PREMIUM CAROUSEL
// ============================================================================

export interface CarouselProps {
  children: React.ReactNode[];
  className?: string;
}

export const Carousel: React.FC<CarouselProps> = ({ children, className }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const prev = () => setCurrentIndex((curr) => (curr === 0 ? children.length - 1 : curr - 1));
  const next = () => setCurrentIndex((curr) => (curr === children.length - 1 ? 0 : curr + 1));

  return (
    <div className={cn("relative w-full overflow-hidden rounded-2xl", className)}>
      <div
        className="flex transition-transform duration-500 ease-out h-full"
        style={{ transform: `translateX(-${currentIndex * 100}%)` }}
      >
        {children.map((child, index) => (
          <div key={index} className="min-w-full flex-shrink-0">
            {child}
          </div>
        ))}
      </div>
      {/* Controls */}
      <div className="absolute inset-y-0 left-4 flex items-center">
        <Button variant="royal" size="icon" onClick={prev} className="rounded-full shadow-premium-ocean w-12 h-12">
          <ChevronLeft className="w-6 h-6 text-treasure" />
        </Button>
      </div>
      <div className="absolute inset-y-0 right-4 flex items-center">
        <Button variant="royal" size="icon" onClick={next} className="rounded-full shadow-premium-ocean w-12 h-12">
          <ChevronRight className="w-6 h-6 text-treasure" />
        </Button>
      </div>
      {/* Indicators */}
      <div className="absolute bottom-4 left-0 right-0 flex items-center justify-center space-x-2">
        {children.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentIndex(i)}
            className={cn("w-3 h-3 rounded-full transition-all duration-300", currentIndex === i ? "bg-treasure w-8" : "bg-ocean-foam/50")}
          />
        ))}
      </div>
    </div>
  );
};

// ============================================================================
// 6. TIMELINE COMPONENT
// ============================================================================

export interface TimelineEvent {
  year: string;
  title: string;
  description: string;
  faction?: string;
}

export interface TimelineProps {
  events: TimelineEvent[];
  className?: string;
}

export const Timeline: React.FC<TimelineProps> = ({ events, className }) => {
  return (
    <div className={cn("relative border-l-4 border-treasure ml-4 sm:ml-8 space-y-12 py-4", className)}>
      {events.map((event, index) => (
        <div key={index} className="relative pl-8 sm:pl-12 group">
          {/* Timeline Node */}
          <div className="absolute -left-[22px] top-1.5 w-10 h-10 rounded-full bg-ocean-deep border-4 border-treasure flex items-center justify-center shadow-premium-gilded group-hover:scale-110 transition-transform">
            <Anchor className="w-4 h-4 text-treasure" />
          </div>
          {/* Content Card */}
          <div className="bg-card border-2 border-border rounded-2xl p-6 shadow-paper-lift group-hover:border-treasure transition-colors">
            <span className="inline-block font-mono font-bold text-treasure bg-ocean-deep px-3 py-1 rounded-full text-xs mb-3">
              {event.year}
            </span>
            <h4 className="text-2xl font-cinematic font-bold text-foreground mb-2">{event.title}</h4>
            <p className="text-muted-foreground font-sans text-base leading-relaxed">{event.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

// ============================================================================
// 7. MASONRY GALLERY WITH LIGHTBOX
// ============================================================================

export interface GalleryImage {
  src: string;
  title: string;
  alt: string;
}

export interface GalleryProps {
  images: GalleryImage[];
  className?: string;
}

export const Gallery: React.FC<GalleryProps> = ({ images, className }) => {
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);

  return (
    <div className={cn("w-full", className)}>
      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {images.map((img, index) => (
          <div
            key={index}
            onClick={() => setSelectedImage(img)}
            className="relative h-72 rounded-2xl overflow-hidden border-2 border-border bg-ocean-deep cursor-pointer group shadow-sm hover:border-treasure transition-all duration-300"
          >
            <img src={img.src} alt={img.alt} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
            <div className="absolute inset-0 bg-gradient-to-t from-ocean-deep via-transparent to-transparent opacity-0 group-hover:opacity-90 transition-opacity duration-300 flex items-end p-6">
              <h5 className="font-cinematic text-xl font-bold text-treasure">{img.title}</h5>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {selectedImage && (
          <Dialog isOpen={!!selectedImage} onClose={() => setSelectedImage(null)} title={selectedImage.title} className="max-w-4xl">
            <div className="relative w-full h-[60vh] bg-ocean-deep rounded-xl overflow-hidden mt-4">
              <img src={selectedImage.src} alt={selectedImage.alt} className="w-full h-full object-contain" />
            </div>
          </Dialog>
        )}
      </AnimatePresence>
    </div>
  );
};

// ============================================================================
// 8. HOVER TOOLTIP
// ============================================================================

export interface TooltipProps {
  content: string;
  children: React.ReactNode;
  position?: "top" | "bottom" | "left" | "right";
  className?: string;
}

export const Tooltip: React.FC<TooltipProps> = ({ content, children, position = "top", className }) => {
  const [isVisible, setIsVisible] = useState(false);

  const positionClasses = {
    top: "bottom-full left-1/2 -translate-x-1/2 mb-2",
    bottom: "top-full left-1/2 -translate-x-1/2 mt-2",
    left: "right-full top-1/2 -translate-y-1/2 mr-2",
    right: "left-full top-1/2 -translate-y-1/2 ml-2",
  };

  return (
    <div className="relative inline-block" onMouseEnter={() => setIsVisible(true)} onMouseLeave={() => setIsVisible(false)}>
      {children}
      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.15 }}
            className={cn(
              "absolute z-50 px-3 py-1.5 rounded-lg bg-ocean-deep text-treasure border border-treasure font-cinematic text-xs tracking-wider whitespace-nowrap shadow-premium-ocean pointer-events-none",
              positionClasses[position],
              className
            )}
          >
            {content}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// ============================================================================
// 9. TOAST NOTIFICATION SYSTEM
// ============================================================================

export interface ToastProps {
  message: string;
  type?: "success" | "warning" | "info" | "error";
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, type = "info", onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => onClose(), 5000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const typeConfig = {
    success: { bg: "bg-emerald text-ocean-deep border-ocean-deep", icon: <Check className="w-5 h-5 mr-3" /> },
    warning: { bg: "bg-sunset text-white border-white", icon: <AlertTriangle className="w-5 h-5 mr-3" /> },
    error: { bg: "bg-sunset-crimson text-white border-white", icon: <AlertTriangle className="w-5 h-5 mr-3" /> },
    info: { bg: "bg-ocean-royal text-ocean-foam border-treasure", icon: <Info className="w-5 h-5 mr-3 text-treasure" /> },
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      transition={{ duration: 0.3 }}
      className={cn(
        "fixed bottom-6 right-6 z-50 flex items-center justify-between p-4 rounded-xl border-2 shadow-premium-ocean min-w-[300px] font-sans font-medium",
        typeConfig[type].bg
      )}
    >
      <div className="flex items-center">
        {typeConfig[type].icon}
        <span>{message}</span>
      </div>
      <button onClick={onClose} className="ml-4 opacity-80 hover:opacity-100 transition-opacity">
        <X className="w-5 h-5" />
      </button>
    </motion.div>
  );
};

// ============================================================================
// 10. PREMIUM DIALOG / MODAL
// ============================================================================

export interface DialogProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  className?: string;
}

export const Dialog: React.FC<DialogProps> = ({ isOpen, onClose, title, children, footer, className }) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="absolute inset-0 bg-ocean-deep/80 backdrop-blur-sm"
          />
          {/* Modal Content */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className={cn(
              "relative w-full max-w-2xl rounded-3xl border-4 border-treasure bg-parchment p-6 sm:p-8 shadow-premium-ocean z-10 overflow-hidden",
              className
            )}
          >
            <div className="flex items-center justify-between border-b-2 border-border pb-4 mb-6">
              <h3 className="text-2xl sm:text-3xl font-cinematic font-bold text-foreground tracking-wide">{title}</h3>
              <button onClick={onClose} className="p-2 rounded-full hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="my-4 font-sans text-base text-foreground leading-relaxed">{children}</div>
            {footer && <div className="mt-8 border-t-2 border-border pt-6 flex items-center justify-end space-x-4">{footer}</div>}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
