"use client";

import React, { InputHTMLAttributes, SelectHTMLAttributes, useState } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";
import { HoverRipple } from "@/components/animations/motion";
import { Search, X, ChevronDown, Loader2 } from "lucide-react";

// ============================================================================
// 1. PREMIUM BUTTON COMPONENT
// ============================================================================

const buttonVariants = cva(
  "inline-flex items-center justify-center rounded-lg font-cinematic text-card tracking-wide transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-treasure focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 select-none shadow-sm",
  {
    variants: {
      variant: {
        gilded: "bg-gradient-to-r from-treasure via-treasure-light to-treasure-dark text-ocean-deep hover:shadow-premium-gilded font-bold border border-treasure-light/50",
        wooden: "bg-wooden-plank text-paper hover:border-treasure hover:shadow-paper-lift font-bold",
        royal: "bg-ocean-royal text-ocean-foam hover:bg-ocean-light hover:shadow-premium-ocean border border-ocean-light",
        sunset: "bg-sunset text-white hover:bg-sunset-bright hover:shadow-glowing-bounty font-bold",
        crimson: "bg-sunset-crimson text-white hover:bg-sunset-blood font-bold",
        ghost: "bg-transparent text-foreground hover:bg-muted hover:text-muted-foreground border border-transparent hover:border-border",
      },
      size: {
        default: "h-11 px-6 py-2 text-base",
        sm: "h-9 px-4 py-1.5 text-sm",
        lg: "h-14 px-8 py-3 text-lg font-bold",
        icon: "h-11 w-11 p-2",
      },
      withRipple: {
        true: "",
        false: "",
      },
    },
    defaultVariants: {
      variant: "gilded",
      size: "default",
      withRipple: true,
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  isLoading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    { className, variant, size, withRipple = true, isLoading = false, leftIcon, rightIcon, children, disabled, ...props },
    ref
  ) => {
    const buttonContent = (
      <button
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        disabled={disabled || isLoading}
        {...props}
      >
        {isLoading && <Loader2 className="w-5 h-5 mr-2 animate-spin text-current" />}
        {!isLoading && leftIcon && <span className="mr-2">{leftIcon}</span>}
        {children}
        {!isLoading && rightIcon && <span className="ml-2">{rightIcon}</span>}
      </button>
    );

    if (withRipple && !disabled && !isLoading) {
      return <HoverRipple className="w-full sm:w-auto">{buttonContent}</HoverRipple>;
    }

    return buttonContent;
  }
);
Button.displayName = "Button";

// ============================================================================
// 2. PREMIUM INPUT COMPONENT
// ============================================================================

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  icon?: React.ReactNode;
  errorMessage?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type = "text", icon, errorMessage, ...props }, ref) => {
    return (
      <div className="relative w-full">
        {icon && <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground z-10">{icon}</span>}
        <input
          type={type}
          className={cn(
            "flex h-12 w-full rounded-lg border border-border bg-input px-4 py-2 text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-treasure focus-visible:ring-offset-1 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 transition-all duration-200",
            icon && "pl-11",
            errorMessage && "border-sunset-crimson focus-visible:ring-sunset-crimson",
            className
          )}
          ref={ref}
          {...props}
        />
        {errorMessage && <p className="mt-1 text-xs text-sunset-crimson font-medium">{errorMessage}</p>}
      </div>
    );
  }
);
Input.displayName = "Input";

// ============================================================================
// 3. FEATURE-RICH SEARCH INPUT
// ============================================================================

export interface SearchInputProps extends InputHTMLAttributes<HTMLInputElement> {
  onClear?: () => void;
  isSearching?: boolean;
}

export const SearchInput = React.forwardRef<HTMLInputElement, SearchInputProps>(
  ({ className, onClear, isSearching = false, value, ...props }, ref) => {
    return (
      <div className="relative w-full max-w-lg">
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-treasure z-10">
          {isSearching ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
        </span>
        <input
          type="text"
          value={value}
          className={cn(
            "flex h-12 w-full rounded-full border-2 border-treasure bg-ocean-deep/90 pl-12 pr-12 text-ocean-foam placeholder:text-ocean-foam/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-treasure-light transition-all duration-300 shadow-premium-ocean",
            className
          )}
          ref={ref}
          {...props}
        />
        {value && Boolean(value.toString().length) && onClear && (
          <button
            type="button"
            onClick={onClear}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-ocean-foam/60 hover:text-treasure transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>
    );
  }
);
SearchInput.displayName = "SearchInput";

// ============================================================================
// 4. PREMIUM SELECT COMPONENT
// ============================================================================

export interface SelectOption {
  value: string;
  label: string;
}

export interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  options: SelectOption[];
  placeholder?: string;
}

export const Select = React.forwardRef<HTMLSelectElement, SelectProps>(
  ({ className, options, placeholder, ...props }, ref) => {
    return (
      <div className="relative w-full">
        <select
          className={cn(
            "appearance-none flex h-12 w-full rounded-lg border border-border bg-input px-4 pr-10 py-2 text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-treasure focus-visible:ring-offset-1 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 transition-all duration-200 cursor-pointer",
            className
          )}
          ref={ref}
          {...props}
        >
          {placeholder && (
            <option value="" disabled selected>
              {placeholder}
            </option>
          )}
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" />
      </div>
    );
  }
);
Select.displayName = "Select";

// ============================================================================
// 5. PREMIUM DROPDOWN WRAPPER
// ============================================================================

interface DropdownProps {
  trigger: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}

export const Dropdown: React.FC<DropdownProps> = ({ trigger, children, className }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative inline-block text-left" onMouseEnter={() => setIsOpen(true)} onMouseLeave={() => setIsOpen(false)}>
      <div>{trigger}</div>
      {isOpen && (
        <div className={cn("absolute right-0 mt-2 w-64 rounded-xl bg-ocean-deep border-2 border-treasure shadow-premium-ocean p-4 z-50 animate-accordion-down", className)}>
          {children}
        </div>
      )}
    </div>
  );
};

// ============================================================================
// 6. PREMIUM FACTION & STATUS BADGE
// ============================================================================

const badgeVariants = cva(
  "inline-flex items-center rounded-full px-3 py-1 text-xs font-bold font-cinematic uppercase tracking-wider transition-colors select-none shadow-sm",
  {
    variants: {
      variant: {
        pirate: "bg-wood text-treasure border border-treasure",
        marine: "bg-ocean-royal text-ocean-foam border border-ocean-foam",
        yonko: "bg-sunset-crimson text-treasure border border-treasure shadow-glowing-bounty",
        revs: "bg-sunset text-paper border border-paper",
        crossguild: "bg-emerald text-ocean-deep border border-ocean-deep",
        bounty: "bg-treasure text-ocean-deep border border-wood font-mono tracking-widest",
        active: "bg-emerald-dark text-white",
        unknown: "bg-muted text-muted-foreground",
      },
    },
    defaultVariants: {
      variant: "pirate",
    },
  }
);

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {}

export const Badge: React.FC<BadgeProps> = ({ className, variant, children, ...props }) => {
  return (
    <div className={cn(badgeVariants({ variant }), className)} {...props}>
      {children}
    </div>
  );
};

// ============================================================================
// 7. PREMIUM AVATAR COMPONENT
// ============================================================================

export interface AvatarProps {
  src: string;
  alt: string;
  size?: "sm" | "md" | "lg" | "xl";
  level?: number;
  faction?: "pirate" | "marine" | "yonko" | "revs" | "crossguild";
  className?: string;
}

export const Avatar: React.FC<AvatarProps> = ({ src, alt, size = "md", level, faction, className }) => {
  const sizeClasses = {
    sm: "w-10 h-10",
    md: "w-14 h-14",
    lg: "w-20 h-20",
    xl: "w-32 h-32",
  };

  const borderClasses = {
    pirate: "border-treasure",
    marine: "border-ocean-foam",
    yonko: "border-sunset-crimson",
    revs: "border-sunset",
    crossguild: "border-emerald",
    default: "border-border",
  };

  return (
    <div className={cn("relative inline-block", className)}>
      <div
        className={cn(
          "relative rounded-full overflow-hidden border-2 bg-ocean-deep shadow-premium-ocean transition-transform duration-300 hover:scale-105",
          sizeClasses[size],
          faction ? borderClasses[faction] : borderClasses.default
        )}
      >
        <img src={src} alt={alt} className="w-full h-full object-cover" />
      </div>
      {level !== undefined && (
        <span className="absolute -bottom-1 -right-1 flex items-center justify-center bg-treasure text-ocean-deep text-xs font-bold font-mono px-2 py-0.5 rounded-full border border-ocean-deep shadow-sm">
          Lv.{level}
        </span>
      )}
    </div>
  );
};
