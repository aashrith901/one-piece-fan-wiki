"use client";

import React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/buttons";
import { Compass, AlertTriangle, HelpCircle, Anchor } from "lucide-react";

// ============================================================================
// 1. PREMIUM LOADING SCREEN & SPINNER
// ============================================================================

export interface LoadingScreenProps {
  text?: string;
  className?: string;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ text = "Sailing the Grand Line...", className }) => {
  return (
    <div className={cn("flex flex-col items-center justify-center min-h-[400px] w-full p-8 select-none", className)}>
      <div className="relative w-32 h-32 flex items-center justify-center mb-6">
        {/* Outer Ship Steering Wheel Animation */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 8, ease: "linear" }}
          className="absolute inset-0 rounded-full border-4 border-dashed border-treasure"
        />
        {/* Inner Compass Spinning Needle */}
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
          className="absolute inset-4 rounded-full border-2 border-treasure-light/50 flex items-center justify-center"
        >
          <Compass className="w-12 h-12 text-treasure animate-pulse" />
        </motion.div>
      </div>
      <h3 className="text-2xl font-cinematic font-bold text-foreground tracking-wider gold-foil-text animate-pulse">
        {text}
      </h3>
      <p className="mt-2 text-sm text-muted-foreground font-sans italic">Hold fast, the New World awaits...</p>
    </div>
  );
};

// ============================================================================
// 2. SKELETON LOADER (CARDS & UI)
// ============================================================================

export interface SkeletonLoaderProps {
  type?: "card" | "avatar" | "text" | "table";
  count?: number;
  className?: string;
}

export const SkeletonLoader: React.FC<SkeletonLoaderProps> = ({ type = "card", count = 1, className }) => {
  const items = Array.from({ length: count }, (_, i) => i);

  if (type === "avatar") {
    return (
      <div className="flex space-x-4">
        {items.map((i) => (
          <div key={i} className={cn("w-14 h-14 rounded-full bg-muted animate-pulse", className)} />
        ))}
      </div>
    );
  }

  if (type === "text") {
    return (
      <div className="space-y-3 w-full">
        {items.map((i) => (
          <div key={i} className={cn("h-4 bg-muted rounded-md animate-pulse w-full", className)} />
        ))}
      </div>
    );
  }

  if (type === "table") {
    return (
      <div className={cn("w-full rounded-2xl border-2 border-border bg-card p-6 space-y-4", className)}>
        <div className="h-10 bg-muted rounded-xl animate-pulse w-full mb-6" />
        {items.map((i) => (
          <div key={i} className="h-12 bg-muted/60 rounded-lg animate-pulse w-full" />
        ))}
      </div>
    );
  }

  // Default Card Skeleton
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 w-full">
      {items.map((i) => (
        <div key={i} className={cn("w-full h-[450px] rounded-2xl border-2 border-border bg-card overflow-hidden animate-pulse p-6 flex flex-col justify-between", className)}>
          <div className="w-full h-60 bg-muted rounded-xl mb-6" />
          <div className="space-y-4 w-full">
            <div className="h-6 bg-muted rounded-md w-3/4" />
            <div className="h-4 bg-muted rounded-md w-1/2" />
          </div>
          <div className="h-10 bg-muted rounded-xl w-full mt-6" />
        </div>
      ))}
    </div>
  );
};

// ============================================================================
// 3. ERROR COMPONENT (BUSTER CALL ALARM)
// ============================================================================

export interface ErrorComponentProps {
  title?: string;
  message?: string;
  onRetry?: () => void;
  className?: string;
}

export const ErrorComponent: React.FC<ErrorComponentProps> = ({
  title = "BUSTER CALL INITIATED!",
  message = "A severe communication breakdown has occurred with the Marine Headquarters. The den den mushi waves are jammed.",
  onRetry,
  className,
}) => {
  return (
    <div className={cn("flex flex-col items-center justify-center min-h-[450px] w-full p-8 max-w-2xl mx-auto text-center select-none", className)}>
      <motion.div
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="w-24 h-24 rounded-full bg-sunset-crimson/10 border-4 border-sunset-crimson flex items-center justify-center mb-6 shadow-glowing-bounty"
      >
        <AlertTriangle className="w-12 h-12 text-sunset-crimson" />
      </motion.div>
      <h3 className="text-3xl font-cinematic font-bold text-sunset-crimson tracking-wider mb-3">
        {title}
      </h3>
      <p className="text-base font-sans text-muted-foreground leading-relaxed mb-8 max-w-lg">
        {message}
      </p>
      {onRetry && (
        <Button variant="crimson" size="lg" onClick={onRetry} leftIcon={<Anchor className="w-5 h-5" />}>
          RETRY TRANSMISSION
        </Button>
      )}
    </div>
  );
};

// ============================================================================
// 4. EMPTY STATE CONTAINER
// ============================================================================

export interface EmptyStateProps {
  title?: string;
  message?: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  title = "NO TREASURE FOUND",
  message = "It appears this island is completely deserted. Neither pirates nor marines have left any logs here.",
  actionLabel,
  onAction,
  className,
}) => {
  return (
    <div className={cn("flex flex-col items-center justify-center min-h-[400px] w-full p-8 max-w-lg mx-auto text-center select-none", className)}>
      <div className="w-24 h-24 rounded-full bg-ocean-deep border-2 border-treasure flex items-center justify-center mb-6 shadow-premium-ocean">
        <HelpCircle className="w-12 h-12 text-treasure animate-bounce" />
      </div>
      <h4 className="text-2xl font-cinematic font-bold text-foreground tracking-wide mb-2">{title}</h4>
      <p className="text-base font-sans text-muted-foreground leading-relaxed mb-8">{message}</p>
      {actionLabel && onAction && (
        <Button variant="gilded" size="default" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </div>
  );
};

// ============================================================================
// 5. 404 NOT FOUND (ZORO LOST MEME)
// ============================================================================

export interface NotFoundComponentProps {
  onBack?: () => void;
  className?: string;
}

export const NotFoundComponent: React.FC<NotFoundComponentProps> = ({ onBack, className }) => {
  return (
    <div className={cn("flex flex-col items-center justify-center min-h-[600px] w-full p-8 max-w-2xl mx-auto text-center select-none", className)}>
      <div className="relative w-40 h-40 rounded-full bg-emerald-dark/10 border-4 border-emerald flex items-center justify-center mb-8 shadow-sm">
        <Compass className="w-20 h-20 text-emerald animate-spin" />
      </div>
      <h2 className="text-4xl sm:text-5xl font-cinematic font-bold text-foreground tracking-wider mb-4">
        YOU PULL A ZORO! (404)
      </h2>
      <p className="text-lg font-sans text-muted-foreground leading-relaxed mb-10 max-w-lg">
        How did you even get here? You've strayed entirely off the Log Pose navigation chart. This section of the Grand Line doesn't exist!
      </p>
      {onBack && (
        <Button variant="wooden" size="lg" onClick={onBack}>
          NAVIGATE BACK TO SAFETY
        </Button>
      )}
    </div>
  );
};
