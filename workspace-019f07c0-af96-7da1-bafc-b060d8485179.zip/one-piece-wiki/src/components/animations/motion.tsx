"use client";

import React, { useEffect, useRef, useState } from "react";
import { motion, useMotionValue, useSpring, useTransform, useScroll, AnimatePresence } from "framer-motion";
import gsap from "gsap";
import { cn } from "@/lib/utils";

// ============================================================================
// 1. PAGE TRANSITION WRAPPER
// ============================================================================

interface PageTransitionProps {
  children: React.ReactNode;
  className?: string;
}

export const PageTransition: React.FC<PageTransitionProps> = ({ children, className }) => {
  return (
    <AnimatePresence mode="wait">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className={cn("w-full h-full", className)}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
};

// ============================================================================
// 2. PARALLAX SCROLL CONTAINER
// ============================================================================

interface ParallaxScrollProps {
  children: React.ReactNode;
  speed?: number; // e.g., 0.5 for half speed, 2 for double speed
  className?: string;
}

export const ParallaxScroll: React.FC<ParallaxScrollProps> = ({ children, speed = 0.5, className }) => {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["0%", `${speed * 100}%`]);

  return (
    <div ref={ref} className={cn("relative overflow-hidden w-full", className)}>
      <motion.div style={{ y }} className="w-full h-full">
        {children}
      </motion.div>
    </div>
  );
};

// ============================================================================
// 3. FADE REVEAL ON SCROLL
// ============================================================================

interface FadeRevealProps {
  children: React.ReactNode;
  delay?: number;
  duration?: number;
  className?: string;
}

export const FadeReveal: React.FC<FadeRevealProps> = ({ children, delay = 0, duration = 0.6, className }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ delay, duration, ease: "easeOut" }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

// ============================================================================
// 4. SLIDE REVEAL ON SCROLL
// ============================================================================

interface SlideRevealProps {
  children: React.ReactNode;
  direction?: "left" | "right" | "top" | "bottom";
  delay?: number;
  duration?: number;
  className?: string;
}

export const SlideReveal: React.FC<SlideRevealProps> = ({
  children,
  direction = "bottom",
  delay = 0,
  duration = 0.6,
  className,
}) => {
  const getInitialCoords = () => {
    switch (direction) {
      case "left": return { x: -50, y: 0 };
      case "right": return { x: 50, y: 0 };
      case "top": return { x: 0, y: -50 };
      case "bottom": return { x: 0, y: 50 };
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, ...getInitialCoords() }}
      whileInView={{ opacity: 1, x: 0, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ delay, duration, ease: [0.16, 1, 0.3, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

// ============================================================================
// 5. SCALE POP REVEAL
// ============================================================================

interface ScaleRevealProps {
  children: React.ReactNode;
  delay?: number;
  duration?: number;
  className?: string;
}

export const ScaleReveal: React.FC<ScaleRevealProps> = ({ children, delay = 0, duration = 0.5, className }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.85 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ delay, duration, ease: [0.17, 0.67, 0.83, 0.67] }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

// ============================================================================
// 6. FLOATING ELEMENT (OCEAN WAVE HOVER)
// ============================================================================

interface FloatingElementProps {
  children: React.ReactNode;
  yOffset?: number;
  duration?: number;
  className?: string;
}

export const FloatingElement: React.FC<FloatingElementProps> = ({
  children,
  yOffset = 12,
  duration = 5,
  className,
}) => {
  return (
    <motion.div
      animate={{ y: [0, -yOffset, 0] }}
      transition={{ repeat: Infinity, duration, ease: "easeInOut" }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

// ============================================================================
// 7. HOVER RIPPLE EFFECT WRAPPER
// ============================================================================

interface HoverRippleProps {
  children: React.ReactNode;
  className?: string;
}

export const HoverRipple: React.FC<HoverRippleProps> = ({ children, className }) => {
  const [ripples, setRipples] = useState<{ x: number; y: number; id: number }[]>([]);

  const addRipple = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = Date.now();
    setRipples((prev) => [...prev, { x, y, id }]);
  };

  return (
    <div
      onClick={addRipple}
      className={cn("relative overflow-hidden cursor-pointer select-none inline-block", className)}
    >
      {children}
      <AnimatePresence>
        {ripples.map((r) => (
          <motion.span
            key={r.id}
            initial={{ top: r.y, left: r.x, scale: 0, opacity: 0.5 }}
            animate={{ scale: 25, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            onAnimationComplete={() => setRipples((prev) => prev.filter((item) => item.id !== r.id))}
            className="absolute bg-treasure/30 rounded-full w-4 h-4 pointer-events-none -translate-x-1/2 -translate-y-1/2"
          />
        ))}
      </AnimatePresence>
    </div>
  );
};

// ============================================================================
// 8. CARD TILT 3D WRAPPER
// ============================================================================

interface CardTiltProps {
  children: React.ReactNode;
  maxTilt?: number;
  className?: string;
}

export const CardTilt: React.FC<CardTiltProps> = ({ children, maxTilt = 15, className }) => {
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const springConfig = { damping: 20, stiffness: 300 };
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [maxTilt, -maxTilt]), springConfig);
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-maxTilt, maxTilt]), springConfig);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={cn("relative perspective-1000", className)}
    >
      <div style={{ transform: "translateZ(30px)" }} className="w-full h-full">
        {children}
      </div>
    </motion.div>
  );
};

// ============================================================================
// 9. IMAGE REVEAL CURTAIN
// ============================================================================

interface ImageRevealProps {
  src: string;
  alt: string;
  className?: string;
  imageClassName?: string;
}

export const ImageReveal: React.FC<ImageRevealProps> = ({ src, alt, className, imageClassName }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={cn("relative overflow-hidden bg-ocean-deep", className)}>
      <motion.div
        initial={{ y: "0%" }}
        animate={{ y: loaded ? "100%" : "0%" }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="absolute inset-0 bg-treasure z-10 pointer-events-none"
      />
      <img
        src={src}
        alt={alt}
        onLoad={() => setLoaded(true)}
        className={cn("w-full h-full object-cover transition-transform duration-700 hover:scale-105", imageClassName)}
      />
    </div>
  );
};

// ============================================================================
// 10. ANIMATED COUNTER (BOUNTY & STATS)
// ============================================================================

interface AnimatedCounterProps {
  value: number;
  prefix?: string;
  suffix?: string;
  duration?: number;
  className?: string;
}

export const AnimatedCounter: React.FC<AnimatedCounterProps> = ({
  value,
  prefix = "",
  suffix = "",
  duration = 2,
  className,
}) => {
  const [displayValue, setDisplayValue] = useState("0");
  const countRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const obj = { val: 0 };
    const targetVal = value;
    
    gsap.to(obj, {
      val: targetVal,
      duration,
      ease: "power2.out",
      onUpdate: () => {
        setDisplayValue(Math.floor(obj.val).toLocaleString("en-US"));
      },
    });
  }, [value, duration]);

  return (
    <span ref={countRef} className={cn("font-mono font-bold tracking-wider", className)}>
      {prefix}{displayValue}{suffix}
    </span>
  );
};
