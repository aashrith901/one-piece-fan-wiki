"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/buttons";
import { SkeletonLoader } from "@/components/ui/feedback";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { Calendar, Clock, Bookmark, Share2, MessageCircle, RefreshCw, Tag, User, ThumbsUp, MessageSquare } from "lucide-react";

// ============================================================================
// NEWS ARTICLE VIEW
// ============================================================================

export interface NewsArticleViewProps {
  articleSlug?: string;
}

export default function NewsArticleView({ articleSlug = "vegapunk-broadcast-climax" }: NewsArticleViewProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [article, setArticle] = useState<any | null>(null);
  const [savedBookmarks, setSavedBookmarks] = useState<string[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Community Comments States
  const [commentsList, setCommentsList] = useState([
    { id: 1, author: "Monkey D. Luffy", avatar: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=400&auto=format&fit=crop", content: "VEGAPUNK IS SO AWESOME! What does he mean the world is sinking?! Does that mean more ocean for the Sunny to sail?!", upvotes: 245, time: "2 hours ago" },
    { id: 2, author: "Nico Robin", avatar: "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?q=80&w=400&auto=format&fit=crop", content: "This completely confirms the theories from the Ohara scholars regarding the Void Century. The ancient weapons weren't just warships; they altered the sea level of the entire globe.", upvotes: 412, time: "3 hours ago" },
    { id: 3, author: "Sir Crocodile", avatar: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=400&auto=format&fit=crop", content: "If the world sinks, land becomes the ultimate premium commodity. The Cross Guild will need to secure elevated territory immediately.", upvotes: 189, time: "5 hours ago" },
  ]);
  const [newCommentText, setNewCommentText] = useState("");

  useEffect(() => {
    // Fetch article from news API
    fetch(`/api/news?slug=${encodeURIComponent(articleSlug)}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.success) setArticle(data.data);
      })
      .catch((err) => console.error("Article fetch error:", err));

    const bms = localStorage.getItem("one_piece_news_bookmarks");
    if (bms) setSavedBookmarks(JSON.parse(bms));
  }, [articleSlug]);

  const toggleBookmark = () => {
    if (!article) return;
    let nextBms = [...savedBookmarks];
    if (nextBms.includes(article.slug)) {
      nextBms = nextBms.filter((b) => b !== article.slug);
      setToastMessage("Removed article from your private reading vault.");
    } else {
      nextBms.push(article.slug);
      setToastMessage("Bookmarked article! Synced with your personal Reading Tracker.");
    }
    setSavedBookmarks(nextBms);
    localStorage.setItem("one_piece_news_bookmarks", JSON.stringify(nextBms));
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;
    const nextCom = {
      id: Date.now(),
      author: "Super Fan Admiral",
      avatar: "https://images.unsplash.com/photo-1528164344705-475426879c01?q=80&w=400&auto=format&fit=crop",
      content: newCommentText.trim(),
      upvotes: 1,
      time: "Just now",
    };
    setCommentsList([nextCom, ...commentsList]);
    setNewCommentText("");
    setToastMessage("Broadcasted your transponder snail comment to the community!");
  };

  if (!article) {
    return <SkeletonLoader count={3} className="min-h-screen p-12 max-w-4xl mx-auto" />;
  }

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* Toast Notification Popup */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 bg-ocean-royal text-ocean-foam border-2 border-treasure p-6 rounded-2xl shadow-premium-ocean flex items-center space-x-4 max-w-sm"
          >
            <span className="font-sans text-sm font-medium">{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="text-xs text-treasure hover:underline">Close</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================================================================ */}
      {/* HEADER HERO SECTION */}
      {/* ============================================================================ */}
      <div className="relative w-full min-h-[60vh] bg-ocean-deep overflow-hidden flex items-end pb-16 select-none">
        <img src={article.coverImageUrl} alt={article.title} className="absolute inset-0 w-full h-full object-cover opacity-40 object-center" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-ocean-deep/60 to-transparent" />
        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 w-full space-y-6 pt-24">
          <Breadcrumbs
            items={[
              { label: "Grand Line Wiki", href: "/" },
              { label: "News Hub", href: "/news" },
              { label: article.category },
            ]}
          />
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <span className="bg-wood text-treasure border border-treasure px-4 py-1.5 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase shadow-sm">
                {article.category}
              </span>
              <span className="flex items-center text-xs font-mono text-ocean-foam/80">
                <Clock className="w-3.5 h-3.5 mr-1.5 text-treasure" /> {article.readingTime}
              </span>
              <span className="flex items-center text-xs font-mono text-ocean-foam/80">
                <Calendar className="w-3.5 h-3.5 mr-1.5 text-treasure" /> {new Date(article.publishedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
              </span>
            </div>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-cinematic font-bold text-ocean-foam tracking-wider gold-foil-text leading-tight">
              {article.title}
            </h1>
            <div className="flex items-center justify-between border-t border-ocean-royal pt-6">
              <div className="flex items-center space-x-4">
                <img src={article.author.image} alt={article.author.name} className="w-12 h-12 rounded-full object-cover border-2 border-treasure" />
                <div>
                  <span className="font-cinematic text-base font-bold text-treasure block">{article.author.name}</span>
                  <span className="font-sans text-xs text-ocean-foam/70 italic block">Senior Grand Line Journalist</span>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={toggleBookmark}
                  className="p-3 rounded-full bg-ocean-royal text-ocean-foam hover:text-treasure hover:border-treasure border border-transparent transition-all shadow-sm"
                >
                  <Bookmark className={cn("w-5 h-5", savedBookmarks.includes(article.slug) ? "fill-current text-treasure" : "")} />
                </button>
                <button
                  onClick={() => { navigator.clipboard.writeText(window.location.href); setToastMessage("Link copied to clipboard!"); }}
                  className="p-3 rounded-full bg-ocean-royal text-ocean-foam hover:text-treasure hover:border-treasure border border-transparent transition-all shadow-sm"
                >
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================ */}
      {/* MAIN ARTICLE BODY & CONTENT */}
      {/* ============================================================================ */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <TreasureMapContainer className="space-y-8">
          <p className="font-sans text-xl text-foreground leading-relaxed font-bold italic border-l-4 border-treasure pl-6 py-2 bg-card/50 rounded-r-2xl">
            {article.excerpt}
          </p>
          <div className="font-sans text-lg text-foreground leading-relaxed space-y-6 pt-4 border-t border-border">
            <p>{article.content}</p>
          </div>
          <div className="flex flex-wrap gap-2 pt-8 border-t border-border">
            {article.tags.map((tag: string, idx: number) => (
              <span key={idx} className="flex items-center text-xs font-mono bg-card text-foreground px-3 py-1.5 rounded-xl border border-border shadow-sm">
                <Tag className="w-3.5 h-3.5 mr-1.5 text-treasure" /> {tag}
              </span>
            ))}
          </div>
        </TreasureMapContainer>

        {/* ============================================================================ */}
        {/* COMMUNITY COMMENTS THREAD */}
        {/* ============================================================================ */}
        <div className="mt-16 space-y-12">
          <div className="bg-wooden-plank border-4 border-treasure rounded-3xl p-8 sm:p-12 shadow-premium-ocean text-paper space-y-8">
            <div className="flex items-center justify-between border-b border-treasure/30 pb-4">
              <h4 className="text-3xl font-cinematic font-bold text-treasure flex items-center">
                <MessageSquare className="w-8 h-8 mr-3 text-treasure" /> DEN DEN MUSHI CHATROOM ({commentsList.length})
              </h4>
              <span className="font-mono text-xs text-paper/80">COMMUNITY FLEET</span>
            </div>

            {/* Submit Comment Form */}
            <form onSubmit={handleAddComment} className="space-y-4">
              <textarea
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                placeholder="Broadcast your thoughts, theories, or reactions to the community..."
                rows={4}
                className="w-full rounded-2xl bg-ocean-deep border-2 border-treasure p-4 text-ocean-foam placeholder:text-ocean-foam/60 focus:outline-none focus:ring-2 focus:ring-treasure-light font-sans text-base shadow-inner"
              />
              <div className="flex justify-end">
                <Button variant="gilded" size="default" type="submit">
                  BROADCAST TRANSMISSION
                </Button>
              </div>
            </form>

            {/* Comments List */}
            <div className="space-y-6 pt-6 border-t border-treasure/20">
              {commentsList.map((com) => (
                <div key={com.id} className="bg-ocean-deep border-2 border-ocean-royal rounded-2xl p-6 shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <img src={com.avatar} alt={com.author} className="w-12 h-12 rounded-full object-cover border-2 border-treasure shadow-sm" />
                      <div>
                        <span className="font-cinematic text-lg font-bold text-treasure block">{com.author}</span>
                        <span className="font-mono text-xs text-ocean-foam/60 block">{com.time}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => { com.upvotes += 1; setToastMessage("Upvoted comment!"); }}
                      className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-ocean-royal text-ocean-foam hover:border-treasure border border-transparent transition-all shadow-sm font-mono text-xs"
                    >
                      <ThumbsUp className="w-4 h-4 text-treasure" />
                      <span>{com.upvotes}</span>
                    </button>
                  </div>
                  <p className="font-sans text-base text-ocean-foam/90 leading-relaxed font-medium">{com.content}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
