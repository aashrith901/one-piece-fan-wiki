"use client";

import React, { useState, useEffect, useTransition } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, SearchInput, Select, Badge } from "@/components/ui/buttons";
import { SkeletonLoader, EmptyState } from "@/components/ui/feedback";
import { RopeBorder, AnchorDecoration, WaveSeparator, TreasureMapContainer, WoodenPanel, GlassPanel } from "@/components/decorations/maritime";
import { PremiumNavbar, MobileNavbar, SearchOverlay, ScrollIndicator, Footer, Breadcrumbs, SectionHeader } from "@/components/navigation/navigation-system";
import { Search, Flame, Calendar, Clock, Bookmark, Share2, MessageCircle, RefreshCw, AlertTriangle, ArrowRight, Tag, BookmarkCheck } from "lucide-react";

// ============================================================================
// NEWS HUB DASHBOARD
// ============================================================================

export default function NewsIndex() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [newsList, setNewsList] = useState<any[]>([]);
  const [featuredNews, setFeaturedNews] = useState<any | null>(null);
  const [breakingNews, setBreakingNews] = useState<any[]>([]);
  const [isPending, startTransition] = useTransition();
  const [savedBookmarks, setSavedBookmarks] = useState<string[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const categories = [
    { label: "All Dispatches", value: "all" },
    { label: "Anime News", value: "Anime News" },
    { label: "Manga News", value: "Manga News" },
    { label: "Movies & Live Action", value: "Movies & Live Action" },
    { label: "Video Games", value: "Games" },
    { label: "Official Merchandise", value: "Merchandise" },
    { label: "Official Events", value: "Official Events" },
    { label: "Live Events", value: "Live Events" },
    { label: "Collaborations", value: "Collaborations" },
    { label: "Community News", value: "Community News" },
  ];

  useEffect(() => {
    startTransition(async () => {
      try {
        const res = await fetch(`/api/news?q=${encodeURIComponent(query)}&category=${encodeURIComponent(category)}`);
        const data = await res.json();
        if (data.success) {
          setNewsList(data.data);
          if (data.featured && data.featured.length > 0) setFeaturedNews(data.featured[0]);
          if (data.breaking) setBreakingNews(data.breaking);
        }
      } catch (err) {
        console.error("News fetch error:", err);
      }
    });

    // Load Bookmarks from localStorage
    const bms = localStorage.getItem("one_piece_news_bookmarks");
    if (bms) setSavedBookmarks(JSON.parse(bms));
  }, [query, category]);

  const toggleBookmark = (slug: string, e: React.MouseEvent) => {
    e.stopPropagation();
    let nextBms = [...savedBookmarks];
    if (nextBms.includes(slug)) {
      nextBms = nextBms.filter((b) => b !== slug);
      setToastMessage("Removed article from your private reading vault.");
    } else {
      nextBms.push(slug);
      setToastMessage("Bookmarked article! Synced with your personal Reading Tracker.");
    }
    setSavedBookmarks(nextBms);
    localStorage.setItem("one_piece_news_bookmarks", JSON.stringify(nextBms));
  };

  return (
    <div className="relative w-full min-h-screen bg-background overflow-x-hidden selection:bg-treasure selection:text-ocean-deep">
      <PremiumNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <MobileNavbar onOpenSearch={() => setIsSearchOpen(true)} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <ScrollIndicator />

      {/* Toast Notification Popup */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 bg-ocean-royal text-ocean-foam border-2 border-treasure p-6 rounded-2xl shadow-premium-ocean flex items-center space-x-4 max-w-sm"
          >
            <BookmarkCheck className="w-6 h-6 text-treasure flex-shrink-0" />
            <span className="font-sans text-sm font-medium">{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="text-xs text-treasure hover:underline">Close</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================================================================ */}
      {/* 1. BREAKING NEWS TICKER */}
      {/* ============================================================================ */}
      {breakingNews.length > 0 && (
        <div className="w-full bg-sunset-crimson text-white border-y-2 border-treasure py-3 px-4 sm:px-8 select-none shadow-glowing-bounty z-20 relative overflow-hidden">
          <div className="max-w-7xl mx-auto flex items-center space-x-4">
            <div className="flex items-center space-x-2 bg-ocean-deep text-treasure px-3 py-1 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase border border-treasure shadow-sm flex-shrink-0">
              <AlertTriangle className="w-4 h-4 mr-1 text-sunset animate-pulse" /> BREAKING NEWS
            </div>
            <div className="flex-grow overflow-hidden whitespace-nowrap">
              <motion.div
                animate={{ x: ["0%", "-50%"] }}
                transition={{ repeat: Infinity, duration: 25, ease: "linear" }}
                className="inline-flex space-x-12 font-cinematic text-sm sm:text-base font-bold tracking-wide"
              >
                {breakingNews.concat(breakingNews).map((n, i) => (
                  <span key={i} onClick={() => (window.location.href = `/news/${n.slug}`)} className="cursor-pointer hover:text-treasure-light transition-colors">
                    🚨 {n.title} — <span className="font-sans font-normal italic text-xs text-white/80">{n.excerpt}</span>
                  </span>
                ))}
              </motion.div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================================ */}
      {/* 2. FEATURED NEWS BANNER */}
      {/* ============================================================================ */}
      {featuredNews && (
        <div
          onClick={() => (window.location.href = `/news/${featuredNews.slug}`)}
          className="relative w-full h-[60vh] sm:h-[70vh] bg-ocean-deep overflow-hidden flex items-end cursor-pointer group select-none"
        >
          <img src={featuredNews.coverImageUrl} alt={featuredNews.title} className="absolute inset-0 w-full h-full object-cover opacity-50 transition-transform duration-1000 group-hover:scale-105" />
          <div className="absolute inset-0 bg-gradient-to-t from-ocean-deep via-ocean-deep/60 to-transparent" />
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pb-16 space-y-6">
            <div className="flex items-center space-x-4">
              <span className="bg-wood text-treasure border border-treasure px-4 py-1.5 rounded-full text-xs font-cinematic font-bold tracking-widest uppercase shadow-sm">
                {featuredNews.category}
              </span>
              <span className="flex items-center text-xs font-mono text-ocean-foam/80">
                <Clock className="w-3.5 h-3.5 mr-1.5 text-treasure" /> {featuredNews.readingTime}
              </span>
            </div>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-cinematic font-bold text-ocean-foam tracking-wider group-hover:text-treasure transition-colors leading-tight max-w-4xl">
              {featuredNews.title}
            </h1>
            <p className="text-base sm:text-xl font-sans text-ocean-foam/90 max-w-3xl leading-relaxed font-medium">
              {featuredNews.excerpt}
            </p>
            <div className="flex items-center justify-between max-w-4xl border-t border-ocean-royal pt-6">
              <div className="flex items-center space-x-3">
                <img src={featuredNews.author.image} alt={featuredNews.author.name} className="w-10 h-10 rounded-full object-cover border border-treasure" />
                <span className="font-cinematic text-sm font-bold text-treasure">{featuredNews.author.name}</span>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={(e) => toggleBookmark(featuredNews.slug, e)}
                  className="p-3 rounded-full bg-ocean-royal text-ocean-foam hover:text-treasure hover:border-treasure border border-transparent transition-all shadow-sm"
                >
                  <Bookmark className={cn("w-5 h-5", savedBookmarks.includes(featuredNews.slug) ? "fill-current text-treasure" : "")} />
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(window.location.origin + `/news/${featuredNews.slug}`); setToastMessage("Link copied to clipboard!"); }}
                  className="p-3 rounded-full bg-ocean-royal text-ocean-foam hover:text-treasure hover:border-treasure border border-transparent transition-all shadow-sm"
                >
                  <Share2 className="w-5 h-5" />
                </button>
                <span className="hidden sm:flex items-center font-cinematic text-xs font-bold text-ocean-foam/80 bg-ocean-royal px-4 py-2 rounded-xl">
                  <MessageCircle className="w-4 h-4 mr-2 text-treasure" /> {featuredNews.commentsCount} COMMENTS
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================================ */}
      {/* 3. NEWS DASHBOARD SEARCH & FILTERS */}
      {/* ============================================================================ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 select-none">
        <TreasureMapContainer className="mb-12">
          <div className="space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <h3 className="text-3xl font-cinematic font-bold text-foreground tracking-wide">GRAND LINE NEWS PRESS</h3>
                <p className="text-base font-sans text-muted-foreground mt-1">Read breaking dispatches, editorial reviews, and live action set updates.</p>
              </div>
            </div>

            <div className="relative w-full">
              <SearchInput
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onClear={() => setQuery("")}
                placeholder="Search news dispatches by headline, keyword, or tag... (e.g. 'Vegapunk', 'Netflix', 'Soundtrack')"
                className="max-w-full text-xl h-16 bg-ocean-deep text-ocean-foam border-2 border-treasure shadow-premium-ocean"
                isSearching={isPending}
              />
            </div>

            {/* Category Filter Buttons */}
            <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
              {categories.map((cat) => (
                <button
                  key={cat.value}
                  onClick={() => setCategory(cat.value)}
                  className={cn(
                    "px-4 py-2 rounded-xl font-cinematic text-sm font-bold tracking-wider whitespace-nowrap transition-all shadow-sm border flex-shrink-0",
                    category === cat.value
                      ? "bg-treasure text-ocean-deep border-treasure shadow-premium-gilded"
                      : "bg-card text-foreground border-border hover:border-treasure"
                  )}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>
        </TreasureMapContainer>

        {/* ============================================================================ */}
        {/* 4. NEWS ARTICLES GRID */}
        {/* ============================================================================ */}
        <div className="mt-12">
          {isPending && newsList.length === 0 ? (
            <SkeletonLoader count={6} />
          ) : newsList.length === 0 ? (
            <EmptyState title="NO DISPATCHES MATCH YOUR ENQUIRY" message="No news articles match your active filter tags or search phrasing. Adjust your search parameters." />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {newsList.map((news) => (
                <div
                  key={news.id}
                  onClick={() => (window.location.href = `/news/${news.slug}`)}
                  className="cursor-pointer overflow-hidden rounded-2xl border border-border bg-card shadow-paper-lift transition-all duration-300 hover:translate-y-[-4px] hover:border-treasure hover:shadow-premium-gilded group flex flex-col justify-between"
                >
                  <div className="relative h-60 w-full overflow-hidden bg-wood">
                    <img src={news.coverImageUrl} alt={news.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-ocean-deep via-transparent to-transparent opacity-60" />
                    <span className="absolute top-4 left-4 bg-ocean-deep text-treasure border border-treasure px-3 py-1 rounded-full text-xs font-cinematic font-bold tracking-wider uppercase shadow-sm">
                      {news.category}
                    </span>
                    <button
                      onClick={(e) => toggleBookmark(news.slug, e)}
                      className="absolute top-4 right-4 p-2 rounded-full bg-ocean-deep text-ocean-foam hover:text-treasure border border-treasure shadow-sm transition-all"
                    >
                      <Bookmark className={cn("w-4 h-4", savedBookmarks.includes(news.slug) ? "fill-current text-treasure" : "")} />
                    </button>
                  </div>
                  <div className="p-6 flex flex-col flex-grow justify-between">
                    <div>
                      <div className="flex items-center space-x-4 text-xs font-mono text-muted-foreground mb-3">
                        <span className="flex items-center"><Calendar className="w-3.5 h-3.5 mr-1 text-treasure" /> {new Date(news.publishedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
                        <span className="flex items-center"><Clock className="w-3.5 h-3.5 mr-1 text-treasure" /> {news.readingTime}</span>
                      </div>
                      <h4 className="text-2xl font-cinematic font-bold text-foreground group-hover:text-treasure-dark transition-colors tracking-wide line-clamp-2">
                        {news.title}
                      </h4>
                      <p className="mt-2 text-sm font-sans text-muted-foreground line-clamp-3 leading-relaxed">
                        {news.excerpt}
                      </p>
                    </div>
                    <div>
                      <div className="flex flex-wrap gap-1.5 my-4">
                        {news.tags.map((tag: string, idx: number) => (
                          <span key={idx} className="flex items-center text-[10px] font-mono bg-muted text-muted-foreground px-2 py-0.5 rounded-md border border-border">
                            <Tag className="w-2.5 h-2.5 mr-1 text-treasure" /> {tag}
                          </span>
                        ))}
                      </div>
                      <div className="border-t border-border pt-4 flex items-center justify-between text-xs text-muted-foreground font-cinematic font-bold">
                        <span className="flex items-center"><MessageCircle className="w-4 h-4 mr-1.5 text-treasure" /> {news.commentsCount} COMMENTS</span>
                        <span className="flex items-center text-treasure group-hover:translate-x-1 transition-transform">READ DISPATCH <ArrowRight className="w-3.5 h-3.5 ml-1" /></span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
