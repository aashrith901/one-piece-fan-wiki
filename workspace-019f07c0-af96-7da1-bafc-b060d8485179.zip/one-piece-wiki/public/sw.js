// ============================================================================
// ENTERPRISE PROGRESSIVE WEB APP (PWA) SERVICE WORKER
// ============================================================================

const CACHE_NAME = "one-piece-wiki-cache-v1.0.2";
const STATIC_ASSETS = [
  "/",
  "/manifest.json",
  "/favicon.ico",
  "/offline",
  "/globals.css",
];

// 1. Install Event & Static Asset Pre-caching
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("[PWA Service Worker] Pre-caching offline assets");
      return cache.addAll(STATIC_ASSETS);
    })
  );
  self.skipWaiting();
});

// 2. Activate Event & Old Cache Scrubbing
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log("[PWA Service Worker] Scrubbing obsolete cache: ", cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// 3. Fetch Event Strategy: NetworkFirst for APIs, CacheFirst for static assets
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Ignore non-GET requests or external analytics hits
  if (event.request.method !== "GET" || url.origin !== self.location.origin) {
    return;
  }

  // API Routes: Network First, Fallback to Cache
  if (url.pathname.startsWith("/api/")) {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          const resClone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, resClone));
          return response;
        })
        .catch(() => {
          console.warn("[PWA Service Worker] Network down, serving API route from cache: ", event.request.url);
          return caches.match(event.request).then((cachedResponse) => {
            return cachedResponse || new Response(JSON.stringify({ success: false, offline: true, error: "System offline. Serving fallback mock structure." }), {
              headers: { "Content-Type": "application/json" },
            });
          });
        })
    );
    return;
  }

  // Static Pages / Navigation: Cache First, Fallback to Network, Fallback to /offline
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        // Fetch background refresh to update cache silently
        fetch(event.request).then((netResponse) => {
          if (netResponse.status === 200) {
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, netResponse));
          }
        }).catch(() => {});
        return cachedResponse;
      }

      return fetch(event.request)
        .then((netResponse) => {
          if (netResponse.status === 200) {
            const netClone = netResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, netClone));
          }
          return netResponse;
        })
        .catch(() => {
          console.warn("[PWA Service Worker] Navigation fetch failed, serving dedicated /offline fallback page.");
          return caches.match("/offline");
        });
    })
  );
});

// 4. Background Sync Listener
self.addEventListener("sync", (event) => {
  if (event.tag === "sync-bounty-project") {
    console.log("[PWA Service Worker] Background sync event triggered: ", event.tag);
    // Simulation of background sync push to Drizzle ORM
  }
});

// 5. Push Notification Listener
self.addEventListener("push", (event) => {
  const data = event.data ? event.data.json() : { title: "News Coo Broadcast", body: "A new legendary event occurred on the Grand Line!" };
  const options = {
    body: data.body,
    icon: "/icons/apple-touch-icon.png",
    badge: "/favicon.ico",
  };
  event.waitUntil(self.registration.showNotification(data.title, options));
});
