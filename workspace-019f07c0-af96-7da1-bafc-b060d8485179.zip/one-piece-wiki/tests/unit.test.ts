import { formatBounty, seededRandom } from "../src/lib/utils";
import { userProfileSchema, discussionThreadSchema, pollSchema, userCustomBountySchema } from "../src/lib/validations";

// ============================================================================
// ENTERPRISE UNIT TESTING SUITE
// ============================================================================

describe("Utility Functions Unit Tests", () => {
  test("formatBounty correctly formats raw numbers and string currencies", () => {
    expect(formatBounty(3000000000)).toBe("฿ 3,000,000,000");
    expect(formatBounty("1500000000")).toBe("฿ 1,500,000,000");
    expect(formatBounty(0)).toBe("฿ 0");
  });

  test("seededRandom generates persistent pseudo-random floats between 0 and 1", () => {
    const val1 = seededRandom("monkey-d-luffy");
    const val2 = seededRandom("monkey-d-luffy");
    const val3 = seededRandom("roronoa-zoro");
    expect(val1).toBe(val2);
    expect(val1).not.toBe(val3);
    expect(val1).toBeGreaterThanOrEqual(0);
    expect(val1).toBeLessThanOrEqual(1);
  });
});

describe("Zod Validation Schema Unit Tests", () => {
  test("userProfileSchema validates correct dossier inputs", () => {
    const valid = { username: "luffy_emperor", bio: "Pirate King", factionAllegiance: "Pirates" };
    const res = userProfileSchema.safeParse(valid);
    expect(res.success).toBe(true);

    const invalid = { username: "lu", factionAllegiance: "InvalidFaction" };
    const resInv = userProfileSchema.safeParse(invalid);
    expect(resInv.success).toBe(false);
  });

  test("discussionThreadSchema verifies thread broadcast requirements", () => {
    const valid = { slug: "test-thread", title: "Valid Thread Title", category: "Theories", content: "This is a sufficiently long content body to pass validation rules." };
    const res = discussionThreadSchema.safeParse(valid);
    expect(res.success).toBe(true);
  });

  test("pollSchema validates ballot options count", () => {
    const valid = { slug: "test-poll", question: "Who will win?", options: [{ optionText: "Luffy" }, { optionText: "Kaido" }] };
    const res = pollSchema.safeParse(valid);
    expect(res.success).toBe(true);
  });
});
