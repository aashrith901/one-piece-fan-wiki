import { GET as searchGet } from "../src/app/api/search/route";
import { GET as newsGet } from "../src/app/api/news/route";
import { GET as syncGet } from "../src/app/api/sync/route";
import { GET as adminGet, POST as adminPost } from "../src/app/api/admin/route";
import { NextRequest } from "next/server";

// ============================================================================
// ENTERPRISE INTEGRATION TESTING SUITE
// ============================================================================

describe("API Route Integration Tests", () => {
  test("GET /api/search returns successful paginated lore entity structures", async () => {
    const req = new NextRequest("https://onepiecefanwiki.grandline/api/search?q=Luffy&filter=all");
    const res = await searchGet(req);
    const data = await res.json();
    expect(data.success).toBe(true);
    expect(data.data.length).toBeGreaterThan(0);
    expect(data.data[0].name).toContain("Luffy");
  });

  test("GET /api/news correctly resolves category filters and breaking tickers", async () => {
    const req = new NextRequest("https://onepiecefanwiki.grandline/api/news?category=Manga News");
    const res = await newsGet(req);
    const data = await res.json();
    expect(data.success).toBe(true);
    expect(data.data[0].category).toBe("Manga News");
    expect(data.breaking.length).toBeGreaterThan(0);
  });

  test("GET /api/sync enforces smart memory caching and never crashes", async () => {
    const req = new NextRequest("https://onepiecefanwiki.grandline/api/sync");
    const res1 = await syncGet(req);
    const data1 = await res1.json();
    expect(data1.success).toBe(true);

    // Second immediate call should hit smart cache
    const res2 = await syncGet(req);
    const data2 = await res2.json();
    expect(data2.success).toBe(true);
    expect(data2.cached).toBe(true);
  });

  test("POST /api/admin creates encrypted backup snapshots successfully", async () => {
    const req = new NextRequest("https://onepiecefanwiki.grandline/api/admin", {
      method: "POST",
      body: JSON.stringify({ action: "createBackup", title: "Automated Test Backup" }),
    });
    const res = await adminPost(req);
    const data = await res.json();
    expect(data.success).toBe(true);
    expect(data.backupId).toContain("backup_");
  });
});
